package com.tekhnical.amplify.model;

public class CurrencySymbol {
    public final String symbol;
    public final boolean symbolFirst;

    public CurrencySymbol(String symbol2) {
        this(symbol2, false);
    }

    public CurrencySymbol(String symbol2, boolean symbolFirst2) {
        this.symbol = symbol2;
        this.symbolFirst = symbolFirst2;
    }
}
