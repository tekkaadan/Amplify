package com.tekhnical.amplify.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;

import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;

public class ScreenDialog extends Dialog {
    private LinearLayout contentLayout;
    private TextView titleView, messageView;
    private ImageView saveButton;
    public ScreenDialog(@NonNull Context context) {
        super(context);
        getWindow().getAttributes().windowAnimations = R.style.ScreenDialogAnimation;
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        setContentView(R.layout.dialog_screen);
        getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        titleView = findViewById(R.id.dialog_title);
        messageView = findViewById(R.id.messageView);
        contentLayout = findViewById(R.id.content);
        saveButton = findViewById(R.id.save_btn);
        ImageView closeButton = findViewById(R.id.close_btn);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        LinearLayout parentCard = findViewById(R.id.dialog_parent);
        parentCard.setBackgroundColor(MyApplication.getAppBackground(getContext()));
    }

    public void setTitle(@Nullable CharSequence title) {
        titleView.setText(title);
    }

    public void setView(View view){
        contentLayout.addView(view);
    }
    public void setMessage(String message){
        messageView.setVisibility(View.VISIBLE);
        messageView.setText(message);
    }
    public void setSaveButton(boolean visible){
        saveButton.setVisibility(visible ? View.VISIBLE : View.GONE);
    }
    public void setSaveListener(View.OnClickListener listener){
        saveButton.setVisibility(View.VISIBLE);
        saveButton.setOnClickListener(listener);
    }
}
