package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Crex24 extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Crex24";
    private static final String TTS_NAME = "Crex24";
    private static final String URL = "https://api.crex24.com/v2/public/tickers?instrument=%1$s";
    private static final String CURRENCIES_URL = "https://api.crex24.com/v2/public/instruments";

    public Crex24() {
        super("crex24", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/crex.png";
        //return "https://assets.coingecko.com/markets/images/138/small/Webp.net-resizeimage_%285%29.png";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.crex;
    }
    @Override
    public void parseTicker(int requestId, String responseString, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        if (jsonArray.length()>0) {
            JSONObject jsonObject =jsonArray.getJSONObject(0);
            ticker.last = ParseUtils.getDouble(jsonObject, "last");
            ticker.high = ParseUtils.getDouble(jsonObject, "high");
            ticker.low = ParseUtils.getDouble(jsonObject, "low");
            ticker.bid = ParseUtils.getDouble(jsonObject, "bid");
            ticker.ask = ParseUtils.getDouble(jsonObject, "ask");
            ticker.vol = ParseUtils.getDouble(jsonObject, "baseVolume");
        }
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("state") & jsonObject.getString("state").equalsIgnoreCase("active")){
                pairs.add(new CurrencyPairInfo(jsonObject.getString("baseCurrency").toUpperCase(),jsonObject.getString("quoteCurrency").toUpperCase(),jsonObject.getString("symbol")));
            }
        }
    }

}
