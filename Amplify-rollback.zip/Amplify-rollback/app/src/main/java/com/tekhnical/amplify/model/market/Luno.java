package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class Luno extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Luno";
    private static final String TTS_NAME = "Luno";
    private static final String URL = "https://api.luno.com/api/1/ticker?pair=%1$s%2$s";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.XBT, new String[]{Currency.EUR,Currency.ZAR,Currency.UGX,Currency.ZMW});
        CURRENCY_PAIRS.put(VirtualCurrency.ETH, new String[]{VirtualCurrency.XBT});
        CURRENCY_PAIRS.put(VirtualCurrency.BCH, new String[]{VirtualCurrency.XBT});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Luno.png";
        //return "https://assets.coingecko.com/markets/images/33/small/luno.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.luno;
    }
    public Luno() {
        super("luno",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyBase(), checkerInfo.getCurrencyCounter()});
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject,"bid");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject,"ask");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject,"rolling_24_hour_volume");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject,"last_trade");
        if (jsonObject.has("timestamp")){
            ticker.timestamp = jsonObject.getLong("timestamp");
        }
    }
}
