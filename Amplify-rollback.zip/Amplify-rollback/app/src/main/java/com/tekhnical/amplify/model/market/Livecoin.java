package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class Livecoin extends Market {
    private static final String NAME = "Livecoin";
    private static final String TTS_NAME = "Live coin";
    private static final String URL = "https://api.livecoin.net/exchange/ticker?currencyPair=%1$s";
    private static final String URL_CURRENCY_PAIRS = "https://api.livecoin.net/exchange/ticker";

    public Livecoin() {
        super("livecoin",NAME, TTS_NAME, null);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/livecoin.png";
        //return "https://assets.coingecko.com/markets/images/32/small/livecoin.png";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.livecoin;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDouble(jsonObject,"best_bid");
        ticker.ask = ParseUtils.getDouble(jsonObject,"best_ask");
        ticker.vol = ParseUtils.getDouble(jsonObject,"volume");
        ticker.high = ParseUtils.getDouble(jsonObject,"high");
        ticker.low = ParseUtils.getDouble(jsonObject,"low");
        ticker.last = ParseUtils.getDouble(jsonObject,"last");
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray tickerArray = new JSONArray(responseString);
        for (int i = 0; i < tickerArray.length(); i++) {
            if(tickerArray.getJSONObject(i).has("symbol")) {
                String symbol = tickerArray.getJSONObject(i).getString("symbol");
                String[] currencyNames = symbol.split("/");
                if (currencyNames != null && currencyNames.length >= 2) {
                    pairs.add(new CurrencyPairInfo(currencyNames[0], currencyNames[1], symbol));
                }
            }
        }
    }
}
