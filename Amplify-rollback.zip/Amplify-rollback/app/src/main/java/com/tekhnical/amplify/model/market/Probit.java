package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Probit extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Probit";
    private static final String TTS_NAME = "Probit";
    private static final String URL = "https://api.probit.com/api/exchange/v1/ticker?market_ids=%1$s";
    private static final String CURRENCIES_URL = "https://api.probit.com/api/exchange/v1/market";

    public Probit() {
        super("probit", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }


    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/ProBit.png";
        //return "https://assets.coingecko.com/markets/images/370/small/probit.png";
    }
*/
    @Override
    public int getImageUrl() {
        return R.drawable.probit;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray jsonArray = tickerObject.getJSONArray("data");
        JSONObject jsonObject = jsonArray.getJSONObject(0);
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "base_volume");
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = jsonObject.getJSONArray("data");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject pairObject = jsonArray.getJSONObject(i);
            if (pairObject.has("id"))
            list.add(new CurrencyPairInfo(pairObject.getString("base_currency_id"),pairObject.getString("quote_currency_id"),pairObject.getString("id")));

        }
    }

}
