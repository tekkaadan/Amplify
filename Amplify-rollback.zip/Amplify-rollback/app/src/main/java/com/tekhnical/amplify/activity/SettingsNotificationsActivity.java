package com.tekhnical.amplify.activity;

import android.os.Bundle;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.generic.SimpleFragmentSubActivity;
import com.tekhnical.amplify.fragment.SettingsNotificationsFragment;

public class SettingsNotificationsActivity extends SimpleFragmentSubActivity<SettingsNotificationsFragment> {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.setContentTheme(true);
        super.onCreate(savedInstanceState);
    }

    @Override
    public SettingsNotificationsFragment createChildFragment() {
        return new SettingsNotificationsFragment();
    }

    @Override
    public int getContentViewResId() {
        return R.layout.setting_main_activity;
    }

    @Override
    public String getContentViewTitle() {
        return getString(R.string.settings_activity_title);
    }

   /* @Override
    public String getContentViewTitle() {
        return getResources().getString(R.string.settings_notifications_category_title);
    }*/
}
