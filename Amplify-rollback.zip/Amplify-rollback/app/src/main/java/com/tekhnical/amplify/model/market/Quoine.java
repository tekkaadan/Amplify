package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class Quoine extends Market {
    private static final String NAME = "Liquid";
    private static final String TTS_NAME = "Liquid";
    private static final String URL = "https://api.liquid.com/products/code/CASH/%1$s";
    private static final String URL_CURRENCY_PAIRS = "https://api.liquid.com/products/";

    public Quoine() {
        super("quoine",NAME, TTS_NAME, null);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/liquid.png";
        //return "https://assets.coingecko.com/markets/images/40/small/liquid.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.liquid;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDouble(jsonObject,"market_bid");
        ticker.ask = ParseUtils.getDouble(jsonObject,"market_ask");
        ticker.vol = ParseUtils.getDouble(jsonObject,"volume_24h");
        ticker.high = ParseUtils.getDouble(jsonObject,"high_market_ask");
        ticker.low = ParseUtils.getDouble(jsonObject,"low_market_bid");
        ticker.last = ParseUtils.getDouble(jsonObject,"last_traded_price");
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray pairsJsonArray = new JSONArray(responseString);
        for (int i = 0; i < pairsJsonArray.length(); i++) {
            JSONObject pairJsonObject = pairsJsonArray.getJSONObject(i);
            if (VirtualCurrency.CASH.equals(pairJsonObject.getString("code"))) {
                String currencyCounter = pairJsonObject.getString("currency");
                String pairName = pairJsonObject.getString("currency_pair_code");
                if (!(pairName == null || currencyCounter == null || !pairName.endsWith(currencyCounter))) {
                    pairs.add(new CurrencyPairInfo(pairName.substring(0, pairName.length() - currencyCounter.length()), currencyCounter, pairName));
                }
            }
        }
    }
}
