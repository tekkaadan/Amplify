package com.tekhnical.amplify.content;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

import com.tekhnical.amplify.content.MaindbContract.Checker;
import com.tekhnical.amplify.content.MaindbContract.Checker.Builder;
import com.robotoworks.mechanoid.Mechanoid;
import com.robotoworks.mechanoid.db.AbstractValuesBuilder;
import com.robotoworks.mechanoid.db.ActiveRecord;
import com.robotoworks.mechanoid.db.ActiveRecordFactory;
import com.robotoworks.mechanoid.util.Closeables;

public class CheckerRecord extends ActiveRecord implements Parcelable {
    public static final Creator<CheckerRecord> CREATOR = new Creator<CheckerRecord>() {
        public CheckerRecord createFromParcel(Parcel in) {
            return new CheckerRecord(in);
        }

        public CheckerRecord[] newArray(int size) {
            return new CheckerRecord[size];
        }
    };
    public static String[] PROJECTION = {"_id", MaindbContract.CheckerColumns.ENABLED, MaindbContract.CheckerColumns.MARKET_KEY, MaindbContract.CheckerColumns.CURRENCY_SRC, MaindbContract.CheckerColumns.CURRENCY_DST, MaindbContract.CheckerColumns.FREQUENCY, MaindbContract.CheckerColumns.NOTIFICATION_PRIORITY, MaindbContract.CheckerColumns.TTS_ENABLED, MaindbContract.CheckerColumns.LAST_CHECK_TICKER, MaindbContract.CheckerColumns.LAST_CHECK_POINT_TICKER, MaindbContract.CheckerColumns.PREVIOUS_CHECK_TICKER, MaindbContract.CheckerColumns.LAST_CHECK_DATE, MaindbContract.CheckerColumns.SORT_ORDER, MaindbContract.CheckerColumns.CURRENCY_SUBUNIT_SRC, MaindbContract.CheckerColumns.CURRENCY_SUBUNIT_DST, MaindbContract.CheckerColumns.ERROR_MSG, MaindbContract.CheckerColumns.CURRENCY_PAIR_ID, MaindbContract.CheckerColumns.CONTRACT_TYPE,MaindbContract.CheckerColumns.HOLDINGS,MaindbContract.CheckerColumns.MARKET_TYPE,MaindbContract.CheckerColumns.HOLDINGS_AMOUNT, MaindbContract.CheckerColumns.FREQUENCY_TYPE};
    public static String[] PROJECTION_PORTFOLIO = {"_id", MaindbContract.CheckerColumns.ENABLED, MaindbContract.CheckerColumns.MARKET_KEY, MaindbContract.CheckerColumns.CURRENCY_SRC, MaindbContract.CheckerColumns.CURRENCY_DST, MaindbContract.CheckerColumns.FREQUENCY, MaindbContract.CheckerColumns.NOTIFICATION_PRIORITY, MaindbContract.CheckerColumns.TTS_ENABLED, MaindbContract.CheckerColumns.LAST_CHECK_TICKER, MaindbContract.CheckerColumns.LAST_CHECK_POINT_TICKER, MaindbContract.CheckerColumns.PREVIOUS_CHECK_TICKER, MaindbContract.CheckerColumns.LAST_CHECK_DATE, MaindbContract.CheckerColumns.SORT_ORDER, MaindbContract.CheckerColumns.CURRENCY_SUBUNIT_SRC, MaindbContract.CheckerColumns.CURRENCY_SUBUNIT_DST, MaindbContract.CheckerColumns.ERROR_MSG, MaindbContract.CheckerColumns.CURRENCY_PAIR_ID, MaindbContract.CheckerColumns.CONTRACT_TYPE,MaindbContract.CheckerColumns.HOLDINGS,MaindbContract.CheckerColumns.MARKET_TYPE,MaindbContract.CheckerColumns.HOLDINGS_AMOUNT, MaindbContract.CheckerColumns.FREQUENCY_TYPE, "SUM("+MaindbContract.CheckerColumns.HOLDINGS_AMOUNT+") as sum"};
    private static ActiveRecordFactory<CheckerRecord> sFactory = new ActiveRecordFactory<CheckerRecord>() {
        public CheckerRecord create(Cursor c) {
            return CheckerRecord.fromCursor(c);
        }

        public String[] getProjection() {
            return CheckerRecord.PROJECTION;
        }

        @Override
        public Uri getContentUri() {
            return null;
        }
    };
    private long mContractType;
    private boolean mContractTypeDirty;
    private String mCurrencyDst;
    private boolean mCurrencyDstDirty;
    private String mCurrencyPairId;
    private boolean mCurrencyPairIdDirty;
    private String mCurrencySrc;
    private boolean mCurrencySrcDirty;
    private long mCurrencySubunitDst;
    private boolean mCurrencySubunitDstDirty;
    private long mCurrencySubunitSrc;
    private boolean mCurrencySubunitSrcDirty;
    private boolean mEnabled;
    private boolean mEnabledDirty;
    private String mErrorMsg;
    private boolean mErrorMsgDirty;
    private long mFrequency;
    private boolean mFrequencyDirty;
    private long mLastCheckDate;
    private boolean mLastCheckDateDirty;
    private String mLastCheckPointTicker;
    private boolean mLastCheckPointTickerDirty;
    private String mLastCheckTicker;
    private boolean mLastCheckTickerDirty;
    private String mMarketKey;
    private boolean mMarketKeyDirty;
    private long mNotificationPriority;
    private boolean mNotificationPriorityDirty;
    private String mPreviousCheckTicker;
    private boolean mPreviousCheckTickerDirty;
    private long mSortOrder;
    private boolean mSortOrderDirty;
    private boolean mTtsEnabled;
    private boolean mTtsEnabledDirty;
    private String mHoldings;
    private boolean mHoldingsDirty;
    private double mHoldingsAmount;
    private boolean mHoldingsAmountDirty;
    private double mSum;
    private boolean mSumDirty;
    private long mMarketType;
    private boolean mMarketTypeDirty;
    private int mFrequencyType;
    private boolean mFrequencyTypeDirty;
    public interface Indices {
        public static final int CONTRACT_TYPE = 17;
        public static final int HOLDINGS = 18;
        public static final int HOLDINGS_AMOUNT = 20;
        public static final int SUM = 22;
        public static final int FREQUENCY_TYPE = 21;
        public static final int MARKET_TYPE = 19;
        public static final int CURRENCY_DST = 4;
        public static final int CURRENCY_PAIR_ID = 16;
        public static final int CURRENCY_SRC = 3;
        public static final int CURRENCY_SUBUNIT_DST = 14;
        public static final int CURRENCY_SUBUNIT_SRC = 13;
        public static final int ENABLED = 1;
        public static final int ERROR_MSG = 15;
        public static final int FREQUENCY = 5;
        public static final int LAST_CHECK_DATE = 11;
        public static final int LAST_CHECK_POINT_TICKER = 9;
        public static final int LAST_CHECK_TICKER = 8;
        public static final int MARKET_KEY = 2;
        public static final int NOTIFICATION_PRIORITY = 6;
        public static final int PREVIOUS_CHECK_TICKER = 10;
        public static final int SORT_ORDER = 12;
        public static final int TTS_ENABLED = 7;
        public static final int _ID = 0;
    }

    public static ActiveRecordFactory<CheckerRecord> getFactory() {
        return sFactory;
    }

    @Override
    public String[] _getProjection() {
        return PROJECTION;
    }

    public void setEnabled(boolean enabled) {
        this.mEnabled = enabled;
        this.mEnabledDirty = true;
    }

    public boolean getEnabled() {
        return this.mEnabled;
    }

    public long getMarketType() {
        return mMarketType;
    }

    public void setMarketType(long marketType) {
        this.mMarketType = marketType;
        this.mMarketTypeDirty = true;
    }

    public int getFrequencyType() {
        return mFrequencyType;
    }

    public void setFrequencyType(int type) {
        this.mFrequencyType = type;
        this.mFrequencyTypeDirty = true;
    }

    public String getHoldings() {
        return mHoldings;
    }

    public void setHoldings(String mHoldings) {
        this.mHoldings = mHoldings;
        this.mHoldingsDirty = true;
    }

    public double getHoldingsAmount() {
        return mHoldingsAmount;
    }

    public void setHoldingsAmount(double mHoldingsAmount) {
        this.mHoldingsAmount = mHoldingsAmount;
        this.mHoldingsAmountDirty = true;
    }

    public void setSum(double mSum) {
        this.mSum = mSum;
        this.mSumDirty = true;
    }

    public double getSum() {
        return mSum;
    }

    public void setMarketKey(String marketKey) {
        this.mMarketKey = marketKey;
        this.mMarketKeyDirty = true;
    }

    public String getMarketKey() {
        return this.mMarketKey;
    }

    public void setCurrencySrc(String currencySrc) {
        this.mCurrencySrc = currencySrc;
        this.mCurrencySrcDirty = true;
    }

    public String getCurrencySrc() {
        return this.mCurrencySrc;
    }

    public void setCurrencyDst(String currencyDst) {
        this.mCurrencyDst = currencyDst;
        this.mCurrencyDstDirty = true;
    }

    public String getCurrencyDst() {
        return this.mCurrencyDst;
    }

    public void setFrequency(long frequency) {
        this.mFrequency = frequency;
        this.mFrequencyDirty = true;
    }

    public long getFrequency() {
        return this.mFrequency;
    }

    public void setNotificationPriority(long notificationPriority) {
        this.mNotificationPriority = notificationPriority;
        this.mNotificationPriorityDirty = true;
    }

    public long getNotificationPriority() {
        return this.mNotificationPriority;
    }

    public void setTtsEnabled(boolean ttsEnabled) {
        this.mTtsEnabled = ttsEnabled;
        this.mTtsEnabledDirty = true;
    }

    public boolean getTtsEnabled() {
        return this.mTtsEnabled;
    }

    public void setLastCheckTicker(String lastCheckTicker) {
        this.mLastCheckTicker = lastCheckTicker;
        this.mLastCheckTickerDirty = true;
    }

    public String getLastCheckTicker() {
        return this.mLastCheckTicker;
    }

    public void setLastCheckPointTicker(String lastCheckPointTicker) {
        this.mLastCheckPointTicker = lastCheckPointTicker;
        this.mLastCheckPointTickerDirty = true;
    }

    public String getLastCheckPointTicker() {
        return this.mLastCheckPointTicker;
    }

    public void setPreviousCheckTicker(String previousCheckTicker) {
        this.mPreviousCheckTicker = previousCheckTicker;
        this.mPreviousCheckTickerDirty = true;
    }

    public String getPreviousCheckTicker() {
        return this.mPreviousCheckTicker;
    }

    public void setLastCheckDate(long lastCheckDate) {
        this.mLastCheckDate = lastCheckDate;
        this.mLastCheckDateDirty = true;
    }

    public long getLastCheckDate() {
        return this.mLastCheckDate;
    }

    public void setSortOrder(long sortOrder) {
        this.mSortOrder = sortOrder;
        this.mSortOrderDirty = true;
    }

    public long getSortOrder() {
        return this.mSortOrder;
    }

    public void setCurrencySubunitSrc(long currencySubunitSrc) {
        this.mCurrencySubunitSrc = currencySubunitSrc;
        this.mCurrencySubunitSrcDirty = true;
    }

    public long getCurrencySubunitSrc() {
        return this.mCurrencySubunitSrc;
    }

    public void setCurrencySubunitDst(long currencySubunitDst) {
        this.mCurrencySubunitDst = currencySubunitDst;
        this.mCurrencySubunitDstDirty = true;
    }

    public long getCurrencySubunitDst() {
        return this.mCurrencySubunitDst;
    }

    public void setErrorMsg(String errorMsg) {
        this.mErrorMsg = errorMsg;
        this.mErrorMsgDirty = true;
    }

    public String getErrorMsg() {
        return this.mErrorMsg;
    }

    public void setCurrencyPairId(String currencyPairId) {
        this.mCurrencyPairId = currencyPairId;
        this.mCurrencyPairIdDirty = true;
    }

    public String getCurrencyPairId() {
        return this.mCurrencyPairId;
    }

    public void setContractType(long contractType) {
        this.mContractType = contractType;
        this.mContractTypeDirty = true;
    }

    public long getContractType() {
        return this.mContractType;
    }

    public CheckerRecord() {
        super(Checker.CONTENT_URI);
    }

    private CheckerRecord(Parcel in) {
        super(Checker.CONTENT_URI);
        setId(in.readLong());

        this.mEnabled = in.readInt() > 0;
        this.mMarketKey = in.readString();
        this.mCurrencySrc = in.readString();
        this.mCurrencyDst = in.readString();
        this.mFrequency = in.readLong();
        this.mNotificationPriority = in.readLong();

        this.mTtsEnabled = in.readInt() > 0;
        this.mLastCheckTicker = in.readString();
        this.mLastCheckPointTicker = in.readString();
        this.mPreviousCheckTicker = in.readString();
        this.mLastCheckDate = in.readLong();
        this.mSortOrder = in.readLong();
        this.mCurrencySubunitSrc = in.readLong();
        this.mCurrencySubunitDst = in.readLong();
        this.mErrorMsg = in.readString();
        this.mCurrencyPairId = in.readString();
        this.mContractType = in.readLong();
        this.mHoldings = in.readString();
        this.mHoldingsAmount = in.readDouble();
        this.mMarketType = in.readLong();
        this.mFrequencyType = in.readInt();
        boolean[] dirtyFlags = new boolean[21];
        in.readBooleanArray(dirtyFlags);
        this.mEnabledDirty = dirtyFlags[0];
        this.mMarketKeyDirty = dirtyFlags[1];
        this.mCurrencySrcDirty = dirtyFlags[2];
        this.mCurrencyDstDirty = dirtyFlags[3];
        this.mFrequencyDirty = dirtyFlags[4];
        this.mNotificationPriorityDirty = dirtyFlags[5];
        this.mTtsEnabledDirty = dirtyFlags[6];
        this.mLastCheckTickerDirty = dirtyFlags[7];
        this.mLastCheckPointTickerDirty = dirtyFlags[8];
        this.mPreviousCheckTickerDirty = dirtyFlags[9];
        this.mLastCheckDateDirty = dirtyFlags[10];
        this.mSortOrderDirty = dirtyFlags[11];
        this.mCurrencySubunitSrcDirty = dirtyFlags[12];
        this.mCurrencySubunitDstDirty = dirtyFlags[13];
        this.mErrorMsgDirty = dirtyFlags[14];
        this.mCurrencyPairIdDirty = dirtyFlags[15];
        this.mContractTypeDirty = dirtyFlags[16];
        this.mHoldingsDirty = dirtyFlags[17];
        this.mMarketTypeDirty = dirtyFlags[18];
        this.mHoldingsAmountDirty = dirtyFlags[19];
        this.mFrequencyTypeDirty = dirtyFlags[20];
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(getId());
        dest.writeInt(this.mEnabled ? 1 : 0);
        dest.writeString(this.mMarketKey);
        dest.writeString(this.mCurrencySrc);
        dest.writeString(this.mCurrencyDst);
        dest.writeLong(this.mFrequency);
        dest.writeLong(this.mNotificationPriority);
        dest.writeInt(this.mTtsEnabled?1:0);
        dest.writeString(this.mLastCheckTicker);
        dest.writeString(this.mLastCheckPointTicker);
        dest.writeString(this.mPreviousCheckTicker);
        dest.writeLong(this.mLastCheckDate);
        dest.writeLong(this.mSortOrder);
        dest.writeLong(this.mCurrencySubunitSrc);
        dest.writeLong(this.mCurrencySubunitDst);
        dest.writeString(this.mErrorMsg);
        dest.writeString(this.mCurrencyPairId);
        dest.writeLong(this.mContractType);
        dest.writeString(this.mHoldings);
        dest.writeDouble(this.mHoldingsAmount);
        dest.writeLong(this.mMarketType);
        dest.writeInt(this.mFrequencyType);
        dest.writeBooleanArray(new boolean[]{this.mEnabledDirty, this.mMarketKeyDirty, this.mCurrencySrcDirty, this.mCurrencyDstDirty, this.mFrequencyDirty, this.mNotificationPriorityDirty, this.mTtsEnabledDirty, this.mLastCheckTickerDirty, this.mLastCheckPointTickerDirty, this.mPreviousCheckTickerDirty, this.mLastCheckDateDirty, this.mSortOrderDirty, this.mCurrencySubunitSrcDirty, this.mCurrencySubunitDstDirty, this.mErrorMsgDirty, this.mCurrencyPairIdDirty, this.mContractTypeDirty,this.mHoldingsDirty,this.mMarketTypeDirty,this.mHoldingsAmountDirty, this.mFrequencyTypeDirty});
    }

    @Override
    public AbstractValuesBuilder createBuilder() {
        Builder builder = Checker.newBuilder();
        if (this.mEnabledDirty) {
            builder.setEnabled(this.mEnabled);
        }
        if (this.mMarketKeyDirty) {
            builder.setMarketKey(this.mMarketKey);
        }
        if (this.mCurrencySrcDirty) {
            builder.setCurrencySrc(this.mCurrencySrc);
        }
        if (this.mCurrencyDstDirty) {
            builder.setCurrencyDst(this.mCurrencyDst);
        }
        if (this.mFrequencyDirty) {
            builder.setFrequency(this.mFrequency);
        }
        if (this.mNotificationPriorityDirty) {
            builder.setNotificationPriority(this.mNotificationPriority);
        }
        if (this.mTtsEnabledDirty) {
            builder.setTtsEnabled(this.mTtsEnabled);
        }
        if (this.mLastCheckTickerDirty) {
            builder.setLastCheckTicker(this.mLastCheckTicker);
        }
        if (this.mLastCheckPointTickerDirty) {
            builder.setLastCheckPointTicker(this.mLastCheckPointTicker);
        }
        if (this.mPreviousCheckTickerDirty) {
            builder.setPreviousCheckTicker(this.mPreviousCheckTicker);
        }
        if (this.mLastCheckDateDirty) {
            builder.setLastCheckDate(this.mLastCheckDate);
        }
        if (this.mSortOrderDirty) {
            builder.setSortOrder(this.mSortOrder);
        }
        if (this.mCurrencySubunitSrcDirty) {
            builder.setCurrencySubunitSrc(this.mCurrencySubunitSrc);
        }
        if (this.mCurrencySubunitDstDirty) {
            builder.setCurrencySubunitDst(this.mCurrencySubunitDst);
        }
        if (this.mErrorMsgDirty) {
            builder.setErrorMsg(this.mErrorMsg);
        }
        if (this.mCurrencyPairIdDirty) {
            builder.setCurrencyPairId(this.mCurrencyPairId);
        }
        if (this.mContractTypeDirty) {
            builder.setContractType(this.mContractType);
        }
        if (this.mHoldingsDirty) {
            builder.setHoldings(this.mHoldings);
        }
        if (this.mHoldingsAmountDirty) {
            builder.setHoldingsAmount(this.mHoldingsAmount);
        }
        if (this.mMarketTypeDirty) {
            builder.setMarketType(this.mMarketType);
        }
        if (this.mFrequencyTypeDirty) {
            builder.setFrequencyType(this.mFrequencyType);
        }
        return builder;
    }

    public void makeDirty(boolean dirty) {
        this.mEnabledDirty = dirty;
        this.mMarketKeyDirty = dirty;
        this.mCurrencySrcDirty = dirty;
        this.mCurrencyDstDirty = dirty;
        this.mFrequencyDirty = dirty;
        this.mNotificationPriorityDirty = dirty;
        this.mTtsEnabledDirty = dirty;
        this.mLastCheckTickerDirty = dirty;
        this.mLastCheckPointTickerDirty = dirty;
        this.mPreviousCheckTickerDirty = dirty;
        this.mLastCheckDateDirty = dirty;
        this.mSortOrderDirty = dirty;
        this.mCurrencySubunitSrcDirty = dirty;
        this.mCurrencySubunitDstDirty = dirty;
        this.mErrorMsgDirty = dirty;
        this.mCurrencyPairIdDirty = dirty;
        this.mContractTypeDirty = dirty;
        this.mHoldingsDirty = dirty;
        this.mHoldingsAmountDirty = dirty;
        this.mMarketTypeDirty = dirty;
        this.mFrequencyTypeDirty = dirty;
    }

    @Override
    public void setPropertiesFromCursor(Cursor c) {
        boolean z = true;
        setId(c.getLong(Indices._ID));
        setEnabled(c.getInt(Indices.ENABLED) > 0);
        setMarketKey(c.getString(Indices.MARKET_KEY));
        setCurrencySrc(c.getString(Indices.CURRENCY_SRC));
        setCurrencyDst(c.getString(Indices.CURRENCY_DST));
        setFrequency(c.getLong(Indices.FREQUENCY));
        setNotificationPriority(c.getLong(Indices.NOTIFICATION_PRIORITY));
        if (c.getInt(Indices.TTS_ENABLED) <= 0) {
            z = false;
        }
        setTtsEnabled(z);
        setLastCheckTicker(c.getString(Indices.LAST_CHECK_TICKER));
        setLastCheckPointTicker(c.getString(Indices.LAST_CHECK_POINT_TICKER));
        setPreviousCheckTicker(c.getString(Indices.PREVIOUS_CHECK_TICKER));
        setLastCheckDate(c.getLong(Indices.LAST_CHECK_DATE));
        setSortOrder(c.getLong(Indices.SORT_ORDER));
        setCurrencySubunitSrc(c.getLong(Indices.CURRENCY_SUBUNIT_SRC));
        setCurrencySubunitDst(c.getLong(Indices.CURRENCY_SUBUNIT_DST));
        setErrorMsg(c.getString(Indices.ERROR_MSG));
        setCurrencyPairId(c.getString(Indices.CURRENCY_PAIR_ID));
        setContractType(c.getLong(Indices.CONTRACT_TYPE));
        setHoldings(c.getString(Indices.HOLDINGS));
        setHoldingsAmount(c.getDouble(Indices.HOLDINGS_AMOUNT));
        setMarketType(c.getLong(Indices.MARKET_TYPE));
        setFrequencyType(c.getInt(Indices.FREQUENCY_TYPE));
        if(!c.isNull(Indices.SUM))
            setSum(c.getDouble(Indices.SUM));
    }

    public static CheckerRecord fromCursor(Cursor c) {
        CheckerRecord item = new CheckerRecord();
        item.setPropertiesFromCursor(c);
        item.makeDirty(false);
        return item;
    }

    public static CheckerRecord fromBundle(Bundle bundle, String key) {
        bundle.setClassLoader(CheckerRecord.class.getClassLoader());
        return (CheckerRecord) bundle.getParcelable(key);
    }

    public static CheckerRecord get(long id) {
        Cursor c = null;
        try {
            c = Mechanoid.getContentResolver().query(Checker.CONTENT_URI.buildUpon().appendPath(String.valueOf(id)).build(), PROJECTION, null, null, null);
            if (!c.moveToFirst()) {
                Closeables.closeSilently(c);
                return null;
            }
            CheckerRecord fromCursor = fromCursor(c);
            Closeables.closeSilently(c);
            return fromCursor;
        } catch (Throwable th) {
            Closeables.closeSilently(c);
            throw th;
        }
    }
}
