package com.tekhnical.amplify.activity.generic;

public interface OnboardingListener {
    public void changeView(int index);
}
