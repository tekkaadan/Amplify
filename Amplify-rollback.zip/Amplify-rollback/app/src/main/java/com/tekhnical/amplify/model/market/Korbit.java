package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import org.json.JSONObject;

public class Korbit extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Korbit";
    private static final String TTS_NAME = "Korbit";
    private static final String URL = "https://api.korbit.co.kr/v1/ticker/detailed?currency_pair=%1$s_%2$s";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{Currency.KRW});
        CURRENCY_PAIRS.put(VirtualCurrency.ETH, new String[]{Currency.KRW});
        CURRENCY_PAIRS.put(VirtualCurrency.ETC, new String[]{Currency.KRW});
        CURRENCY_PAIRS.put(VirtualCurrency.XRP, new String[]{Currency.KRW});
    }

    public Korbit() {
        super("korbit",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyBaseLowerCase(), checkerInfo.getCurrencyCounterLowerCase()});
    }
/*
    @Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Korbit.png";
        //return "https://assets.coingecko.com/markets/images/28/small/korbit-logo.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.korbit;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject,"bid");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject,"ask");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject,"volume");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject,"high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject,"low");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject,"last");
        if (jsonObject.has("timestamp"))
            ticker.timestamp = jsonObject.getLong("timestamp");
    }
}
