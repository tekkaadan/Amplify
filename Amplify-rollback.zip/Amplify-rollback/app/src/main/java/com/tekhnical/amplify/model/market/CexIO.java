package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class CexIO extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "CEX.IO";
    private static final String TTS_NAME = "CEX IO";
    private static final String URL = "https://cex.io/api/ticker/%1$s/%2$s";
    private static final String URL_CURRENCY_PAIRS = "https://cex.io/api/currency_limits";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{Currency.USD, Currency.EUR, Currency.GBP, Currency.RUB});
        CURRENCY_PAIRS.put(VirtualCurrency.ETH, new String[]{Currency.USD, Currency.EUR, VirtualCurrency.BTC});
        CURRENCY_PAIRS.put("GHS", new String[]{VirtualCurrency.BTC});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/CEXIO.png";
        //return "https://assets.coingecko.com/markets/images/56/small/CEX.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.cexio;
    }
    public CexIO() {
        super("cex",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyBase(), checkerInfo.getCurrencyCounter()});
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        if (jsonObject.has("bid")) {
            ticker.bid = ParseUtils.getDouble(jsonObject,"bid");
        }
        if (jsonObject.has("ask")) {
            ticker.ask = ParseUtils.getDouble(jsonObject,"ask");
        }
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject,"volume");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject,"high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject,"low");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject,"last");
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray pairsJsonArray = jsonObject.getJSONObject("data").getJSONArray("pairs");
        for (int i = 0; i < pairsJsonArray.length(); i++) {
            JSONObject pairJsonObject = pairsJsonArray.getJSONObject(i);
            String currencyBase = ParseUtils.getString(pairJsonObject,"symbol1");
            String currencyCounter = ParseUtils.getString(pairJsonObject,"symbol2");
            if (!currencyBase.isEmpty() && !currencyCounter.isEmpty()) {
                pairs.add(new CurrencyPairInfo(currencyBase, currencyCounter, currencyBase+":"+currencyCounter));
            }
        }
    }
}
