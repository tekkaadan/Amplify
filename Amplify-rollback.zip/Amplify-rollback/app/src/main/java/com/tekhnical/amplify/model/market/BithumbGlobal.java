package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class BithumbGlobal extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "BithumbGlobal";
    private static final String TTS_NAME = "Bithumb Global";
    private static final String URL = "https://global-openapi.bithumb.pro/openapi/v1/spot/ticker?symbol=%1$s";
    private static final String CURRENCIES_URL = "https://global-openapi.bithumb.pro/openapi/v1/spot/config";

    public BithumbGlobal() {
        super("bithumb_global", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/BithumbGlobal.png";
        //return "https://assets.coingecko.com/markets/images/405/small/bithumb-global.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bithumbglobal;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        if (tickerObject.has("data") & tickerObject.getJSONArray("data").length()>0) {
            JSONObject jsonObject = tickerObject.getJSONArray("data").getJSONObject(0);
            ticker.last = ParseUtils.getDouble(jsonObject, "c");
            ticker.high = ParseUtils.getDoubleFromString(jsonObject, "h");
            ticker.low = ParseUtils.getDoubleFromString(jsonObject, "l");
            ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "vol");
        }
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONObject dataObject = json.getJSONObject("data");
        if (dataObject.has("spotConfig")) {
            JSONArray jsonArray = dataObject.getJSONArray("spotConfig");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject pairObject = jsonArray.getJSONObject(i);
                String[] splits =  pairObject.getString("symbol").split("-");
                if (splits.length>=2) {
                    list.add(new CurrencyPairInfo(splits[0],splits[1], pairObject.getString("symbol")));
                }

            }

        }
    }

}
