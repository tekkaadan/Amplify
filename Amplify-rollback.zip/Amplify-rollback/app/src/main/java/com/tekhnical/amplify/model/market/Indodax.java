package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Indodax extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Indodax";
    private static final String TTS_NAME = "Indodax";
    private static final String URL = "https://indodax.com/api/ticker/%1$s";
    private static final String CURRENCIES_URL = "https://indodax.com/api/pairs";

    public Indodax() {
        super("indodax", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject("ticker");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "buy");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "sell");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "vol_btc");
        if (jsonObject.has("server_time"))
            ticker.timestamp = jsonObject.getLong("server_time");
    }

/*    @Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Indodax.png";
        //return "https://assets.coingecko.com/markets/images/3/small/logogram-Indodax-new-_JPG_format.jpg";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.indodax;
    }
    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("symbol")){
                pairs.add(new CurrencyPairInfo(jsonObject.getString("traded_currency").toUpperCase(),jsonObject.getString("base_currency").toUpperCase(),jsonObject.getString("id")));
            }
        }
    }


}
