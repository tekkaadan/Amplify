package com.tekhnical.amplify.model;

import com.google.gson.annotations.SerializedName;

public class StockGlobalQuote {

    @SerializedName("quote")
    private StockQuote quote;

    public StockQuote getQuote() {
        return quote;
    }

    public void setQuote(StockQuote quote) {
        this.quote = quote;
    }
}
