package com.tekhnical.amplify.volley;

import android.content.Context;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.RequestFuture;
import com.tekhnical.amplify.util.AsyncTaskCompat;
import com.tekhnical.amplify.util.HttpsHelper;
import com.tekhnical.amplify.util.PreferencesUtils;
import com.tekhnical.amplify.volley.generic.GzipVolleyStringRequest;
import java.util.Locale;
import org.json.JSONObject;

public class UserCountryDetectionAsyncTask extends AsyncTask<Void, Void, Void> {
    private final Context appContext;
    private final RequestQueue requestQueue;

    private UserCountryDetectionAsyncTask(Context context) {
        this.appContext = context.getApplicationContext();
        this.requestQueue = HttpsHelper.newRequestQueue(context);
    }

    @Override
    public Void doInBackground(Void... params) {
        updateUserRegion();
        return null;
    }

    public boolean updateUserRegion() {
        String userCountry = getCountryCodeFromTelephonyNetwork();
        if (TextUtils.isEmpty(userCountry)) {
            userCountry = getCountryCodeFromInternet();
        }
        if (TextUtils.isEmpty(userCountry)) {
            userCountry = getCountryCodeSystemLocale();
        }
        if (TextUtils.isEmpty(userCountry)) {
            return false;
        }
        PreferencesUtils.setUserCountry(this.appContext, userCountry);
        return true;
    }

    private String getCountryCodeFromTelephonyNetwork() {
        try {
            TelephonyManager telephonyManager = (TelephonyManager) this.appContext.getSystemService("phone");
            if (telephonyManager == null) {
                return null;
            }
            String countryIso = telephonyManager.getNetworkCountryIso();
            if (countryIso != null) {
                return countryIso.toUpperCase(Locale.ENGLISH);
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private String getCountryCodeFromInternet() {
        try {
            RequestFuture<String> future = RequestFuture.newFuture();
            GzipVolleyStringRequest request = new GzipVolleyStringRequest("http://ip-api.com/json", future, future);
            request.setRetryPolicy(new DefaultRetryPolicy(8000, 1, 1.0f));
            this.requestQueue.add(request);
            String responseString = (String) future.get();
            if (responseString != null) {
                return new JSONObject(responseString).getString("countryCode");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private String getCountryCodeSystemLocale() {
        String country;
        try {
            Locale locale = this.appContext.getResources().getConfiguration().locale;
            if (locale != null) {
                country = locale.getCountry();
            } else {
                country = null;
            }
            if (TextUtils.isEmpty(country)) {
                country = Locale.getDefault().getCountry();
            }
            if (TextUtils.isEmpty(country)) {
                return null;
            }
            return country;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void setupUserCountry(Context context) {
        if (TextUtils.isEmpty(PreferencesUtils.getUserCountry(context))) {
            AsyncTaskCompat.execute(new UserCountryDetectionAsyncTask(context), new Void[0]);
        }
    }
}
