package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Gate extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "GateIO";
    private static final String TTS_NAME = "GateIO";
    private static final String URL = "https://data.gateio.la/api2/1/ticker/%1$s";
    private static final String CURRENCIES_URL = "https://data.gateio.la/api2/1/pairs";

    public Gate() {
        super("gate", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/GateIO.png";
        //return "https://assets.coingecko.com/markets/images/60/small/gateio.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.gateio;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDouble(jsonObject, "highestBid");
        ticker.ask = ParseUtils.getDouble(jsonObject, "lowestAsk");
        ticker.last = ParseUtils.getDouble(jsonObject, "last");
        ticker.high = ParseUtils.getDouble(jsonObject, "high24hr");
        ticker.low = ParseUtils.getDouble(jsonObject, "low24hr");
        ticker.vol = ParseUtils.getDouble(jsonObject, "baseVolume");

    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            String pair = jsonArray.getString(i);
            if (pair.contains("_")) {
                String[] split = pair.split("_");
                if (split.length >= 2)
                    pairs.add(new CurrencyPairInfo(split[0].toUpperCase(), split[1].toUpperCase(), pair));
            }
        }
    }
}
