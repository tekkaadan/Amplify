package com.tekhnical.amplify;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.preference.PreferenceManager;

import com.tekhnical.amplify.volley.UserCountryDetectionAsyncTask;
import com.robotoworks.mechanoid.Mechanoid;

public class MyApplication extends Application {
    public static final String NIGHT_MODE = "NIGHT_MODE";
    private boolean isNightModeEnabled = true;

    private static MyApplication singleton = null;
    public static boolean reCreate = false;
    public static int appMarketType = 0, isRefresh = -1;
    public static MyApplication getInstance() {

        if(singleton == null)
        {
            singleton = new MyApplication();
        }
        return singleton;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        singleton = this;
        super.onCreate();
        Mechanoid.init(this);
        UserCountryDetectionAsyncTask.setupUserCountry(this);
        SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        isNightModeEnabled = mPrefs.getBoolean(NIGHT_MODE, true);

        changeMode(isNightModeEnabled,mPrefs.getInt(getString(R.string.settings_theme_category_key),2));
    }

    public boolean isNightModeEnabled() {
        return isNightModeEnabled;
    }

    public void setIsNightModeEnabled(boolean isNightModeEnabled) {
        reCreate = true;
        this.isNightModeEnabled = isNightModeEnabled;
        SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = mPrefs.edit();
        editor.putBoolean(NIGHT_MODE, isNightModeEnabled);
        editor.apply();
        changeMode(isNightModeEnabled,mPrefs.getInt(getString(R.string.settings_theme_category_key),2));
    }

    public static int getAppTheme(Context context){
        SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(context);
        return mPrefs.getInt(context.getString(R.string.settings_theme_category_key),2);
    }
    public static int getAppBackground(Context context){
        switch (getAppTheme(context)){
            case 1:
                return context.getResources().getColor(R.color.md_grey_50);
            case 2:
                return context.getResources().getColor(R.color.colorAmoledPrimary);
            case 3:
                return context.getResources().getColor(R.color.theme_gray_light);
            case 4:
                return context.getResources().getColor(R.color.theme_sepia_light);
            default:
                return context.getResources().getColor(R.color.background);
        }
    }
    private void changeMode(boolean isNightModeEnabled, int theme) {
        Log.e("APP","THEME:"+theme);
        if (isNightModeEnabled)
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        else
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
    }
}
