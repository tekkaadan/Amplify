package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Tokenlon extends Market {

    private static final String NAME = "Tokenlon";
    private static final String TTS_NAME = "Tokenlon";
    private static final String URL = "https://tokenlon-core-market.tokenlon.im/rest/get_ticker?period=24H&pairs=%1$s";
    private static final String CURRENCIES_URL = "https://tokenlon-core-market.tokenlon.im/rest/get_pairs";


    public Tokenlon() {
        super("tokenlon", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    @Override
    public int getImageUrl() {
        return R.drawable.tokenlon;
    }
    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/ZB.png";
        //return "https://assets.coingecko.com/markets/images/115/small/zb.jpg";
    }*/

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject("data");
        ticker.bid = ParseUtils.getDouble(jsonObject, "bid");
        ticker.ask = ParseUtils.getDouble(jsonObject, "ask");
        ticker.last = ParseUtils.getDouble(jsonObject, "last");
        ticker.low = ParseUtils.getDouble(jsonObject, "low");
        ticker.high = ParseUtils.getDouble(jsonObject, "high");
        ticker.vol = ParseUtils.getDouble(jsonObject, "vol");
        if (jsonObject.has("timestamp")){
            ticker.timestamp = jsonObject.getLong("timestamp");
        }

    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = jsonObject.getJSONArray("data");
        for (int i = 0; i < jsonArray.length(); i++) {
            String split[] = jsonArray.getString(i).split("_");
            if (split.length>=2)
                list.add(new CurrencyPairInfo(split[0].toUpperCase(),split[1].toUpperCase(),jsonArray.getString(i)));
        }
    }



}
