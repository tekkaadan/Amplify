package com.tekhnical.amplify.fragment;

import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.preference.Preference;
import androidx.preference.Preference.OnPreferenceChangeListener;
import androidx.preference.PreferenceCategory;
import androidx.preference.PreferenceFragmentCompat;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.receiver.MarketChecker;
import com.tekhnical.amplify.util.NotificationUtils;
import com.tekhnical.amplify.util.PreferencesUtils;

public class SettingsNotificationsFragment extends PreferenceFragmentCompat {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);
        //view.setBackgroundColor(getResources().getColor(R.color.background));
        return view;
    }

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.settings_notifications, rootKey);
        PreferenceCategory checkNotificationCategoryPreference = (PreferenceCategory) findPreference(getString(R.string.settings_check_notification_category_key));
        Preference checkNotificationFearIndexPreference = findPreference(getString(R.string.settings_check_notification_fearindex_key));

        checkNotificationFearIndexPreference.setOnPreferenceChangeListener(new OnPreferenceChangeListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                PreferencesUtils.setCheckNotificationFearIndex(SettingsNotificationsFragment.this.getActivity(), ((Boolean) newValue).booleanValue());
                MarketChecker.checkAsyncFearIndex(SettingsNotificationsFragment.this.getActivity(), (Boolean) newValue);
                MarketChecker.resetAlarmManagerForFearIndex(SettingsNotificationsFragment.this.getActivity(), false);
                return true;
            }
        });

        Preference checkNotificationExpandablePreference = findPreference(getString(R.string.settings_check_notification_expandable_key));

        checkNotificationExpandablePreference.setOnPreferenceChangeListener(new OnPreferenceChangeListener() {
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                PreferencesUtils.setCheckNotificationExpandable(SettingsNotificationsFragment.this.getActivity(), ((Boolean) newValue).booleanValue());
                NotificationUtils.refreshOngoingNotifications(SettingsNotificationsFragment.this.getActivity());
                return true;
            }
        });

        Preference checkNotificationCustomLayoutPreference = findPreference(getString(R.string.settings_check_notification_custom_layout_key));

        checkNotificationCustomLayoutPreference.setOnPreferenceChangeListener(new OnPreferenceChangeListener() {
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                PreferencesUtils.setCheckNotificationCustomLayout(SettingsNotificationsFragment.this.getActivity(), ((Boolean) newValue).booleanValue());
                NotificationUtils.refreshOngoingNotifications(SettingsNotificationsFragment.this.getActivity());
                return true;
            }
        });

        Preference checkNotificationTickerPreference = findPreference(getString(R.string.settings_check_notification_ticker_key));

        checkNotificationTickerPreference.setOnPreferenceChangeListener(new OnPreferenceChangeListener() {
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                PreferencesUtils.setCheckNotificationTicker(SettingsNotificationsFragment.this.getActivity(), ((Boolean) newValue).booleanValue());
                NotificationUtils.refreshOngoingNotifications(SettingsNotificationsFragment.this.getActivity());
                return true;
            }
        });
    }

}
