package com.tekhnical.amplify.preferences;

import android.content.Context;
import androidx.preference.ListPreference;
import android.util.AttributeSet;

public class IntListPreference extends ListPreference {
    public IntListPreference(Context context) {
        super(context);
        init();
    }

    public IntListPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setDefaultEntryValues();
    }

    public void setDefaultEntryValues() {
        if (getEntryValues() == null && getEntries() != null) {
            int count = getEntries().length;
            CharSequence[] entryValues = new String[count];
            for (int i = 0; i < count; i++) {
                entryValues[i] = String.valueOf(i);
            }
            setEntryValues(entryValues);
        }
    }

    @Override
    public boolean persistString(String value) {
        if (value == null) {
            return false;
        }
        return persistInt(Integer.valueOf(value).intValue());
    }

    @Override
    public String getPersistedString(String defaultReturnValue) {
        return !getSharedPreferences().contains(getKey()) ? defaultReturnValue : String.valueOf(getPersistedInt(0));
    }


}
