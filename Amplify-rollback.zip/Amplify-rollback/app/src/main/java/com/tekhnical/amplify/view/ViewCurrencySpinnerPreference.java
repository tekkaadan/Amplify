package com.tekhnical.amplify.view;

import android.annotation.TargetApi;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

import com.tekhnical.amplify.view.generic.ViewSpinnerPreference;

public class ViewCurrencySpinnerPreference extends ViewSpinnerPreference {
    private OnClickListener onSyncClickedListener;
    private boolean showSyncButton;

    public ViewCurrencySpinnerPreference(Context context) {
        super(context);
    }

    public ViewCurrencySpinnerPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @TargetApi(11)
    public ViewCurrencySpinnerPreference(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public void setShowSyncButton(boolean showSyncButton2) {
        this.showSyncButton = showSyncButton2;
    }

    @Override
    public void onFinishInflate() {
        super.onFinishInflate();
        setWidget(new View(getContext()));
    }

    /*@Override
    public void onPrepareDialog(CustomDialog builder) {
        super.onPrepareDialog(builder);
        if (this.showSyncButton) {
            builder.setPositiveButton(getResources().getString(R.string.checker_add_check_currency_dst_dialog_sync), new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (ViewCurrencySpinnerPreference.this.onSyncClickedListener != null) {
                        ViewCurrencySpinnerPreference.this.onSyncClickedListener.onClick(ViewCurrencySpinnerPreference.this);
                    }
                }
            });
        }
    }*/

    public void setOnSyncClickedListener(OnClickListener onSyncClickedListener2) {
        this.onSyncClickedListener = onSyncClickedListener2;
    }
}
