package com.tekhnical.amplify.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;

import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;

public class CustomDialog extends Dialog {
    private AppCompatButton okButton, neutralButton, cancelButton;
    private LinearLayout contentLayout;
    private TextView titleView, messageView;
    public CustomDialog(@NonNull Context context) {
        super(context);
        getWindow().getAttributes().windowAnimations = R.style.ExitDialogAnimation;
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        setContentView(R.layout.dialog_custom);
        getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        titleView = findViewById(R.id.dialog_title);
        messageView = findViewById(R.id.messageView);
        okButton = findViewById(R.id.ok_btn);
        neutralButton = findViewById(R.id.neutral_btn);
        cancelButton = findViewById(R.id.cancel_btn);
        contentLayout = findViewById(R.id.content);
        ImageView closeButton = findViewById(R.id.close_btn);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        CardView parentCard = findViewById(R.id.dialog_parent);
        parentCard.setCardBackgroundColor(MyApplication.getAppBackground(getContext()));
    }

    public void setTitle(@Nullable CharSequence title) {
        titleView.setText(title);
    }

    public void setView(View view){
        contentLayout.addView(view);
    }
    public void setMessage(String message){
        messageView.setVisibility(View.VISIBLE);
        messageView.setText(message);
    }
    public void setPositiveButton(String text, View.OnClickListener listener){
        okButton.setVisibility(View.VISIBLE);
        okButton.setText(text);
        okButton.setOnClickListener(listener);
    }
    public void setNeutralButton(String text, View.OnClickListener listener){
        neutralButton.setVisibility(View.VISIBLE);
        neutralButton.setText(text);
        neutralButton.setOnClickListener(listener);
    }
    public void setNegativeButton(String text, View.OnClickListener listener){
        cancelButton.setVisibility(View.VISIBLE);
        cancelButton.setText(text);
        cancelButton.setOnClickListener(listener);
    }
}
