package com.tekhnical.amplify.content;

import android.content.Context;

public class MaindbOpenHelper extends AbstractMaindbOpenHelper {
    public MaindbOpenHelper(Context context) {
        super(context);
    }
}
