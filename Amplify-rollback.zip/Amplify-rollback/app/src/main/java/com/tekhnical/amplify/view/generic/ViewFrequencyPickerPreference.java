package com.tekhnical.amplify.view.generic;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.DialogInterface;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.NumberPicker;

import com.jaygoo.widget.OnRangeChangedListener;
import com.jaygoo.widget.RangeSeekBar;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.dialog.CustomDialog;
import com.tekhnical.amplify.dialog.ScreenDialog;
import com.tekhnical.amplify.preferences.FrequencyPickerDialogPreference;
import com.tekhnical.amplify.util.PreferencesUtils;

import java.text.DecimalFormat;

public class ViewFrequencyPickerPreference extends ScreenDialogPreference {
    public static final long USE_GLOBAL_CHECK_FREQUENCY = -1;
    private long frequency;
    private int frequencyType = 0;
    private String[] frequencyTypeEntries;
    private OnFrequencySelectedListener onFrequencySelectedListener;
    private EditText minutesEd, secondsEd;
    private CompoundButton useGlobalFrequencyCheckBox;
    public interface OnFrequencySelectedListener {
        boolean onFrequencySelected(ViewFrequencyPickerPreference viewFrequencyPickerPreference, int type, long j);
    }

    public ViewFrequencyPickerPreference(Context context) {
        super(context);
    }

    public ViewFrequencyPickerPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @TargetApi(11)
    public ViewFrequencyPickerPreference(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    public void onFinishInflate() {
        super.onFinishInflate();
        setFrequency(0,FrequencyPickerDialogPreference.DEFAULT_FREQUENCY_MILLIS);
    }

    @Override
    public void init(Context context, AttributeSet attrs) {
        this.frequencyTypeEntries = new String[4];
        for (int i = 0; i < FrequencyPickerDialogPreference.FREQUENCY_TYPE_NAMES.length; i++) {
            this.frequencyTypeEntries[i] = getContext().getString(FrequencyPickerDialogPreference.FREQUENCY_TYPE_NAMES[i]);
        }
        super.init(context, attrs);
    }

    public void setFrequency(int type, long frequency2) {
        if (frequency2 >= 0 && frequency2 < FrequencyPickerDialogPreference.MIN_FREQUENCY_MILLIS) {
            frequency2 = FrequencyPickerDialogPreference.MIN_FREQUENCY_MILLIS;
        }
        if (this.frequency != frequency2 && (this.onFrequencySelectedListener == null || this.onFrequencySelectedListener.onFrequencySelected(this, type, frequency2))) {
            this.frequency = frequency2;
            this.frequencyType = type;
        }
        Log.e("VIEW","View FREQ:"+this.frequency +" "+frequencyType);
        setSummary(getEntry());
    }

    public long getFrequency() {
        return this.frequency;
    }

    public CharSequence getEntry() {
        long frequencyToBeDisplayed = this.frequency;
        int frequencyTypeId = this.frequencyType;
        if (this.frequency <= -1) {
            frequencyToBeDisplayed = PreferencesUtils.getCheckGlobalFrequency(getContext());
            frequencyTypeId = 0;
        }
        int frequencyValue = parseFrequencyValue(frequencyToBeDisplayed, frequencyTypeId);
        String frequencyString = getContext().getResources().getQuantityString(FrequencyPickerDialogPreference.FREQUENCY_TYPE_PLURALS[frequencyTypeId], frequencyValue, new Object[]{Integer.valueOf(frequencyValue)});
        if (this.frequency > -1) {
            return frequencyString;
        }
        return getResources().getString(R.string.checker_add_check_frequency_use_global_summary, new Object[]{frequencyString});
    }

    @Override
    public void onPrepareDialog(ScreenDialog builder) {
        boolean z = false;
        View dialogLayout = LayoutInflater.from(getContext()).inflate(R.layout.frequency_picker_dialog, null);
        LinearLayout globalCheckboxLayout = dialogLayout.findViewById(R.id.globalFrequencyCheckBoxLayout);
        globalCheckboxLayout.setVisibility(VISIBLE);
        //final NumberPicker frequencyTypePicker = (NumberPicker) dialogLayout.findViewById(R.id.frequencyTypePicker);
        //final NumberPicker frequencyValuePicker = (NumberPicker) dialogLayout.findViewById(R.id.frequencyValuePicker);
        minutesEd = dialogLayout.findViewById(R.id.frequencyMinutesEd);
        secondsEd = dialogLayout.findViewById(R.id.frequencySecondsEd);
        RangeSeekBar freqRangeBar = dialogLayout.findViewById(R.id.frequencyRangebar);
        useGlobalFrequencyCheckBox = (CompoundButton) dialogLayout.findViewById(R.id.useGlobalFrequencyCheckBox);
        DecimalFormat decimalFormat = new DecimalFormat("00");
        freqRangeBar.setOnRangeChangedListener(new OnRangeChangedListener() {
            @Override
            public void onRangeChanged(RangeSeekBar view, float leftValue, float rightValue, boolean isFromUser) {
                int change = (int) ((60 * leftValue)/100);
                Log.e("SEEKBAR",leftValue+" "+change);
                if(minutesEd.isFocused()) {
                    minutesEd.setText(decimalFormat.format(change));
                    secondsEd.setText("00");
                }
                else {
                    secondsEd.setText(decimalFormat.format(change));
                    minutesEd.setText("00");
                }
            }

            @Override
            public void onStartTrackingTouch(RangeSeekBar view, boolean isLeft) {

            }

            @Override
            public void onStopTrackingTouch(RangeSeekBar view, boolean isLeft) {

            }
        });

        useGlobalFrequencyCheckBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                ViewFrequencyPickerPreference.this.refreshFrequencyPickers(minutesEd, secondsEd, -1);
                minutesEd.setEnabled(!isChecked);
                secondsEd.setEnabled(!isChecked);
                freqRangeBar.setEnabled(!isChecked);
                minutesEd.clearFocus();
                secondsEd.clearFocus();
            }
        });
        if (this.frequency <= -1) {
            z = true;
        }
        useGlobalFrequencyCheckBox.setChecked(z);
        refreshFrequencyPickers(minutesEd, secondsEd, this.frequency);
        /*builder.setPositiveButton(getResources().getString(R.string.ok), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                minutesEd.clearFocus();
                secondsEd.clearFocus();
                int minutes =  Integer.parseInt(minutesEd.getText().toString());
                int secs =  Integer.parseInt(secondsEd.getText().toString());
                long frequencyMillis = getFrequencyMillis(minutes > 0 ? 1 : 0, minutes>0 ? minutes : secs);

                ViewFrequencyPickerPreference.this.setFrequency(useGlobalFrequencyCheckBox.isChecked() ? -1 : frequencyMillis);
                builder.dismiss();
            }

        });*/
        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                save();
            }
        });
        builder.setView(dialogLayout);
        builder.setSaveListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
                builder.dismiss();
            }
        });
    }

    private void save(){
        minutesEd.clearFocus();
        secondsEd.clearFocus();
        int minutes =  Integer.parseInt(minutesEd.getText().toString());
        int secs =  Integer.parseInt(secondsEd.getText().toString());
        int type = minutes > 0 ? 1 : 0;
        long frequencyMillis = getFrequencyMillis(type, minutes>0 ? minutes : secs);

        ViewFrequencyPickerPreference.this.setFrequency(type,useGlobalFrequencyCheckBox.isChecked() ? -1 : frequencyMillis);
    }
    private void refreshFrequencyPickers(EditText minutesEd, EditText secsEd, long frequency2) {
        DecimalFormat decimalFormat = new DecimalFormat("00");
        long frequencyToBeDisplayed = frequency2;
        if (frequency2 <= -1) {
            frequencyToBeDisplayed = PreferencesUtils.getCheckGlobalFrequency(getContext());
        }
        Log.e("VIEW","FREQ:"+frequencyToBeDisplayed + " "+frequencyType);
        if(frequencyType == 1) {
            minutesEd.setText(decimalFormat.format(parseFrequencyValue(frequencyToBeDisplayed, 1)));
            secsEd.setText("00");
        }else {
            secsEd.setText(decimalFormat.format(parseFrequencyValue(frequencyToBeDisplayed, 0)));
            minutesEd.setText("00");
        }
    }

    private long getFrequencyMillis(int frequencyTypeId, int frequencyValue) {
        return FrequencyPickerDialogPreference.FREQUENCY_TYPE_MULTIPLAYERS[frequencyTypeId] * ((long) frequencyValue);
    }

    private int parseFrequencyTypeId(long frequencyMillis) {
        for (int i = FrequencyPickerDialogPreference.FREQUENCY_TYPE_MULTIPLAYERS.length - 1; i >= 0; i--) {
            if (frequencyMillis >= FrequencyPickerDialogPreference.FREQUENCY_TYPE_MULTIPLAYERS[i] * ((long) FrequencyPickerDialogPreference.FREQUENCY_VALUE_MIN[1])) {
                return i;
            }
        }
        return 0;
    }

    private int parseFrequencyValue(long frequencyMillis, int frequencyTypeId) {
        return (int) (frequencyMillis / FrequencyPickerDialogPreference.FREQUENCY_TYPE_MULTIPLAYERS[frequencyTypeId]);
    }

    public void setOnFrequencySelectedListener(OnFrequencySelectedListener onFrequencySelectedListener2) {
        this.onFrequencySelectedListener = onFrequencySelectedListener2;
    }
}
