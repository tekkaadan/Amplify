package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import org.json.JSONObject;

public class Mercado extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Mercado Bitcoin";
    private static final String TTS_NAME = "Mercado";
    private static final String URL = "https://www.mercadobitcoin.net/api/%1$s/ticker/";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{Currency.BRL});
        CURRENCY_PAIRS.put(VirtualCurrency.BCH, new String[]{Currency.BRL});
        CURRENCY_PAIRS.put(VirtualCurrency.LTC, new String[]{Currency.BRL});
    }

    public Mercado() {
        super("mercado",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyBase()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Mercado.png";
        //return "https://assets.coingecko.com/markets/images/34/small/mercado.png";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.mercado;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject tickerJsonObject = jsonObject.getJSONObject("ticker");
        ticker.bid = ParseUtils .getDouble(tickerJsonObject,"buy");
        ticker.ask = ParseUtils.getDouble(tickerJsonObject,"sell");
        ticker.vol = ParseUtils.getDouble(tickerJsonObject,"vol");
        ticker.high = ParseUtils.getDouble(tickerJsonObject,"high");
        ticker.low = ParseUtils.getDouble(tickerJsonObject,"low");
        ticker.last = ParseUtils.getDouble(tickerJsonObject,"last");
        if(tickerJsonObject.has("date"))
            ticker.timestamp = tickerJsonObject.getLong("date") * 1000;
    }
}
