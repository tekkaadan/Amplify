package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import java.util.HashMap;
import java.util.LinkedHashMap;
import org.json.JSONObject;

public class BitBay extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "BitBay.net";
    private static final String TTS_NAME = "Bit Bay";
    private static final String URL = "https://bitbay.net/API/Public/%1$s%2$s/ticker.json";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BCC, new String[]{VirtualCurrency.BTC, Currency.PLN, Currency.USD, Currency.EUR});
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{Currency.PLN, Currency.USD, Currency.EUR});
        CURRENCY_PAIRS.put(VirtualCurrency.DASH, new String[]{VirtualCurrency.BTC, Currency.PLN, Currency.USD, Currency.EUR});
        CURRENCY_PAIRS.put(VirtualCurrency.GAME, new String[]{VirtualCurrency.BTC, Currency.PLN, Currency.USD, Currency.EUR});
        CURRENCY_PAIRS.put(VirtualCurrency.LTC, new String[]{VirtualCurrency.BTC, Currency.PLN, Currency.USD, Currency.EUR});
        CURRENCY_PAIRS.put(VirtualCurrency.ETH, new String[]{VirtualCurrency.BTC, Currency.PLN, Currency.USD, Currency.EUR});
        CURRENCY_PAIRS.put(VirtualCurrency.LSK, new String[]{VirtualCurrency.BTC, Currency.PLN, Currency.USD, Currency.EUR});
    }

    public BitBay() {
        super("bitbay",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyBase(), checkerInfo.getCurrencyCounter()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/BitBay.png";
        //return "https://assets.coingecko.com/markets/images/2/small/BitBay-exchange.jpg";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bitbay;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = jsonObject.getDouble("bid");
        ticker.ask = jsonObject.getDouble("ask");
        ticker.vol = jsonObject.getDouble("volume");
        ticker.high = jsonObject.getDouble("max");
        ticker.low = jsonObject.getDouble("min");
        ticker.last = jsonObject.getDouble("last");
    }
}
