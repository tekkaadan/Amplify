package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import org.json.JSONObject;

public class CoinFloor extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Coinfloor";
    private static final String TTS_NAME = "Coin Floor";
    private static final String URL = "https://webapi.coinfloor.co.uk/bist/%1$s/%2$s/ticker/";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.XBT, new String[]{Currency.GBP, Currency.EUR, Currency.USD});
        CURRENCY_PAIRS.put(VirtualCurrency.BCH, new String[]{Currency.GBP});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Coinfloor.png";
        //return "https://assets.coingecko.com/markets/images/489/small/Coinfloor_logo_square_on_blue_large.png";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.coinfloor;
    }
    public CoinFloor() {
        super("coinfloor",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyBase(), checkerInfo.getCurrencyCounter()});
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject,"bid");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject,"ask");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject,"volume");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject,"high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject,"low");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject,"last");
    }
}
