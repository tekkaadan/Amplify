package com.tekhnical.amplify.view.generic;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.ButterKnife;
import butterknife.BindView;

import com.tekhnical.amplify.R;

public class ViewPreference extends FrameLayout implements OnClickListener {
    private CharSequence summary;
    @BindView(R.id.summaryView)
    TextView summaryView;
    private CharSequence title;
    @BindView(R.id.titleAndSummaryContainer)
    ViewGroup titleAndSummaryContainer;
    @BindView(R.id.titleView)
    TextView titleView;
    @BindView(R.id.widgetFrame)
    ViewGroup widgetFrame;
    @BindView(R.id.action_right)
    ImageView nextIv;

    public ViewPreference(Context context) {
        super(context);
        init(context, null);
    }

    public ViewPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    @TargetApi(11)
    public ViewPreference(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context, attrs);
    }

    @Override
    public void onFinishInflate() {
        super.onFinishInflate();
        //if (getChildCount() == 0) {
            LayoutInflater.from(getContext()).inflate(R.layout.view_preference, this);
        //}
        ButterKnife.bind((View) this);
        setTitle(this.title);
        setSummary(this.summary);
    }

    public void init(Context context, AttributeSet attrs) {
        TypedValue typedValue = new TypedValue();
        ((Activity) context).getTheme().resolveAttribute(R.attr.selectableItemBackground, typedValue, true);
        setBackgroundResource(typedValue.resourceId);
        setOnClickListener(this);
        setFocusable(true);
        if (attrs != null) {
            TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.ViewPreference);
            this.title = a.getString(R.styleable.ViewPreference_android_title);
            this.summary = a.getString(R.styleable.ViewPreference_android_summary);
            a.recycle();
        }
    }

    public ViewGroup getTitleAndSummaryContainer() {
        return this.titleAndSummaryContainer;
    }

    public ViewGroup getWidgetFrame() {
        return this.widgetFrame;
    }

    public void setWidget(View view) {
        if (this.widgetFrame != null) {
            this.nextIv.setVisibility(GONE);
            this.widgetFrame.addView(view);
            this.widgetFrame.setVisibility(VISIBLE);
        }
    }

    public void setTitle(CharSequence title2) {
        this.title = title2;
        if (this.titleView != null) {
            this.titleView.setText(title2);
        }
    }

    public CharSequence getTitle() {
        return this.title;
    }

    public void setSummary(CharSequence summary2) {
        this.summary = summary2;
        if (this.summaryView != null) {
            this.summaryView.setText(summary2);
            this.summaryView.setVisibility(TextUtils.isEmpty(summary2) ? GONE : VISIBLE);
        }
    }

    public CharSequence getSummary() {
        return this.summary;
    }

    public void onClick(View v) {
    }
}
