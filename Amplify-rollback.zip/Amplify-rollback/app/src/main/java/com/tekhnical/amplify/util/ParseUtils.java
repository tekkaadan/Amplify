package com.tekhnical.amplify.util;

import org.json.JSONException;
import org.json.JSONObject;

public class ParseUtils {
    public static double getDoubleFromString(JSONObject jsonObject, String name) throws NumberFormatException, JSONException {
        if(jsonObject.has(name) && jsonObject.getString(name)!=null)
            return Double.parseDouble(jsonObject.getString(name));
        else
            return -1.0d;
    }

    public static long getLongFromString(JSONObject jsonObject, String name) throws NumberFormatException, JSONException {
        if(jsonObject.has(name) && jsonObject.getString(name)!=null)
            return Long.parseLong(jsonObject.getString(name));
        else
            return 0;
    }

    public static double getDouble(JSONObject jsonObject, String name) throws JSONException {
        if(jsonObject.has(name) && !jsonObject.isNull(name))
            return jsonObject.getDouble(name);
        else
            return -1.0d;
    }
    public static String getString(JSONObject jsonObject, String name) throws JSONException {
        if(jsonObject.has(name))
            return jsonObject.getString(name);
        else
            return "";
    }
}
