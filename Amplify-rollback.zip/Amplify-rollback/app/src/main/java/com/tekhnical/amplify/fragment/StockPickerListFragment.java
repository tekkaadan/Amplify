package com.tekhnical.amplify.fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.MarketPickerListActivity;
import com.tekhnical.amplify.adapter.StockPickerAdapter;
import com.tekhnical.amplify.model.ExchangeModel;
import com.tekhnical.amplify.model.StockSearchModel;
import com.tekhnical.amplify.util.ApiInterface;
import com.tekhnical.amplify.util.RetrofitClient;
import com.tekhnical.amplify.util.Utils;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StockPickerListFragment extends Fragment implements SearchView.OnQueryTextListener {


    public static final int SORT_MODE_ALPHABETICALLY = 0;
    public static final int SORT_MODE_NEWEST_FIRST = 1;
    private StockPickerAdapter adapter;
    private RecyclerView stocksRv;
    private String searchQuery;
    private SearchView searchView;
    private ArrayList<ExchangeModel> stockList, updatedList;
    private ApiInterface mInterface;
    private ProgressBar searchProgressBar;
    private TextView emptyView;


    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        stockList = new ArrayList<>();
        updatedList = new ArrayList<>();
        mInterface = RetrofitClient.getAppClient().create(ApiInterface.class);
        this.adapter = new StockPickerAdapter(updatedList,getActivity().getIntent().getStringExtra(MarketPickerListActivity.EXTRA_MARKET_KEY), new StockPickerAdapter.OnStockSelectedListener() {
            @Override
            public void onStockSelected(ExchangeModel model) {
                Intent intent = new Intent();
                intent.putExtra(MarketPickerListActivity.EXTRA_MARKET_KEY, model);
                getActivity().setResult(Activity.RESULT_OK, intent);
                getActivity().finish();
            }
        });
        this.searchProgressBar = view.findViewById(R.id.progress_stock);
        this.emptyView = view.findViewById(R.id.empty_stock_view);
        this.stocksRv = view.findViewById(R.id.stock_rv);
        this.stocksRv.setLayoutManager(new LinearLayoutManager(getContext(),RecyclerView.VERTICAL,false));
        this.stocksRv.setAdapter(adapter);
        this.searchView = view.findViewById(R.id.search_view);
        this.searchView.setOnQueryTextListener(this);
        this.searchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchView.setIconified(false);
            }
        });
        this.searchView.setQuery(this.searchQuery, false);
        this.searchQuery = savedInstanceState != null ? savedInstanceState.getString("searchQuery") : null;
        loadExchanges();

    }

    private void loadExchanges() {
        searchView.setEnabled(false);
        searchProgressBar.setVisibility(View.VISIBLE);
        emptyView.setVisibility(View.GONE);
        updatedList.clear();
        adapter.notifyDataSetChanged();
        mInterface = RetrofitClient.getAppClient().create(ApiInterface.class);
        mInterface.getExchanges(Utils.STOCKAPIKEY).enqueue(new Callback<List<ExchangeModel>>() {
            @Override
            public void onResponse(@NonNull Call<List<ExchangeModel>> call, @NonNull Response<List<ExchangeModel>> response) {
                searchProgressBar.setVisibility(View.GONE);
                searchView.setEnabled(true);
                List<ExchangeModel> list = response.body();
                if (list!=null && list.size()>0){
                    stockList.addAll(list);
                    updatedList.addAll(list);
                    if(adapter!=null)
                        adapter.notifyDataSetChanged();
                }else{
                    emptyView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<ExchangeModel>> call, @NonNull Throwable t) {
                t.printStackTrace();
                searchView.setEnabled(true);
                searchProgressBar.setVisibility(View.GONE);
                emptyView.setText(String.format("Error: %s", t.getMessage()));
                emptyView.setVisibility(View.VISIBLE);
            }
        });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_stock_picker,container,false);
    }

    public void onSaveInstanceState(Bundle outState) {
        outState.putString("searchQuery", this.searchQuery);
        super.onSaveInstanceState(outState);
    }

    public void onDestroyView() {
        super.onDestroyView();
        this.adapter = null;
    }



    public boolean onBackPressed() {
        if (this.searchView == null || this.searchView.isIconified()) {
            return false;
        }
        this.searchView.setQuery("", true);
        this.searchView.setIconified(true);
        return true;
    }


    public boolean onQueryTextChange(String searchQuery) {
        this.searchQuery = searchQuery;
        this.getFilter(searchQuery);
        return true;
    }

    private void getFilter(String searchQuery) {
        if (searchQuery.length()>1) {
            updatedList.clear();
            for (int i=0;i<stockList.size();i++){
                ExchangeModel exchangeModel = stockList.get(i);
                if (exchangeModel.getSymbol().toLowerCase().contains(searchQuery.toLowerCase()) || exchangeModel.getName().toLowerCase().contains((searchQuery.toLowerCase()))){
                    updatedList.add(exchangeModel);
                }
            }
            emptyView.setVisibility(updatedList.size() == 0? View.VISIBLE : View.GONE);
            adapter.notifyDataSetChanged();
        }
    }

    public boolean onQueryTextSubmit(String searchQuery) {
        Utils.hideKeyboard(getActivity(), this.searchView);
        return true;
    }
}
