package com.tekhnical.amplify.model.currency;

import com.tekhnical.amplify.model.CurrencySubunit;
import com.tekhnical.amplify.model.CurrencySubunitsMap;
import java.util.HashMap;

public class CurrenciesSubunits {
    public static final HashMap<String, CurrencySubunitsMap> CURRENCIES_SUBUNITS = new HashMap<>();

    static {
        CURRENCIES_SUBUNITS.put(VirtualCurrency.BTC, new CurrencySubunitsMap(new CurrencySubunit(VirtualCurrency.BTC, 1), new CurrencySubunit(VirtualCurrency.mBTC, 1000), new CurrencySubunit(VirtualCurrency.uBTC, 1000000), new CurrencySubunit(VirtualCurrency.Satoshi, 100000000, false)));
        CURRENCIES_SUBUNITS.put(VirtualCurrency.LTC, new CurrencySubunitsMap(new CurrencySubunit(VirtualCurrency.LTC, 1), new CurrencySubunit(VirtualCurrency.mLTC, 1000)));
    }
}
