package com.tekhnical.amplify.appwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build.VERSION;
import android.util.Log;
import android.view.View;
import android.widget.RemoteViews;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.receiver.NotificationAndWidgetReceiver;
import com.tekhnical.amplify.util.NotificationUtils;

import java.util.Random;

public class WidgetProvider extends AppWidgetProvider {
    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int updateWdgetWithId : appWidgetIds) {
            updateWdgetWithId(context, appWidgetManager, updateWdgetWithId);
        }
        appWidgetManager.notifyAppWidgetViewDataChanged(appWidgetIds, R.id.listView);
        super.onUpdate(context, appWidgetManager, appWidgetIds);
    }

    public static final void updateWdgetWithId(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        Log.e("WIDGET","UPDATE:"+appWidgetId);
        RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.widget);
        boolean isDarkTheme = WidgetPrefsUtils.getDarkTheme(context, appWidgetId);
        int textPrimaryColor = context.getResources().getColor(isDarkTheme ? R.color.widget_text_color_primary_dark : R.color.widget_text_color_primary_light);
        remoteViews.setInt(R.id.backgroundView, "setBackgroundResource", getWidgetBackgroundForAlpha(isDarkTheme, WidgetPrefsUtils.getAlphaPercent(context, appWidgetId)));
        remoteViews.setInt(R.id.actionBar, "setBackgroundResource", isDarkTheme ? R.drawable.widget_actionbar_bg_dark : R.drawable.widget_actionbar_bg_light);
        remoteViews.setInt(R.id.refreshAllView, "setBackgroundResource", isDarkTheme ? R.drawable.widget_action_refresh_all_bg_dark : R.drawable.widget_action_refresh_all_bg_light);
        int actionBarVisibility = WidgetPrefsUtils.getShowActionBar(context, appWidgetId) ? View.VISIBLE : View.GONE;
        remoteViews.setTextColor(R.id.titleView, textPrimaryColor);
        remoteViews.setViewVisibility(R.id.actionBar, actionBarVisibility);
        remoteViews.setImageViewResource(R.id.actionBarSeparator, isDarkTheme ? R.color.widget_actionbar_separator_dark : R.color.widget_actionbar_separator_light);
        remoteViews.setViewVisibility(R.id.actionBarSeparator, actionBarVisibility);
        remoteViews.setTextColor(R.id.emptyView, context.getResources().getColor(isDarkTheme ? R.color.widget_text_color_hint_dark : R.color.widget_text_color_hint_light));
        Intent serviceIntent = new Intent(context, WidgetService.class);
        serviceIntent.putExtra("appWidgetId", appWidgetId);
        serviceIntent.putExtra("random",new Random().nextInt());
        serviceIntent.setData(Uri.parse(serviceIntent.toUri(1)));
        remoteViews.setRemoteAdapter(appWidgetId, R.id.listView, serviceIntent);
        remoteViews.setEmptyView(R.id.listView, R.id.emptyView);
        remoteViews.setTextViewText(R.id.emptyView, context.getString(R.string.widget_list_empty_text));
        PendingIntent mainActivityPendingIntent = NotificationUtils.createMainActivityPendingIntent(context);
        remoteViews.setOnClickPendingIntent(R.id.actionBar, mainActivityPendingIntent);
        remoteViews.setOnClickPendingIntent(R.id.emptyView, mainActivityPendingIntent);
        remoteViews.setImageViewResource(R.id.refreshAllView, isDarkTheme ? R.drawable.ic_action_refresh_dark : R.drawable.ic_action_refresh);
        remoteViews.setOnClickPendingIntent(R.id.refreshAllView, PendingIntent.getBroadcast(context, 0, new Intent(NotificationAndWidgetReceiver.ACTION_NOTIFICATION_REFRESH_ALL, null, context, NotificationAndWidgetReceiver.class), PendingIntent.FLAG_CANCEL_CURRENT));
        Intent refreshIntent = new Intent(NotificationAndWidgetReceiver.ACTION_NOTIFICATION_REFRESH, null, context, NotificationAndWidgetReceiver.class);
        refreshIntent.setData(Uri.parse(refreshIntent.toUri(Intent.URI_INTENT_SCHEME)));
        remoteViews.setPendingIntentTemplate(R.id.listView, PendingIntent.getBroadcast(context, 0, refreshIntent, PendingIntent.FLAG_CANCEL_CURRENT));
        appWidgetManager.updateAppWidget(appWidgetId, remoteViews);
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
    }

    public static void refreshWidget(Context context) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
        appWidgetManager.notifyAppWidgetViewDataChanged(appWidgetManager.getAppWidgetIds(new ComponentName(context, WidgetProvider.class)), R.id.listView);
    }

    private static int getWidgetBackgroundForAlpha(boolean isDarkTheme, int alphaPercent) {
        if (alphaPercent == 100) {
            if (isDarkTheme) {
                return R.drawable.card_background_dark;
            }
            return R.drawable.card_background;
        } else if (alphaPercent >= 90) {
            return isDarkTheme ? R.drawable.card_background_dark_90 : R.drawable.card_background_90;
        } else {
            if (alphaPercent >= 75) {
                return isDarkTheme ? R.drawable.card_background_dark_75 : R.drawable.card_background_75;
            }
            if (alphaPercent >= 50) {
                return isDarkTheme ? R.drawable.card_background_dark_50 : R.drawable.card_background_50;
            }
            if (alphaPercent >= 25) {
                return isDarkTheme ? R.drawable.card_background_dark_25 : R.drawable.card_background_25;
            }
            if (alphaPercent >= 0) {
                return R.drawable.transparent;
            }
            return R.drawable.card_background;
        }
    }
}
