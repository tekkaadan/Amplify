package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Bitmart extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Bitmart";
    private static final String TTS_NAME = "Bitmart";
    private static final String URL = "https://api-cloud.bitmart.com/spot/v1/ticker?symbol=%1$s";
    private static final String CURRENCIES_URL = "https://api-cloud.bitmart.com/spot/v1/symbols";

    public Bitmart() {
        super("bitmart", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/BitMart.png";
        //return "https://assets.coingecko.com/markets/images/239/small/bitmart.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bitmart;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject dataObject = tickerObject.getJSONObject("data");
        JSONObject jsonObject = dataObject.getJSONArray("tickers").getJSONObject(0);
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "best_bid");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "best_ask");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last_price");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high_24h");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low_24h");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "quote_volume_24h");

    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONObject tickerObject = jsonObject.getJSONObject("data");
        JSONArray jsonArray = tickerObject.getJSONArray("symbols");
        for (int i = 0; i < jsonArray.length(); i++) {
            String pair = jsonArray.getString(i);
            String[] splits = pair.split("_");
            if (splits.length>=2){
                list.add(new CurrencyPairInfo(splits[0],splits[1],pair));
            }
        }
    }

}
