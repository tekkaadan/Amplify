package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import org.json.JSONObject;

public class Bitstamp extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Bitstamp";
    private static final String TTS_NAME = "Bitstamp";
    private static final String URL = "https://www.bitstamp.net/api/v2/ticker/%1$s%2$s";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{Currency.EUR, Currency.USD});
        CURRENCY_PAIRS.put(VirtualCurrency.BCH, new String[]{VirtualCurrency.BTC, Currency.EUR, Currency.USD});
        CURRENCY_PAIRS.put(Currency.EUR, new String[]{Currency.USD});
        CURRENCY_PAIRS.put(VirtualCurrency.ETH, new String[]{VirtualCurrency.BTC, Currency.EUR, Currency.USD});
        CURRENCY_PAIRS.put(VirtualCurrency.LTC, new String[]{VirtualCurrency.BTC, Currency.EUR, Currency.USD});
        CURRENCY_PAIRS.put(VirtualCurrency.XRP, new String[]{VirtualCurrency.BTC, Currency.EUR, Currency.USD});
    }

    public Bitstamp() {
        super("bitstamp",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyBaseLowerCase(), checkerInfo.getCurrencyCounterLowerCase()});
    }

    /*@Override
    public String getImageUrl() {
        return "https://assets.coingecko.com/markets/images/9/small/bitstamp.jpg";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bitstamp;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject,"bid");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject,"ask");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject,"volume");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject,"high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject,"low");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject,"last");
        ticker.timestamp = ParseUtils.getLongFromString(jsonObject,"timestamp");
    }
}
