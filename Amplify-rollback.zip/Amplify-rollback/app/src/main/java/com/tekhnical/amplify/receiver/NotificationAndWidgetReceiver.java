package com.tekhnical.amplify.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.tekhnical.amplify.activity.CheckerAddActivity;
import com.tekhnical.amplify.alarm.AlarmKlaxonHelper;
import com.tekhnical.amplify.alarm.Alarms;
import com.tekhnical.amplify.content.AlarmRecord;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.content.MaindbContract.Checker;
import com.tekhnical.amplify.util.AlarmRecordHelper;
import com.tekhnical.amplify.util.NotificationUtils;
import com.robotoworks.mechanoid.Mechanoid;

public class NotificationAndWidgetReceiver extends BroadcastReceiver {
    public static final String ACTION_NOTIFICATION_ALARM_DISMISS = "com.tekhnical.amplify.receiver.action.notification_alarm_dismiss";
    public static final String ACTION_NOTIFICATION_CHECKER_ALARM_DETAILS = "com.tekhnical.amplify.receiver.action.notification_checker_alarm_details";
    public static final String ACTION_NOTIFICATION_REFRESH = "com.tekhnical.amplify.receiver.action.notification_refresh";
    public static final String ACTION_NOTIFICATION_REFRESH_ALL = "com.tekhnical.amplify.receiver.action.notification_refresh_all";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_NOTIFICATION_REFRESH.equals(action)) {
                long checkerRecrdId = intent.getLongExtra(MarketChecker.EXTRA_CHECKER_RECORD_ID, -1);
                if (checkerRecrdId > 0) {
                    MarketChecker.checkMarketAsyncForCheckerRecord(context, CheckerRecord.get(checkerRecrdId));
                }
            } else if (ACTION_NOTIFICATION_REFRESH_ALL.equals(action)) {
                MarketChecker.refreshAllEnabledCheckerRecords(context);
            } else if (ACTION_NOTIFICATION_CHECKER_ALARM_DETAILS.equals(action)) {
                long checkerRecordId = intent.getLongExtra(MarketChecker.EXTRA_CHECKER_RECORD_ID, -1);
                long alarmRecordId = intent.getLongExtra(MarketChecker.EXTRA_ALARM_RECORD_ID, -1);
                if (checkerRecordId > 0 && alarmRecordId > 0) {
                    disableAlarmRecordIfNeeded(alarmRecordId);
                    CheckerRecord checkerRecord = CheckerRecord.get(checkerRecordId);
                    if (checkerRecord != null) {
                        CheckerAddActivity.startCheckerAddActivity(context, checkerRecord, alarmRecordId, true);
                    }
                }
            } else if (ACTION_NOTIFICATION_ALARM_DISMISS.equals(action)) {
                long checkerRecordId2 = intent.getLongExtra(MarketChecker.EXTRA_CHECKER_RECORD_ID, -1);
                long alarmRecordId2 = intent.getLongExtra(MarketChecker.EXTRA_ALARM_RECORD_ID, -1);
                if (checkerRecordId2 > 0 && alarmRecordId2 > 0) {
                    disableAlarmRecordIfNeeded(alarmRecordId2);
                    context.sendBroadcast(AlarmKlaxonHelper.createAlarmKlaxonDismissIntent(context, checkerRecordId2, alarmRecordId2));
                }
            } else if (Alarms.ALARM_DISMISS_ACTION.equals(action)) {
                long alarmRecordId3 = intent.getLongExtra(MarketChecker.EXTRA_ALARM_RECORD_ID, -1);
                if (alarmRecordId3 > 0) {
                    NotificationUtils.clearAlarmNotificationForAlarmRecord(context, alarmRecordId3);
                    disableAlarmRecordIfNeeded(alarmRecordId3);
                }
            } else if (Alarms.ALARM_DONE_ACTION.equals(action)) {
                long alarmRecordId4 = intent.getLongExtra(MarketChecker.EXTRA_ALARM_RECORD_ID, -1);
                if (alarmRecordId4 > 0) {
                    NotificationUtils.clearAlarmNotificationForAlarmRecord(context, alarmRecordId4);
                }
            }
        }
    }

    private boolean disableAlarmRecordIfNeeded(long alarmRecordId) {
        AlarmRecord alarmRecord = AlarmRecord.get(alarmRecordId);
        if (alarmRecord == null || !AlarmRecordHelper.shouldDisableAlarmAfterDismiss(alarmRecord)) {
            return false;
        }
        alarmRecord.setEnabled(false);
        try {
            alarmRecord.save(true);
            Mechanoid.getContentResolver().notifyChange(Checker.CONTENT_URI, null);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return true;
        }
    }
}
