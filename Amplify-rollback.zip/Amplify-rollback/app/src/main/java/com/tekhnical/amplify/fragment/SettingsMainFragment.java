package com.tekhnical.amplify.fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.preference.ListPreference;
import androidx.preference.Preference;

import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.SettingsMainActivity;
import com.tekhnical.amplify.activity.SettingsNotificationsActivity;
import com.tekhnical.amplify.activity.SettingsSoundsActivity;
import com.tekhnical.amplify.activity.SettingsTTSActivity;
import com.tekhnical.amplify.fragment.generic.TTSAwareFragment;
import com.tekhnical.amplify.receiver.MarketChecker;
import com.tekhnical.amplify.util.PreferencesUtils;
import com.tekhnical.amplify.util.Utils;

public class SettingsMainFragment extends TTSAwareFragment {
    private SettingsMainActivity settingsMainActivity;
    private Preference ttsCategoryPreference;


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof SettingsMainActivity) {
            this.settingsMainActivity = (SettingsMainActivity) context;
        }
    }

    @Override
    public void onDisplayPreferenceDialog(Preference preference) {
        super.onDisplayPreferenceDialog(preference);
    }


     @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
         View view = super.onCreateView(inflater, container, savedInstanceState);
         //view.setBackgroundColor(getResources().getColor(R.color.background));
         return view;
    }

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        //super.onCreatePreferences(savedInstanceState, rootKey);
        setPreferencesFromResource(R.xml.settings_main,rootKey);
        final ListPreference themePreference = (ListPreference) findPreference(getString(R.string.settings_theme_category_key));
        if (themePreference!=null) {
            //advancedStreamPreference.setSummary(advancedStreamPreference.getEntry());
            themePreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    boolean change= Utils.handleIntListOnPreferenceChange(themePreference, newValue);
                    if (newValue.equals("2")) {
                        MyApplication.getInstance().setIsNightModeEnabled(true);
                    }
                    else {
                        MyApplication.getInstance().setIsNightModeEnabled(false);
                    }
                    if (getActivity()!=null)
                        getActivity().recreate();
                    return change;
                }
            });
        }
        findPreference(getString(R.string.settings_notifications_category_key)).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                SettingsMainFragment.this.startActivity(new Intent(SettingsMainFragment.this.getActivity(), SettingsNotificationsActivity.class));
                return true;
            }
        });
        findPreference(getString(R.string.settings_check_global_frequency_key)).setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                PreferencesUtils.setCheckGlobalFrequency(SettingsMainFragment.this.getActivity(), ((Long) newValue).longValue());
                MarketChecker.resetAlarmManagerForAllEnabledThatUseGlobalFrequency(SettingsMainFragment.this.getActivity());
                return true;
            }
        });
        findPreference(getString(R.string.settings_sounds_category_key)).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                SettingsMainFragment.this.startActivity(new Intent(SettingsMainFragment.this.getActivity(), SettingsSoundsActivity.class));
                return true;
            }
        });
        this.ttsCategoryPreference = findPreference(getString(R.string.settings_tts_category_key));
        this.ttsCategoryPreference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                SettingsMainFragment.this.startActivity(new Intent(SettingsMainFragment.this.getActivity(), SettingsTTSActivity.class));
                return true;
            }
        });
        findPreference(getString(R.string.settings_about_trading_key)).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                if (SettingsMainFragment.this.settingsMainActivity != null) {
                    Utils.showTradingDialog(getContext());
                }
                return true;
            }
        });
        findPreference(getString(R.string.settings_about_donate_key)).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                if (SettingsMainFragment.this.settingsMainActivity != null) {
                    Utils.showDonateDialog(getContext());
                }
                return true;
            }
        });
        findPreference(getString(R.string.settings_about_share_key)).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                SettingsMainFragment.startShareIntent(SettingsMainFragment.this.getActivity());
                return true;
            }
        });
        findPreference(getString(R.string.settings_about_rate_key)).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                Utils.goToGooglePlay(SettingsMainFragment.this.getActivity(), SettingsMainFragment.this.getActivity().getPackageName());
                return true;
            }
        });
        findPreference(getString(R.string.settings_about_changelog_key)).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                Utils.goToWebPage(getContext(),"https://github.com/tekkaadan/Amplify");
                return true;
            }
        });
        Preference aboutVersionPreference = findPreference(getString(R.string.settings_about_version_key));
        try {
            aboutVersionPreference.setTitle(getString(R.string.settings_about_version_title, getString(R.string.app_name), getActivity().getPackageManager().getPackageInfo(getActivity().getPackageName(), 0).versionName));

            aboutVersionPreference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                public boolean onPreferenceClick(Preference preference) {
                    Utils.sendEmail(SettingsMainFragment.this.getActivity(), "developer@tekhnical.com", "Amplify");
                    /*CustomDialog dialog = new CustomDialog(getContext());
                    dialog.setTitle(getString(R.string.settings_about_category_title));
                    dialog.setMessage(getString(R.string.settings_about_version_contact_dialog_text));
                    dialog.setPositiveButton(getString(R.string.settings_about_version_contact_dialog_button_email), new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                        }
                    });
                    dialog.show();*/
                    return true;
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void onCreateBeforeInitTTS(Bundle savedInstanceState) {
        super.onCreateBeforeInitTTS(savedInstanceState);

    }

    @Override
    public void onTTSAvailable(boolean available) {
        super.onTTSAvailable(available);
        if (getActivity() == null) {
        }
    }

    public static void startShareIntent(Context context) {
        Intent shareIntent = new Intent("android.intent.action.SEND");
        shareIntent.putExtra("android.intent.extra.TITLE", context.getString(R.string.app_name));
        shareIntent.putExtra("android.intent.extra.SUBJECT", context.getString(R.string.app_name));
        shareIntent.putExtra("android.intent.extra.TEXT", "https://play.google.com/store/apps/details?id=com.tekhnical.amplify");
        shareIntent.setType("text/plain");
        context.startActivity(Intent.createChooser(shareIntent, context.getString(R.string.settings_about_share_title)));
    }
}
