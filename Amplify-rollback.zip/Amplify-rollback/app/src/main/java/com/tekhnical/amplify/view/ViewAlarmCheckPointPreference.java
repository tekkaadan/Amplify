package com.tekhnical.amplify.view;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.Context;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.dialog.CustomDialog;
import com.tekhnical.amplify.model.CurrencySubunit;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.content.AlarmRecord;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.util.CurrencyUtils;
import com.tekhnical.amplify.util.FormatUtils;
import com.tekhnical.amplify.util.TickerUtils;
import com.tekhnical.amplify.util.Utils;
import com.tekhnical.amplify.view.generic.ViewDialogPreference;

public class ViewAlarmCheckPointPreference extends ViewDialogPreference {
    private AlarmRecord alarmRecord;
    private CheckerRecord checkerRecord;
    private OnCheckpointChangedListener onCheckpointChangedListener;
    private CurrencySubunit subunit;
    private String sufix;

    public interface OnCheckpointChangedListener {
        boolean onCheckpointChanged(ViewAlarmCheckPointPreference viewAlarmCheckPointPreference, Ticker ticker);
    }

    public ViewAlarmCheckPointPreference(Context context) {
        super(context);
    }

    public ViewAlarmCheckPointPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @TargetApi(11)
    public ViewAlarmCheckPointPreference(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public String getEntry() {
        Ticker lastCheckPointTicker = TickerUtils.fromJson(this.alarmRecord.getLastCheckPointTicker());
        if (lastCheckPointTicker != null) {
            return FormatUtils.formatPriceWithCurrency(lastCheckPointTicker.last, this.subunit) + " - " + FormatUtils.formatDateTime(getContext(), lastCheckPointTicker.timestamp);
        }
        return getContext().getString(R.string.checker_add_alarm_checkpoint_empty_text);
    }

    public void setCheckerAndAlarmRecord(CheckerRecord checkerRecord2, AlarmRecord alarmRecord2) {
        this.checkerRecord = checkerRecord2;
        this.subunit = CurrencyUtils.getCurrencySubunit(checkerRecord2.getCurrencyDst(), checkerRecord2.getCurrencySubunitDst());
        this.alarmRecord = alarmRecord2;
        setSummary(getEntry());
    }

    public void setSufix(String sufix2) {
        this.sufix = sufix2;
    }

    private void setValue(double value) {
        boolean isModyfied;
        Ticker lastCheckPointTicker = TickerUtils.fromJson(this.alarmRecord.getLastCheckPointTicker());
        if (value <= 0.0d) {
            isModyfied = lastCheckPointTicker != null;
            lastCheckPointTicker = null;
        } else if (lastCheckPointTicker != null) {
            isModyfied = lastCheckPointTicker.last != value;
        } else {
            lastCheckPointTicker = new Ticker();
            isModyfied = true;
        }
        if (isModyfied) {
            if (lastCheckPointTicker != null) {
                lastCheckPointTicker.last = value;
                lastCheckPointTicker.timestamp = System.currentTimeMillis();
            }
            if (this.onCheckpointChangedListener == null || this.onCheckpointChangedListener.onCheckpointChanged(this, lastCheckPointTicker)) {
            }
        }
        setSummary(getEntry());
    }

    private void resetCheckpointToLastCheck() {
        if ((TextUtils.isEmpty(this.alarmRecord.getLastCheckPointTicker()) && !TextUtils.isEmpty(this.checkerRecord.getLastCheckTicker())) || (!TextUtils.isEmpty(this.alarmRecord.getLastCheckPointTicker()) && !this.alarmRecord.getLastCheckPointTicker().equals(this.checkerRecord.getLastCheckTicker()))) {
            Ticker lastCheckPointTicker = TickerUtils.fromJson(this.checkerRecord.getLastCheckTicker());
            if (this.onCheckpointChangedListener == null || this.onCheckpointChangedListener.onCheckpointChanged(this, lastCheckPointTicker)) {
            }
        }
        setSummary(getEntry());
    }

    @Override
    public void onPrepareDialog(CustomDialog builder) {
        int i = 0;
        View view = LayoutInflater.from(getContext()).inflate(R.layout.alarm_checkpoint_dialog, null);
        final EditText valueView = (EditText) view.findViewById(R.id.valueView);
        valueView.addTextChangedListener(new TextWatcher() {
            int selectionEnd;
            int selectionStart;

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                this.selectionStart = valueView.getSelectionStart();
                this.selectionEnd = valueView.getSelectionEnd();
                valueView.removeTextChangedListener(this);
                if (s.toString().contains(",")) {
                    valueView.setText(s.toString().replace(',', '.'));
                }
                valueView.addTextChangedListener(this);
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void afterTextChanged(Editable s) {
                valueView.setSelection(this.selectionStart, this.selectionEnd);
            }
        });
        TextView sufixView = (TextView) view.findViewById(R.id.sufixView);
        View resetCheckpointButton = (TextView) view.findViewById(R.id.resetCheckpointButton);
        Ticker lastCheckPointTicker = TickerUtils.fromJson(this.alarmRecord.getLastCheckPointTicker());
        if (lastCheckPointTicker != null) {
            valueView.setText(FormatUtils.formatPriceValueForSubunit(lastCheckPointTicker.last, this.subunit, false, true).replace(',', '.'));
        } else {
            valueView.setText("");
        }
        if (TextUtils.isEmpty(this.checkerRecord.getLastCheckTicker())) {
            i = 8;
        }
        resetCheckpointButton.setVisibility(i);
        Utils.setSelectionAfterLastLetter(valueView);
        sufixView.setText(this.sufix);
        valueView.post(new Runnable() {
            public void run() {
                Utils.showKeyboard(ViewAlarmCheckPointPreference.this.getContext(), valueView);
            }
        });
        resetCheckpointButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                ViewAlarmCheckPointPreference.this.resetCheckpointToLastCheck();
                Dialog dialog = ViewAlarmCheckPointPreference.this.getDialog();
                if (dialog != null && dialog.isShowing()) {
                    dialog.dismiss();
                }
            }
        });
        builder.setPositiveButton(getResources().getString(R.string.ok), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.hideKeyboard(ViewAlarmCheckPointPreference.this.getContext(), valueView);
                try {
                    double newValue = Double.parseDouble(valueView.getText().toString().replace(',', '.'));
                    if (ViewAlarmCheckPointPreference.this.subunit != null) {
                        newValue /= (double) ViewAlarmCheckPointPreference.this.subunit.subunitToUnit;
                    }
                    ViewAlarmCheckPointPreference.this.setValue(newValue);
                } catch (Exception e) {
                    e.printStackTrace();
                    ViewAlarmCheckPointPreference.this.setValue(-1.0d);
                }
            }

        });
        builder.setNeutralButton(getResources().getString(R.string.cancel), new OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.dismiss();
            }
        });
        builder.setNegativeButton(getResources().getString(R.string.generic_remove), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewAlarmCheckPointPreference.this.setValue(-1.0d);
            }
        });
        builder.setView(view);
    }

    public void setOnCheckpointChangedListener(OnCheckpointChangedListener onCheckpointChangedListener2) {
        this.onCheckpointChangedListener = onCheckpointChangedListener2;
    }
}
