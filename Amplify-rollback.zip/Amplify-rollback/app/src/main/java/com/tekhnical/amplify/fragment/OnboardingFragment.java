package com.tekhnical.amplify.fragment;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.generic.OnboardingListener;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link OnboardingFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class OnboardingFragment extends Fragment {

    private static final String ARG_PARAM0 = "index";
    private static final String ARG_PARAM1 = "title";
    private static final String ARG_PARAM2 = "desc";
    private static final String ARG_PARAM3 = "icon";

    private String title, desc;
    private int icon, index;
    private OnboardingListener mListener;
    public OnboardingFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment OnboardingFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static OnboardingFragment newInstance(int param0, String param1, String param2, int param3) {
        OnboardingFragment fragment = new OnboardingFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        args.putInt(ARG_PARAM3, param3);
        args.putInt(ARG_PARAM0, param0);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            mListener = (OnboardingListener) context;
        } catch(ClassCastException e) {
            throw new ClassCastException("Activity must implement" + OnboardingListener.class.getSimpleName());
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            title = getArguments().getString(ARG_PARAM1);
            desc = getArguments().getString(ARG_PARAM2);
            icon = getArguments().getInt(ARG_PARAM3);
            index = getArguments().getInt(ARG_PARAM0);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_onboarding, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TextView titleView = view.findViewById(R.id.intro_title_tv);
        TextView descView = view.findViewById(R.id.intro_desc_tv);
        TextView skipView = view.findViewById(R.id.intro_skip_tv);
        ImageView iconView = view.findViewById(R.id.intro_iv);
        //LinearLayout nextButton = view.findViewById(R.id.next_button);
        titleView.setText(title);
        descView.setText(desc);
        iconView.setImageResource(icon);
        skipView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mListener != null){
                    mListener.changeView(3);
                }
            }
        });
        /*nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mListener != null){
                    mListener.changeView(++index);
                }
            }
        });*/
    }
}