package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class BitTrex extends Market {
    private static final String NAME = "BitTrex";
    private static final String TTS_NAME = "Bit Trex";
    private static final String URL = "https://bittrex.com/api/v1.1/public/getticker?market=%1$s-%2$s";
    private static final String URL_CURRENCY_PAIRS = "https://bittrex.com/api/v1.1/public/getmarkets";

    public BitTrex() {
        super("bittrex",NAME, TTS_NAME, null);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyCounter(), checkerInfo.getCurrencyBase()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Bittrex.png";
        //return "https://assets.coingecko.com/markets/images/10/small/BG-color-250x250_icon.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bittrex;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject resultJsonObject = jsonObject.getJSONObject("result");
        ticker.bid = ParseUtils.getDouble(resultJsonObject,"Bid");
        ticker.ask = ParseUtils.getDouble(resultJsonObject,"Ask");
        ticker.last = ParseUtils.getDouble(resultJsonObject,"Last");
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray resultJsonArray = jsonObject.getJSONArray("result");
        for (int i = 0; i < resultJsonArray.length(); i++) {
            JSONObject marketJsonObject = resultJsonArray.getJSONObject(i);
            if(marketJsonObject.has("MarketCurrency") && marketJsonObject.has("BaseCurrency") && marketJsonObject.has("MarketName")) {
                pairs.add(new CurrencyPairInfo(marketJsonObject.getString("MarketCurrency"), marketJsonObject.getString("BaseCurrency"), marketJsonObject.getString("MarketName")));
            }
        }
    }
}
