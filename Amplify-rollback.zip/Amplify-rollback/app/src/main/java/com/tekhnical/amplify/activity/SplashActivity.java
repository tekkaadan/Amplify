package com.tekhnical.amplify.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.config.MarketsConfig;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.ExchangeModel;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.util.PreferencesUtils;

import java.util.ArrayList;
import java.util.List;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            int theme = MyApplication.getAppTheme(this);
            if (theme == 3)
                setTheme(R.style.GrayTheme);
            else if (theme == 4)
                setTheme(R.style.SepiaTheme);
            else
                setTheme(R.style.AppTheme);
            super.onCreate(savedInstanceState);
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            //getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

            setContentView(R.layout.activity_splash);
        /*if (MyApplication.APP_THEME == 3)
            findViewById(R.id.splash_parent).setBackgroundResource(R.drawable.main_background_gray);
        else if (MyApplication.APP_THEME == 4)
            findViewById(R.id.splash_parent).setBackgroundResource(R.drawable.main_background_sepia);*/
            exit();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void exit() {
        Handler handler = new Handler();
        Runnable r = new Runnable() {
            public void run() {
                if(!PreferencesUtils.getUserHint(SplashActivity.this)) {
                    startActivity(new Intent(SplashActivity.this, OnboadingActivity.class));
                    finish();
                }else{
                    startActivity(new Intent(SplashActivity.this, CheckersListActivity.class));
                    finish();
                }
            }
        };
        handler.postDelayed(r, 2000);
    }
}
