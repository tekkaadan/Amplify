package com.tekhnical.amplify.content;

/* renamed from: com.tekhnical.amplify.db.content.MaindbContentProvider */
public class MaindbContentProvider extends AbstractMaindbContentProvider {
}
