package com.tekhnical.amplify.volley;

public interface CheckerRecordRequestIfc {
    long getCheckerRecordId();
}
