package com.tekhnical.amplify.content;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

import com.tekhnical.amplify.content.MaindbContract.Alarm;
import com.tekhnical.amplify.content.MaindbContract.Alarm.Builder;
import com.robotoworks.mechanoid.Mechanoid;
import com.robotoworks.mechanoid.db.AbstractValuesBuilder;
import com.robotoworks.mechanoid.db.ActiveRecord;
import com.robotoworks.mechanoid.db.ActiveRecordFactory;
import com.robotoworks.mechanoid.util.Closeables;

public class AlarmRecord extends ActiveRecord implements Parcelable {
    public static final Creator<AlarmRecord> CREATOR = new Creator<AlarmRecord>() {
        public AlarmRecord createFromParcel(Parcel in) {
            return new AlarmRecord(in);
        }

        public AlarmRecord[] newArray(int size) {
            return new AlarmRecord[size];
        }
    };
    public static String[] PROJECTION = {"_id", MaindbContract.AlarmColumns.CHECKER_ID, "enabled", MaindbContract.AlarmColumns.TYPE, MaindbContract.AlarmColumns.VALUE, MaindbContract.AlarmColumns.SOUND, MaindbContract.AlarmColumns.SOUND_URI, MaindbContract.AlarmColumns.VIBRATE, MaindbContract.AlarmColumns.LED, "ttsEnabled", "lastCheckPointTicker"};
    private static ActiveRecordFactory<AlarmRecord> sFactory = new ActiveRecordFactory<AlarmRecord>() {
        public AlarmRecord create(Cursor c) {
            return AlarmRecord.fromCursor(c);
        }

        public String[] getProjection() {
            return AlarmRecord.PROJECTION;
        }

        @Override
        public Uri getContentUri() {
            return null;
        }
    };
    private long mCheckerId;
    private boolean mCheckerIdDirty;
    private boolean mEnabled;
    private boolean mEnabledDirty;
    private String mLastCheckPointTicker;
    private boolean mLastCheckPointTickerDirty;
    private boolean mLed;
    private boolean mLedDirty;
    private boolean mSound;
    private boolean mSoundDirty;
    private String mSoundUri;
    private boolean mSoundUriDirty;
    private boolean mTtsEnabled;
    private boolean mTtsEnabledDirty;
    private long mType;
    private boolean mTypeDirty;
    private double mValue;
    private boolean mValueDirty;
    private boolean mVibrate;
    private boolean mVibrateDirty;

    public interface Indices {
        public static final int CHECKER_ID = 1;
        public static final int ENABLED = 2;
        public static final int LAST_CHECK_POINT_TICKER = 10;
        public static final int LED = 8;
        public static final int SOUND = 5;
        public static final int SOUND_URI = 6;
        public static final int TTS_ENABLED = 9;
        public static final int TYPE = 3;
        public static final int VALUE = 4;
        public static final int VIBRATE = 7;
        public static final int _ID = 0;
    }

    public static ActiveRecordFactory<AlarmRecord> getFactory() {
        return sFactory;
    }

    @Override
    public String[] _getProjection() {
        return PROJECTION;
    }

    public void setCheckerId(long checkerId) {
        this.mCheckerId = checkerId;
        this.mCheckerIdDirty = true;
    }

    public long getCheckerId() {
        return this.mCheckerId;
    }

    public void setEnabled(boolean enabled) {
        this.mEnabled = enabled;
        this.mEnabledDirty = true;
    }

    public boolean getEnabled() {
        return this.mEnabled;
    }

    public void setType(long type) {
        this.mType = type;
        this.mTypeDirty = true;
    }

    public long getType() {
        return this.mType;
    }

    public void setValue(double value) {
        this.mValue = value;
        this.mValueDirty = true;
    }

    public double getValue() {
        return this.mValue;
    }

    public void setSound(boolean sound) {
        this.mSound = sound;
        this.mSoundDirty = true;
    }

    public boolean getSound() {
        return this.mSound;
    }

    public void setSoundUri(String soundUri) {
        this.mSoundUri = soundUri;
        this.mSoundUriDirty = true;
    }

    public String getSoundUri() {
        return this.mSoundUri;
    }

    public void setVibrate(boolean vibrate) {
        this.mVibrate = vibrate;
        this.mVibrateDirty = true;
    }

    public boolean getVibrate() {
        return this.mVibrate;
    }

    public void setLed(boolean led) {
        this.mLed = led;
        this.mLedDirty = true;
    }

    public boolean getLed() {
        return this.mLed;
    }

    public void setTtsEnabled(boolean ttsEnabled) {
        this.mTtsEnabled = ttsEnabled;
        this.mTtsEnabledDirty = true;
    }

    public boolean getTtsEnabled() {
        return this.mTtsEnabled;
    }

    public void setLastCheckPointTicker(String lastCheckPointTicker) {
        this.mLastCheckPointTicker = lastCheckPointTicker;
        this.mLastCheckPointTickerDirty = true;
    }

    public String getLastCheckPointTicker() {
        return this.mLastCheckPointTicker;
    }

    public AlarmRecord() {
        super(Alarm.CONTENT_URI);
    }

    private AlarmRecord(Parcel in) {
        super(Alarm.CONTENT_URI);
        setId(in.readLong());
        this.mCheckerId = in.readLong();
        this.mEnabled = in.readInt() > 0;
        this.mType = in.readLong();
        this.mValue = in.readDouble();
        this.mSound = in.readInt() > 0;
        this.mSoundUri = in.readString();
        this.mVibrate = in.readInt() > 0;
        this.mLed = in.readInt() > 0;
        this.mTtsEnabled = in.readInt() > 0;
        this.mLastCheckPointTicker = in.readString();
        boolean[] dirtyFlags = new boolean[10];
        in.readBooleanArray(dirtyFlags);
        this.mCheckerIdDirty = dirtyFlags[0];
        this.mEnabledDirty = dirtyFlags[1];
        this.mTypeDirty = dirtyFlags[2];
        this.mValueDirty = dirtyFlags[3];
        this.mSoundDirty = dirtyFlags[4];
        this.mSoundUriDirty = dirtyFlags[5];
        this.mVibrateDirty = dirtyFlags[6];
        this.mLedDirty = dirtyFlags[7];
        this.mTtsEnabledDirty = dirtyFlags[8];
        this.mLastCheckPointTickerDirty = dirtyFlags[9];
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(getId());
        dest.writeLong(this.mCheckerId);
        dest.writeInt(this.mEnabled ? 1 : 0);
        dest.writeLong(this.mType);
        dest.writeDouble(this.mValue);
        dest.writeInt(this.mSound?1:0);
        dest.writeString(this.mSoundUri);
        dest.writeInt(this.mVibrate?1:0);
        dest.writeInt(this.mLed?1:0);
        dest.writeInt(this.mTtsEnabled?1:0);
        dest.writeString(this.mLastCheckPointTicker);
        dest.writeBooleanArray(new boolean[]{this.mCheckerIdDirty, this.mEnabledDirty, this.mTypeDirty, this.mValueDirty, this.mSoundDirty, this.mSoundUriDirty, this.mVibrateDirty, this.mLedDirty, this.mTtsEnabledDirty, this.mLastCheckPointTickerDirty});
    }

    @Override
    public AbstractValuesBuilder createBuilder() {
        Builder builder = Alarm.newBuilder();
        if (this.mCheckerIdDirty) {
            builder.setCheckerId(this.mCheckerId);
        }
        if (this.mEnabledDirty) {
            builder.setEnabled(this.mEnabled);
        }
        if (this.mTypeDirty) {
            builder.setType(this.mType);
        }
        if (this.mValueDirty) {
            builder.setValue(this.mValue);
        }
        if (this.mSoundDirty) {
            builder.setSound(this.mSound);
        }
        if (this.mSoundUriDirty) {
            builder.setSoundUri(this.mSoundUri);
        }
        if (this.mVibrateDirty) {
            builder.setVibrate(this.mVibrate);
        }
        if (this.mLedDirty) {
            builder.setLed(this.mLed);
        }
        if (this.mTtsEnabledDirty) {
            builder.setTtsEnabled(this.mTtsEnabled);
        }
        if (this.mLastCheckPointTickerDirty) {
            builder.setLastCheckPointTicker(this.mLastCheckPointTicker);
        }
        return builder;
    }

    public void makeDirty(boolean dirty) {
        this.mCheckerIdDirty = dirty;
        this.mEnabledDirty = dirty;
        this.mTypeDirty = dirty;
        this.mValueDirty = dirty;
        this.mSoundDirty = dirty;
        this.mSoundUriDirty = dirty;
        this.mVibrateDirty = dirty;
        this.mLedDirty = dirty;
        this.mTtsEnabledDirty = dirty;
        this.mLastCheckPointTickerDirty = dirty;
    }

    @Override
    public void setPropertiesFromCursor(Cursor c) {
        boolean z4 = true;
        setId(c.getLong(Indices._ID));
        setCheckerId(c.getLong(Indices.CHECKER_ID));
        setEnabled(c.getInt(Indices.ENABLED) > 0);
        setType(c.getLong(Indices.TYPE));
        setValue(c.getDouble(Indices.VALUE));
        setSound(c.getInt(Indices.SOUND) > 0);
        setSoundUri(c.getString(Indices.SOUND_URI));
        setVibrate(c.getInt(Indices.VIBRATE) > 0);
        setLed(c.getInt(Indices.LED) > 0);
        setTtsEnabled(c.getInt(Indices.TTS_ENABLED) > 0);
        setLastCheckPointTicker(c.getString(Indices.LAST_CHECK_POINT_TICKER));
    }

    public static AlarmRecord fromCursor(Cursor c) {
        AlarmRecord item = new AlarmRecord();
        item.setPropertiesFromCursor(c);
        item.makeDirty(false);
        return item;
    }

    public static AlarmRecord fromBundle(Bundle bundle, String key) {
        bundle.setClassLoader(AlarmRecord.class.getClassLoader());
        return (AlarmRecord) bundle.getParcelable(key);
    }

    public static AlarmRecord get(long id) {
        Cursor c = null;
        try {
            c = Mechanoid.getContentResolver().query(Alarm.CONTENT_URI.buildUpon().appendPath(String.valueOf(id)).build(), PROJECTION, null, null, null);
            if (!c.moveToFirst()) {
                Closeables.closeSilently(c);
                return null;
            }
            AlarmRecord fromCursor = fromCursor(c);
            Closeables.closeSilently(c);
            return fromCursor;
        } catch (Throwable th) {
            Closeables.closeSilently(c);
            throw th;
        }
    }
}
