package com.tekhnical.amplify.adapter;

import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckedTextView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.ExchangeModel;
import com.tekhnical.amplify.model.StockSearchModel;

import java.util.ArrayList;

public class StockPickerAdapter extends RecyclerView.Adapter<StockPickerAdapter.ViewHolder> {

    private ArrayList<ExchangeModel> stockList;
    private final String selectedMarketKey;
    private OnStockSelectedListener mListener;
    public StockPickerAdapter(ArrayList<ExchangeModel> list, String selectedMarket, OnStockSelectedListener listener ){
        selectedMarketKey = selectedMarket;
        stockList = list;
        mListener = listener;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.market_picker_list_singlechoice,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ExchangeModel searchModel = stockList.get(position);
        holder.marketNameView.setText(searchModel.getSymbol());
        holder.pickerItemLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.onStockSelected(searchModel);
            }
        });
        if (searchModel.getSymbol().equals(selectedMarketKey)){
            holder.checkedView.setChecked(true);
            TypedValue value = new TypedValue();
            holder.itemView.getContext().getTheme().resolveAttribute(R.attr.selectableItemBackground, value, true);
            holder.checkedView.setCheckMarkDrawable(value.resourceId);
        }else{
            holder.checkedView.setChecked(false);
        }
    }

    @Override
    public int getItemCount() {
        return stockList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView marketNameView;
        private CheckedTextView checkedView;
        private LinearLayout pickerItemLayout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            marketNameView = itemView.findViewById(R.id.marketNameView);
            checkedView = itemView.findViewById(R.id.singleCheckView);
            pickerItemLayout = itemView.findViewById(R.id.market_picker_item_layout);
        }
    }
    public interface OnStockSelectedListener{
        public void onStockSelected(ExchangeModel model);
    }
}
