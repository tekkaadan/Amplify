package com.tekhnical.amplify.fragment;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.cardview.widget.CardView;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.view.generic.ViewSpinnerPreference;

import java.lang.reflect.Field;

public class SpinnerDialogFragment extends BottomSheetDialogFragment {

    private ListView spinnerList;
    private SearchView searchView;
    private ViewSpinnerPreference.ItemClickListener listener;
    private String[] entries;

    public static SpinnerDialogFragment getInstance(String[] entries, ViewSpinnerPreference.ItemClickListener itemClickListener) {
        SpinnerDialogFragment fragment = new SpinnerDialogFragment();
        fragment.listener = itemClickListener;
        Bundle bundle = new Bundle();
        bundle.putStringArray("DATA", entries);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setCancelable(true);
        //setStyle(STYLE_NORMAL,R.style.Theme_AppCompat_Dialog);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        BottomSheetDialog bottomSheetDialog = (BottomSheetDialog) super.onCreateDialog(savedInstanceState);
        bottomSheetDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                try {
                    View bottomSheet = bottomSheetDialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
                    BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
                    if (bottomSheetBehavior == null) {

                        Field behaviorField = bottomSheetDialog.getClass().getDeclaredField("behavior");
                        behaviorField.setAccessible(true);
                        bottomSheetBehavior = (BottomSheetBehavior) behaviorField.get(bottomSheetDialog);
                    }
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                    BottomSheetBehavior finalBottomSheetBehavior = bottomSheetBehavior;
                    bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {

                        @Override
                        public void onStateChanged(@NonNull View bottomSheet, int newState) {
                            if (newState == BottomSheetBehavior.STATE_DRAGGING) {
                                finalBottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                            }
                        }

                        @Override
                        public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                    FirebaseCrashlytics.getInstance().recordException(e);
                }
            }
        });
        return bottomSheetDialog;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        entries = getArguments() != null ? getArguments().getStringArray("DATA") : new String[0];
        View view = inflater.inflate(R.layout.dialog_spinner_fragment, container, false);
        /*final BottomSheetBehavior behavior = BottomSheetBehavior.from((View) view.getParent());
        behavior.setHideable(false);
        behavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                if (newState == BottomSheetBehavior.STATE_HIDDEN) {
                    dismiss();
                }

                if (newState == BottomSheetBehavior.STATE_DRAGGING) {
                    if(!spinnerList.canScrollVertically(1)) {
                        behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                    }
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                //behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
            }
        });*/
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        spinnerList = view.findViewById(R.id.spinner_list);
        searchView = view.findViewById(R.id.search_view);
        Button closeBtn = view.findViewById(R.id.close_btn);
        CardView searchCv = view.findViewById(R.id.search_cv);
        int theme = MyApplication.getAppTheme(getContext());
        if (theme == 3) {
            view.findViewById(R.id.spinner_parent).setBackgroundResource(R.drawable.list_background_gray);
            searchCv.setCardBackgroundColor(getResources().getColor(R.color.theme_gray_light));
            closeBtn.setBackgroundResource(R.drawable.dialog_button_gray);
        }
        else if (theme == 4) {
            view.findViewById(R.id.spinner_parent).setBackgroundResource(R.drawable.list_background_sepia);
            searchCv.setCardBackgroundColor(getResources().getColor(R.color.theme_sepia_light));
            closeBtn.setBackgroundResource(R.drawable.dialog_button_sepia);
        }

        closeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        searchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchView.setIconified(false);
            }
        });
        if (getContext()!=null && entries!=null) {
            ArrayAdapter adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_selectable_list_item, entries);
            spinnerList.setAdapter(adapter);
            spinnerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if(listener != null) {
                        listener.OnItemClick((String) spinnerList.getItemAtPosition(position));
                        dismiss();
                    }
                }
            });
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    adapter.getFilter().filter(query);
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    adapter.getFilter().filter(newText);
                    return false;
                }
            });
        }
    }

}
