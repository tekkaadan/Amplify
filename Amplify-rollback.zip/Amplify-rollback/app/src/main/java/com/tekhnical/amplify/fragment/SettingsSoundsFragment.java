package com.tekhnical.amplify.fragment;

import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.preference.ListPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceCategory;

import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.preference.PreferenceFragmentCompat;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.util.PreferencesUtils;
import com.tekhnical.amplify.util.Utils;

public class SettingsSoundsFragment extends PreferenceFragmentCompat {
    private static final int REQUEST_CODE_ALERT_RINGTONE = 101;
    private int onRingtoneClick = 0;
    private Preference alarmNotificationUpPreference, alarmNotificationDownPreference;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);
        //view.setBackgroundColor(getResources().getColor(R.color.background));
        return view;
    }
    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.settings_sounds,rootKey);
        alarmNotificationUpPreference  =  findPreference(getString(R.string.settings_sounds_alarm_notification_up_key));
        //alarmNotificationUpPreference.setLayoutResource(R.layout.preference_view);
        //alarmNotificationUpPreference.setKey(getString(R.string.settings_sounds_alarm_notification_up_key));
        //alarmNotificationUpPreference.setTitle(R.string.settings_sounds_alarm_notification_up_title);
        //alarmNotificationUpPreference.setRingtoneType(2);
        if (alarmNotificationUpPreference != null) {
            alarmNotificationUpPreference.setSummary(getRingtoneName(PreferencesUtils.getSoundAlarmNotificationUp(getActivity())));
            alarmNotificationUpPreference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                @Override
                public boolean onPreferenceClick(Preference preference) {
                    onRingtoneClick = 1;
                    ringtoneChooser((String) alarmNotificationUpPreference.getSummary());
                    return true;
                }
            });
            alarmNotificationUpPreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    alarmNotificationUpPreference.setSummary(SettingsSoundsFragment.this.getRingtoneName((String) newValue));
                    return true;
                }
            });
        }

        alarmNotificationDownPreference =  findPreference(getString(R.string.settings_sounds_alarm_notification_down_key));
        //alarmNotificationDownPreference.setLayoutResource(R.layout.preference_view);
        //alarmNotificationDownPreference.setKey(getString(R.string.settings_sounds_alarm_notification_down_key));
        //alarmNotificationDownPreference.setTitle(R.string.settings_sounds_alarm_notification_down_title);
        //alarmNotificationDownPreference.setRingtoneType(2);
        if (alarmNotificationDownPreference != null) {
            alarmNotificationDownPreference.setSummary(getRingtoneName(PreferencesUtils.getSoundAlarmNotificationDown(getActivity())));
            alarmNotificationDownPreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    alarmNotificationDownPreference.setSummary(SettingsSoundsFragment.this.getRingtoneName((String) newValue));
                    return true;
                }
            });
            alarmNotificationDownPreference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                @Override
                public boolean onPreferenceClick(Preference preference) {
                    onRingtoneClick = 2;
                    ringtoneChooser((String) alarmNotificationDownPreference.getSummary());
                    return true;
                }
            });
        }


        //PreferenceCategory alarmNotificationCategory = (PreferenceCategory) findPreference(getString(R.string.settings_sounds_alarm_notification_category_key));
        //alarmNotificationCategory.addPreference(alarmNotificationUpPreference);
        //alarmNotificationCategory.addPreference(alarmNotificationDownPreference);
        final ListPreference advancedAlarmStreamPreference = (ListPreference) findPreference(getString(R.string.settings_sounds_advanced_alarm_stream_key));
        if (advancedAlarmStreamPreference!=null ) {
            //advancedAlarmStreamPreference.setSummary(advancedAlarmStreamPreference.getEntry());
            advancedAlarmStreamPreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                @Override
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    return Utils.handleIntListOnPreferenceChange(advancedAlarmStreamPreference, newValue);
                }
            });
        }
    }

    private void ringtoneChooser(String existingValue){
        if(getActivity()!=null && Utils.checkStoragePermission(getActivity())) {
            Intent intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true);
            intent.putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, Settings.System.DEFAULT_NOTIFICATION_URI);

            //String existingValue = getRingtonePreferenceValue(); // TODO
            if (existingValue != null) {
                if (existingValue.length() == 0) {
                    // Select "Silent"
                    intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, (Uri) null);
                } else {
                    intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(existingValue));
                }
            } else {
                // No ringtone has been selected, set to the default
                intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Settings.System.DEFAULT_NOTIFICATION_URI);
            }

            startActivityForResult(intent, REQUEST_CODE_ALERT_RINGTONE);

        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_ALERT_RINGTONE && data != null) {
            Uri ringtone = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            if (ringtone != null) {
                if (onRingtoneClick == 1) {
                    PreferencesUtils.setSoundAlarmNotificationUp(getContext(), ringtone.toString());
                    if (alarmNotificationUpPreference != null) {
                        alarmNotificationUpPreference.setSummary(getRingtoneName(ringtone.toString()));
                    }
                }
                else {
                    PreferencesUtils.setSoundAlarmNotificationDown(getContext(), ringtone.toString());
                    if (alarmNotificationDownPreference != null) {
                        alarmNotificationDownPreference.setSummary(getRingtoneName(ringtone.toString()));
                    }
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
    private String getRingtoneName(String ringtoneUriString) {
        if (ringtoneUriString != null) {
            Uri ringtoneUri = Uri.parse(ringtoneUriString);
            if (ringtoneUri != null) {
                Ringtone ringtone = RingtoneManager.getRingtone(getActivity(), ringtoneUri);
                if (ringtone != null) {
                    return ringtone.getTitle(getActivity());
                }
            }
        }
        return "";
    }
}
