package com.tekhnical.amplify.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.NetworkInfo;
import com.tekhnical.amplify.fragment.CheckersListFragment;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.content.MaindbContract;
import com.tekhnical.amplify.content.MaindbContract.Checker;
import com.tekhnical.amplify.util.PreferencesUtils;
import com.robotoworks.mechanoid.db.SQuery;
import com.robotoworks.mechanoid.db.SQuery.Op;

import java.util.List;

public class MyHelperEventsReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        if ("android.intent.action.BOOT_COMPLETED".equals(intent.getAction())) {
            MarketChecker.resetAlarmManager(context);
            MarketChecker.resetAlarmManagerForFearIndex(context, true);
        } else if ("android.net.conn.CONNECTIVITY_CHANGE".equals(intent.getAction())) {
            try {
                NetworkInfo activeNetwork = (NetworkInfo) intent.getParcelableExtra("networkInfo");
                if (activeNetwork != null && activeNetwork.isConnectedOrConnecting()) {
                    long now = System.currentTimeMillis();
                    List<CheckerRecord> list = SQuery.newQuery().expr("enabled", Op.EQ, true).and().append("((lastCheckDate > " + Long.toString(now) + ") OR (" + MaindbContract.CheckerColumns.FREQUENCY + Op.EQ + -1 + " AND " + MaindbContract.CheckerColumns.LAST_CHECK_DATE + Op.LT + Long.toString(now - PreferencesUtils.getCheckGlobalFrequency(context)) + ") OR (" + MaindbContract.CheckerColumns.FREQUENCY + " <> " + -1 + " AND " + MaindbContract.CheckerColumns.LAST_CHECK_DATE + Op.LT + Long.toString(now) + "-" + MaindbContract.CheckerColumns.FREQUENCY + "))", new String[0]).select(Checker.CONTENT_URI, CheckersListFragment.getSortOrderString(context));
                    for (CheckerRecord checkerRecord : list) {
                        MarketChecker.checkMarketAsyncForCheckerRecord(context, checkerRecord);
                    }
                }
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }
    }
}
