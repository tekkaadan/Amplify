package com.tekhnical.amplify.util;

import android.content.Context;
import com.tekhnical.amplify.alarm.AlarmKlaxonHelper;
import com.tekhnical.amplify.appwidget.WidgetProvider;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.content.AlarmRecord;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.content.MaindbContract;
import com.tekhnical.amplify.content.MaindbContract.Alarm;
import com.tekhnical.amplify.receiver.MarketChecker;
import com.robotoworks.mechanoid.db.SQuery;
import com.robotoworks.mechanoid.db.SQuery.Op;
import java.util.List;

public class CheckerRecordHelper {
    public static CheckerInfo createCheckerInfo(CheckerRecord checkerRecord) {
        return new CheckerInfo(checkerRecord.getCurrencySrc(), checkerRecord.getCurrencyDst(), checkerRecord.getCurrencyPairId(), (int) checkerRecord.getContractType());
    }

    public static final void doAfterEdit(Context context, CheckerRecord checkerRecord, boolean updateWidget) {
        MarketChecker.cancelCheckingForCheckerRecord(checkerRecord.getId());
        MarketChecker.resetAlarmManagerForChecker(context.getApplicationContext(), checkerRecord, true);
        if (!checkerRecord.getEnabled()) {
            NotificationUtils.clearNotificationsForCheckerRecord(context, checkerRecord);
        }
        if (updateWidget) {
            WidgetProvider.refreshWidget(context.getApplicationContext());
        }
        context.sendBroadcast(AlarmKlaxonHelper.createAlarmKlaxonDismissIntent(context, checkerRecord.getId(), -1));
    }

    public static final void doBeforeDelete(Context context, CheckerRecord checkerRecord) {
        checkerRecord.setEnabled(false);
        doAfterEdit(context, checkerRecord, false);
        Alarm.delete("checkerId = ?", new String[]{String.valueOf(checkerRecord.getId())});
    }

    public static final void doAfterDelete(Context context, CheckerRecord checkerRecord) {
        NotificationUtils.clearNotificationsForCheckerRecord(context,checkerRecord);
        WidgetProvider.refreshWidget(context.getApplicationContext());
    }

    public static List<AlarmRecord> getAlarmsForCheckerRecord(CheckerRecord checkerRecord, boolean enabledOnly) {
        return getAlarmsForCheckerRecord(checkerRecord.getId(), enabledOnly);
    }

    private static List<AlarmRecord> getAlarmsForCheckerRecord(long checkerRecordId, boolean enabledOnly) {
        SQuery sQuery = SQuery.newQuery().expr(MaindbContract.AlarmColumns.CHECKER_ID, Op.EQ, checkerRecordId);
        if (enabledOnly) {
            sQuery.and().expr("enabled", Op.EQ, true);
        }
        return sQuery.select(Alarm.CONTENT_URI);
    }

    public static List<Long> getAlarmsIdsForCheckerRecord(long checkerRecordId) {
        return SQuery.newQuery().expr(MaindbContract.AlarmColumns.CHECKER_ID, Op.EQ, checkerRecordId).selectLongList(Alarm.CONTENT_URI, "_id");
    }

    public static long getDisplayedFrequency(Context context, CheckerRecord checkerRecord) {
        if (checkerRecord.getFrequency() <= -1) {
            return PreferencesUtils.getCheckGlobalFrequency(context);
        }
        return checkerRecord.getFrequency();
    }
}
