package com.tekhnical.amplify.activity;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.drawerlayout.widget.DrawerLayout;

import butterknife.ButterKnife;
import butterknife.BindView;

import com.elconfidencial.bubbleshowcase.BubbleShowCase;
import com.elconfidencial.bubbleshowcase.BubbleShowCaseBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.generic.SimpleFragmentActivity;
import com.tekhnical.amplify.appwidget.WidgetProvider;
import com.tekhnical.amplify.dialog.CustomDialog;
import com.tekhnical.amplify.fragment.HomeFragment;
import com.tekhnical.amplify.receiver.MarketChecker;
import com.tekhnical.amplify.util.PreferencesUtils;
import com.tekhnical.amplify.util.Utils;
import com.tjeannin.apprate.AppRate;

public class CheckersListActivity extends SimpleFragmentActivity<HomeFragment> {
    @BindView(R.id.drawerItem)
    ImageView drawerItem;
    @BindView(R.id.refreshItem)
    ImageView refreshItem;
    @BindView(R.id.main_drawer_layout)
    DrawerLayout mDrawer;
    @BindView(R.id.drawer_version_tv)
    TextView appVersionTv;
    @BindView(R.id.spot_iv)
    ImageView spotDefaultIv;
    @BindView(R.id.futures_iv)
    ImageView futuresDefaultIv;
    @BindView(R.id.stocks_iv)
    ImageView stockDefaultIv;
    @BindView(R.id.portfolio_iv)
    ImageView portfolioDefaultIv;
    private boolean wasDialogShown;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.setContentTheme(false);
        super.onCreate(savedInstanceState);
        ButterKnife.bind((Activity) this);

        if (savedInstanceState == null) {
            WidgetProvider.refreshWidget(this);
            MarketChecker.checkIfAlarmsAreSet(this);
        }
        setDrawer();
        showIntro(savedInstanceState);
        showAppRate();
        /*addCheckerFab.setVisibility(View.VISIBLE);
        addCheckerFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckerAddActivity.startCheckerAddActivity(CheckersListActivity.this, null);
            }
        });*/
        /*settingsItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SettingsMainActivity.startSettingsMainActivity(CheckersListActivity.this, false);
            }
        });*/
    }
    private void showIntro(Bundle savedInstanceState){
        int donateCount = PreferencesUtils.wasDonateShown(this);
        this.wasDialogShown = savedInstanceState != null ? savedInstanceState.getBoolean("wasDialogShown") : false;
        if (!this.wasDialogShown) {
            Log.e("LIST",PreferencesUtils.wasNewsShown(this, 3)+" "+wasDialogShown);
            if (!PreferencesUtils.isDefaultItemAdded(this)) {
                CustomDialog dialog = new CustomDialog(this);
                dialog.setCancelable(false);
                dialog.setTitle(getResources().getString(R.string.checkers_list_first_time_dialog_title));
                dialog.setMessage(getResources().getString(R.string.checkers_list_first_time_dialog_message));
                dialog.setPositiveButton(getResources().getString(R.string.checkers_list_add_title), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        CheckersListActivity.this.wasDialogShown = true;
                        MyApplication.appMarketType = 0;
                        CheckerAddActivity.startCheckerAddActivity(CheckersListActivity.this, null);
                    }
                });
                dialog.show();
            } else if (!PreferencesUtils.wasNewsShown(this, 3)) {
                CustomDialog dialog = new CustomDialog(this);
                dialog.setCancelable(false);
                dialog.setTitle(getResources().getString(R.string.checker_add_exchange_tutorial2_title));
                dialog.setMessage(getResources().getString(R.string.checker_add_exchange_tutorial2_text));
                dialog.setPositiveButton(getResources().getString(R.string.ok), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        CheckersListActivity.this.wasDialogShown = true;
                        PreferencesUtils.setNewsShown(CheckersListActivity.this, 3);
                    }
                });
                dialog.show();
            }else if (donateCount == 4){
                Utils.showDonateDialog(this);
            }
            PreferencesUtils.setDonateShown(this,++donateCount);
        }
    }
    private void showAppRate(){
        try {
            String appName = getString(R.string.app_name);
            AppRate appRate = new AppRate(this).setShowIfAppHasCrashed(false).setMinDaysUntilPrompt(4).setMinLaunchesUntilPrompt(10);
            appRate.setCustomDialog(new Builder(this).setTitle(getString(R.string.rate_app_title, new Object[]{appName})).setMessage(getResources().getText(R.string.rate_app_text, appName)).setPositiveButton(R.string.rate_app_positive, appRate).setNeutralButton(R.string.rate_app_neutral, appRate).setNegativeButton(R.string.rate_app_negative, appRate).setOnCancelListener(appRate));
            appRate.init();
        }catch (Exception e){
            e.printStackTrace();
            FirebaseCrashlytics.getInstance().recordException(e);
        }
    }
    private void showHint() {
        if (!PreferencesUtils.getUserDefaultHint(this)) {
            new BubbleShowCaseBuilder(this) //Activity instance
                    .title(getString(R.string.information)) //Any title for the bubble view
                    .description(getString(R.string.drawer_hint)) //More detailed description
                    .arrowPosition(BubbleShowCase.ArrowPosition.TOP) //You can force the position of the arrow to change the location of the bubble.
                    .backgroundColor(getResources().getColor(R.color.background)) //Bubble background color
                    .textColor(getResources().getColor(R.color.textPrimaryColor)) //Bubble Text color
                    .titleTextSize(16) //Title text size in SP (default value 16sp)
                    .descriptionTextSize(14) //Subtitle text size in SP (default value 14sp)
                    .image(getResources().getDrawable(R.drawable.amplify_icon)) //Bubble main image
                    .showOnce(PreferencesUtils.USER_DEFAULT_HINT_KEY) //Id to show only once the BubbleShowCase
                    .targetView(findViewById(R.id.drawerItem)) //View to point out
                    .show();
            PreferencesUtils.setUserDefaultHint(this,true);
        }
    }

    private void setDrawer() {
        drawerItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mDrawer.isDrawerOpen(Gravity.RIGHT)){
                    mDrawer.closeDrawer(Gravity.RIGHT);
                }
                else{
                    mDrawer.openDrawer(Gravity.RIGHT);
                    showHint();
                }
            }
        });
        refreshItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyApplication.isRefresh = MyApplication.appMarketType;
                refreshAll();
            }
        });
        try {
            appVersionTv.setText(getString(R.string.settings_about_version,getPackageManager().getPackageInfo(getPackageName(), 0).versionName));
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        setDefault(PreferencesUtils.getUserDefault(CheckersListActivity.this));
        LinearLayout cryptoSpot = findViewById(R.id.action_menu_spot);
        LinearLayout cryptoFuture = findViewById(R.id.action_menu_future);
        LinearLayout stocks = findViewById(R.id.action_menu_stock);
        LinearLayout portfolio = findViewById(R.id.action_menu_portfolio);
        LinearLayout settings = findViewById(R.id.action_menu_setting);

        cryptoSpot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getChildFragment().homePager.setCurrentItem(0,true);
                mDrawer.closeDrawer(Gravity.RIGHT);
            }
        });
        cryptoSpot.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Utils.vibrate(CheckersListActivity.this);
                setDefault(1);
                PreferencesUtils.setUserDefault(CheckersListActivity.this,1);
                return true;
            }
        });
        cryptoFuture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getChildFragment().homePager.setCurrentItem(1, true);
                mDrawer.closeDrawer(Gravity.RIGHT);
            }
        });
        cryptoFuture.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Utils.vibrate(CheckersListActivity.this);
                setDefault(2);
                PreferencesUtils.setUserDefault(CheckersListActivity.this,2);
                return true;
            }
        });
        stocks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getChildFragment().homePager.setCurrentItem(2, true);
                mDrawer.closeDrawer(Gravity.RIGHT);
            }
        });
        stocks.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Utils.vibrate(CheckersListActivity.this);
                setDefault(3);
                PreferencesUtils.setUserDefault(CheckersListActivity.this,3);
                return true;
            }
        });
        portfolio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getChildFragment().homePager.setCurrentItem(3, true);
                mDrawer.closeDrawer(Gravity.RIGHT);
            }
        });
        portfolio.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Utils.vibrate(CheckersListActivity.this);
                setDefault(0);
                PreferencesUtils.setUserDefault(CheckersListActivity.this,0);
                return true;
            }
        });
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SettingsMainActivity.startSettingsMainActivity(CheckersListActivity.this, false);
                mDrawer.closeDrawer(Gravity.RIGHT);
            }
        });
    }

    private void setDefault(int userDefault){
        switch (userDefault){
            case 1:
                spotDefaultIv.setVisibility(View.VISIBLE);
                futuresDefaultIv.setVisibility(View.GONE);
                stockDefaultIv.setVisibility(View.GONE);
                portfolioDefaultIv.setVisibility(View.GONE);
                break;
            case 2:
                spotDefaultIv.setVisibility(View.GONE);
                futuresDefaultIv.setVisibility(View.VISIBLE);
                stockDefaultIv.setVisibility(View.GONE);
                portfolioDefaultIv.setVisibility(View.GONE);
                break;
            case 3:
                spotDefaultIv.setVisibility(View.GONE);
                futuresDefaultIv.setVisibility(View.GONE);
                stockDefaultIv.setVisibility(View.VISIBLE);
                portfolioDefaultIv.setVisibility(View.GONE);
                break;
            default:
                spotDefaultIv.setVisibility(View.GONE);
                futuresDefaultIv.setVisibility(View.GONE);
                stockDefaultIv.setVisibility(View.GONE);
                portfolioDefaultIv.setVisibility(View.VISIBLE);
                break;
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        refreshAll();
        if (MyApplication.reCreate) {
            Log.e("RESUME","RECREATE");
            MyApplication.reCreate = false;
            recreate();
        }
    }

    private void refreshAll(){
        if (getChildFragment()!=null)
            getChildFragment().setPager();
    }

    @Override
    public void onStart() {
        super.onStart();
        //this.donateBar.setVisibility(PreferencesUtils.getDonationMade(this) ? View.GONE : View.VISIBLE);
    }

    @Override
    public int getContentViewResId() {
        return R.layout.checkers_list_activity;
    }

    @Override
    public HomeFragment createChildFragment() {
        return new HomeFragment();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        outState.putBoolean("wasDialogShown", this.wasDialogShown);
        super.onSaveInstanceState(outState);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() != R.id.settingsItem) {
            return super.onOptionsItemSelected(item);
        }
        SettingsMainActivity.startSettingsMainActivity(this, false);
        return true;
    }
}
