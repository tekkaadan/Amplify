package com.tekhnical.amplify.view.generic;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.util.AttributeSet;
import android.widget.CheckBox;
import android.widget.CompoundButton;

import com.tekhnical.amplify.R;

public class ViewCheckBoxPreference extends ViewTwoStatePreference {
    public ViewCheckBoxPreference(Context context) {
        super(context);
    }

    public ViewCheckBoxPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @TargetApi(11)
    public ViewCheckBoxPreference(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    public CheckBox createCompoundButton() {
        CheckBox checkBox = new CheckBox(getContext());
        checkBox.setTextColor(getContext().getResources().getColor(R.color.textPrimaryColor));
        //checkBox.setButtonTintList(ColorStateList.valueOf(getContext().getResources().getColor(R.color.colorPrimary)));
        checkBox.setButtonDrawable(R.drawable.switch_drawable);
        checkBox.setClickable(false);
        return checkBox;
    }
}
