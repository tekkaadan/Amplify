package com.tekhnical.amplify.volley;

import android.text.TextUtils;
import android.util.Log;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.ParseError;
import com.android.volley.RequestQueue;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.toolbox.RequestFuture;
import com.tekhnical.amplify.config.MarketsConfig;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.CheckerRecordHelper;
import com.tekhnical.amplify.util.MarketsConfigUtils;
import com.tekhnical.amplify.util.RetrofitClient;
import com.tekhnical.amplify.util.TickerUtils;
import com.tekhnical.amplify.volley.generic.GenericVolleyAsyncTask;
import com.tekhnical.amplify.volley.generic.GzipVolleyStringRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.ExecutionException;

public class CheckerTotalVolleyAsyncTask extends GenericVolleyAsyncTask<Ticker> implements CheckerRecordRequestIfc {
    private static final ArrayList<CheckerTotalVolleyAsyncTask> CHECKERS_TASKS = new ArrayList<>();
    protected final CheckerInfo checkerInfo;
    private final CheckerRecord checkerRecord;

    public CheckerTotalVolleyAsyncTask(RequestQueue requestQueue, CheckerRecord checkerRecord2, Listener<Ticker> listener, ErrorListener errorListener) {
        super(requestQueue, listener, errorListener);
        this.checkerRecord = checkerRecord2;
        this.checkerInfo = CheckerRecordHelper.createCheckerInfo(checkerRecord2);
    }

    public long getCheckerRecordId() {
        if (this.checkerRecord != null) {
            return this.checkerRecord.getId();
        }
        return -1;
    }

    @Override
    public void onPreExecute() {
        super.onPreExecute();
        if (CHECKERS_TASKS != null) {
            CHECKERS_TASKS.add(this);
        }
    }

    @Override
    public Object doNetworkInBackground() {
        Market market = MarketsConfigUtils.getMarketByKey(this.checkerRecord.getMarketKey());
        String responseString = null;
        Ticker ticker = null;
        RequestFuture<String> future = RequestFuture.newFuture();
        ticker = new Ticker();
        Ticker tempTicker = TickerUtils.fromJson(checkerRecord.getLastCheckTicker());
        if (checkerRecord.getMarketType() >= 1){
            if (tempTicker != null) {
                ticker.last = tempTicker.last;
                return ticker;
            }
        }
        String url = MarketsConfig.EXCHANGEAPI + "v3/exchanges/" + market.key + "/tickers";
        if (!isCancelled() && !TextUtils.isEmpty(url)) {
            GzipVolleyStringRequest request = new GzipVolleyStringRequest(url, future, future);
            request.setRetryPolicy(new DefaultRetryPolicy(8000, 1, 1.0f));
            this.requestQueue.add(request);
            try {
                responseString = future.get();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (tempTicker != null) {
            if (checkerInfo.getCurrencyCounter()== null || checkerInfo.getCurrencyCounter().equalsIgnoreCase("USD")) {
                ticker.last = tempTicker.last;
                return ticker;
            }
            try {
                JSONObject jsonObject = new JSONObject(responseString);
                if (jsonObject.has("tickers")) {
                    JSONArray jsonArray = jsonObject.getJSONArray("tickers");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject tickerObject = jsonArray.getJSONObject(i);
                        String counter = checkerInfo.getCurrencyCounter();
                        if (counter.length() > 3 && !counter.equalsIgnoreCase(VirtualCurrency.USDT)) {
                            counter = counter.substring(1);
                        }
                        if ((tickerObject.getString("base").equalsIgnoreCase(checkerInfo.getCurrencyBase()) || tickerObject.getString("coin_id").equalsIgnoreCase(checkerInfo.getCurrencyBase())) &&(tickerObject.getString("target").toUpperCase().contains(counter.toUpperCase()) || tickerObject.getString("target_coin_id").equalsIgnoreCase(checkerInfo.getCurrencyCounter())) ) {
                            if (tickerObject.has("converted_last")) {
                                double price = tickerObject.getJSONObject("converted_last").getDouble("usd");
                                ticker.last = price;
                                ticker.usd = price;
                            }
                        }
                    }
                }
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }
        if (ticker.last<0) {
            try {
                JSONObject jsonObject = new JSONObject(responseString);
                if (jsonObject.has("tickers")) {
                    JSONArray jsonArray = jsonObject.getJSONArray("tickers");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject tickerObject = jsonArray.getJSONObject(i);
                        String counter = checkerInfo.getCurrencyCounter();
                        if (counter.length() > 3 && !counter.equalsIgnoreCase(VirtualCurrency.USDT)) {
                            counter = counter.substring(1);
                        }
                        if (tickerObject.getString("base").equalsIgnoreCase(counter) && tickerObject.getString("target").contains("USD")) {
                            if (tickerObject.has("converted_last")) {
                                double price = tickerObject.getJSONObject("converted_last").getDouble("usd");
                                ticker.last = price * tempTicker.last;
                                ticker.usd = price;
                            }
                        }
                    }
                }
            } catch (Throwable th) {
                th.printStackTrace();
            }
        }
        return ticker;

    }

    @Override
    public void onPostExecute(Object result) {
        if (CHECKERS_TASKS != null) {
            CHECKERS_TASKS.remove(this);
        }
        super.onPostExecute(result);
    }

    @Override
    public void onCancelled() {
        if (CHECKERS_TASKS != null) {
            CHECKERS_TASKS.remove(this);
        }
        super.onCancelled();
    }

    public static void cancelCheckingForCheckerRecord(long checkerRecordId) {
        if (CHECKERS_TASKS != null && checkerRecordId > 0) {
            Iterator it = CHECKERS_TASKS.iterator();
            while (it.hasNext()) {
                CheckerTotalVolleyAsyncTask checkerVolleyAsyncTask = (CheckerTotalVolleyAsyncTask) it.next();
                if (checkerVolleyAsyncTask != null && checkerVolleyAsyncTask.getCheckerRecordId() == checkerRecordId) {
                    checkerVolleyAsyncTask.cancel(true);
                }
            }
        }
    }
}
