package com.tekhnical.amplify.preferences;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.NumberPicker;

import androidx.preference.DialogPreference;

import com.jaygoo.widget.OnRangeChangedListener;
import com.jaygoo.widget.RangeSeekBar;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.dialog.CustomDialog;
import com.tekhnical.amplify.dialog.ScreenDialog;
import com.tekhnical.amplify.util.PreferencesUtils;
import com.tekhnical.amplify.util.TimeUtils;

import java.text.DecimalFormat;

public class FrequencyPickerDialogPreference extends DialogPreference {
    public static final long DEFAULT_FREQUENCY_MILLIS = 1000;
    public static final long[] FREQUENCY_TYPE_MULTIPLAYERS = {TimeUtils.MILLIS_IN_SECOND, TimeUtils.MILLIS_IN_MINUTE, TimeUtils.MILLIS_IN_HOUR, TimeUtils.MILLIS_IN_DAY};
    public static final int[] FREQUENCY_TYPE_NAMES = {R.string.time_seconds, R.string.time_minutes, R.string.time_hours, R.string.time_days};
    public static final int[] FREQUENCY_TYPE_PLURALS = {R.plurals.time_seconds, R.plurals.time_minutes, R.plurals.time_hours, R.plurals.time_days};
    public static final int[] FREQUENCY_VALUE_MAX = {59, 59, 23, 365};
    public static final int[] FREQUENCY_VALUE_MIN = {1, 1, 1, 1};
    public static final long MIN_FREQUENCY_MILLIS = (((long) FREQUENCY_VALUE_MIN[0]) * FREQUENCY_TYPE_MULTIPLAYERS[0]);
    private long baseFrequencyMillis = DEFAULT_FREQUENCY_MILLIS;
    private String[] frequencyTypeEntries;
    //private NumberPicker frequencyTypePicker;
    //private NumberPicker frequencyValuePicker;
    private LinearLayout globalCheckboxLayout;
    private EditText minutesEd, secondsEd;
    private RangeSeekBar freqRangeBar;
    private long viewFrequencyMillis;
    private ScreenDialog customDialog;
    private int mDialogLayoutResId = R.layout.frequency_picker_dialog;

    private static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR = new Creator<SavedState>() {
            public SavedState createFromParcel(Parcel in) {
                return new SavedState(in);
            }

            public SavedState[] newArray(int size) {
                return new SavedState[size];
            }
        };
        long baseFrequencyMillis;
        long viewFrequencyMillis;

        public SavedState(Parcelable superState) {
            super(superState);
            this.viewFrequencyMillis = -1;
        }

        public SavedState(Parcel source) {
            super(source);
            this.baseFrequencyMillis = source.readLong();
            this.viewFrequencyMillis = source.readLong();
        }

        public void writeToParcel(Parcel dest, int flags) {
            super.writeToParcel(dest, flags);
            dest.writeLong(this.baseFrequencyMillis);
            dest.writeLong(this.viewFrequencyMillis);
        }
    }

    public FrequencyPickerDialogPreference(Context context) {
        this(context, null);
    }

    public FrequencyPickerDialogPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.frequencyTypeEntries = new String[4];
        for (int i = 0; i < FREQUENCY_TYPE_NAMES.length; i++) {
            this.frequencyTypeEntries[i] = context.getString(FREQUENCY_TYPE_NAMES[i]);
        }
    }

    @Override
    public void onSetInitialValue(boolean restore, Object defaultValue) {
        setFrequencyMillis(restore ? getPersistedLong(DEFAULT_FREQUENCY_MILLIS) : ((Long) defaultValue).longValue());
    }

    @Override
    public Object onGetDefaultValue(TypedArray a, int index) {
        return Long.valueOf(DEFAULT_FREQUENCY_MILLIS);
    }

    /*@Override
    public void onDisplayPreferenceDialog(Preference preference) {
        if (preference instanceof CustomDialogPreference) {
            DialogFragment dialogFragment = DialogPrefFragCompat.newInstance(preference.getKey());
            dialogFragment.setTargetFragment(this, 0);
            dialogFragment.show(getFragmentManager(), null);
        } else super.onDisplayPreferenceDialog(preference);
    }*/

    private void onBindDialogView(View view) {
        this.globalCheckboxLayout = view.findViewById(R.id.globalFrequencyCheckBoxLayout);
        this.minutesEd = view.findViewById(R.id.frequencyMinutesEd);
        this.secondsEd = view.findViewById(R.id.frequencySecondsEd);
        this.freqRangeBar = view.findViewById(R.id.frequencyRangebar);
        this.globalCheckboxLayout.setVisibility(View.GONE);
        DecimalFormat decimalFormat = new DecimalFormat("00");
        freqRangeBar.setOnRangeChangedListener(new OnRangeChangedListener() {
            @Override
            public void onRangeChanged(RangeSeekBar view, float leftValue, float rightValue, boolean isFromUser) {
                int change = (int) ((60 * leftValue)/100);
                Log.e("SEEKBAR",leftValue+" "+change);
                if(minutesEd.isFocused()) {
                    minutesEd.setText(decimalFormat.format(change));
                    secondsEd.setText("00");
                }
                else {
                    secondsEd.setText(decimalFormat.format(change));
                    minutesEd.setText("00");
                }
            }

            @Override
            public void onStartTrackingTouch(RangeSeekBar view, boolean isLeft) {

            }

            @Override
            public void onStopTrackingTouch(RangeSeekBar view, boolean isLeft) {

            }
        });
        if (this.viewFrequencyMillis <= 0) {
            this.viewFrequencyMillis = this.baseFrequencyMillis;
        }
        int frequencyTypeId = PreferencesUtils.getUserUpdate(getContext());
        Log.e("PREF","FREQ:"+decimalFormat.format(parseFrequencyValue(this.viewFrequencyMillis, frequencyTypeId)));
        if (frequencyTypeId == 0){
            this.secondsEd.setText(decimalFormat.format(parseFrequencyValue(this.viewFrequencyMillis, frequencyTypeId)));
            this.minutesEd.setText("00");
        }else{
            this.minutesEd.setText(decimalFormat.format(parseFrequencyValue(this.viewFrequencyMillis, frequencyTypeId)));
            this.secondsEd.setText("00");
        }
        /*this.frequencyTypePicker = (NumberPicker) view.findViewById(R.id.frequencyTypePicker);
        this.frequencyValuePicker = (NumberPicker) view.findViewById(R.id.frequencyValuePicker);
        view.findViewById(R.id.useGlobalFrequencyCheckBox).setVisibility(View.GONE);
        this.frequencyTypePicker.setMinValue(0);
        this.frequencyTypePicker.setMaxValue(this.frequencyTypeEntries.length - 1);
        this.frequencyTypePicker.setDisplayedValues(this.frequencyTypeEntries);
        this.frequencyTypePicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            public void onValueChange(NumberPicker np, int oldVal, int newVal) {
                FrequencyPickerDialogPreference.this.frequencyValuePicker.setMinValue(FrequencyPickerDialogPreference.FREQUENCY_VALUE_MIN[newVal]);
                FrequencyPickerDialogPreference.this.frequencyValuePicker.setMaxValue(FrequencyPickerDialogPreference.FREQUENCY_VALUE_MAX[newVal]);
            }
        });
        this.frequencyValuePicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            public void onValueChange(NumberPicker np, int oldVal, int newVal) {
            }
        });
        if (this.viewFrequencyMillis < 0) {
            this.viewFrequencyMillis = this.baseFrequencyMillis;
        }
        int frequencyTypeId = parseFrequencyTypeId(this.viewFrequencyMillis);
        this.frequencyTypePicker.setValue(frequencyTypeId);
        this.frequencyValuePicker.setMinValue(FREQUENCY_VALUE_MIN[this.frequencyTypePicker.getValue()]);
        this.frequencyValuePicker.setMaxValue(FREQUENCY_VALUE_MAX[this.frequencyTypePicker.getValue()]);
        this.frequencyValuePicker.setValue(parseFrequencyValue(this.viewFrequencyMillis, frequencyTypeId));*/
    }

    private long getFrequencyMillis(int frequencyTypeId, int frequencyValue) {
        return FREQUENCY_TYPE_MULTIPLAYERS[frequencyTypeId] * ((long) frequencyValue);
    }

    private int parseFrequencyTypeId(long frequencyMillis) {
        for (int i = FREQUENCY_TYPE_MULTIPLAYERS.length - 1; i >= 0; i--) {
            if (frequencyMillis >= FREQUENCY_TYPE_MULTIPLAYERS[i] * ((long) FREQUENCY_VALUE_MIN[1])) {
                return i;
            }
        }
        return 0;
    }

    private int parseFrequencyValue(long frequencyMillis, int frequencyTypeId) {
        return (int) (frequencyMillis / FREQUENCY_TYPE_MULTIPLAYERS[frequencyTypeId]);
    }

    @Override
    protected void onClick() {
        showDialog();
    }
    protected void showDialog() {
        Context context = getContext();

        customDialog = new ScreenDialog(context);
        customDialog.setTitle(context.getString(R.string.settings_check_global_frequency_title));
        View contentView = onCreateDialogView();
        if (contentView != null) {
            onBindDialogView(contentView);
            customDialog.setView(contentView);
            customDialog.setSaveListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onDialogClosed(true);
                    customDialog.dismiss();
                }
            });
        }
        customDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                onDialogClosed(true);
            }
        });
        customDialog.show();
    }
    private View onCreateDialogView() {
        if (mDialogLayoutResId == 0) {
            return null;
        }

        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(
                Context.LAYOUT_INFLATER_SERVICE);
        return inflater.inflate(mDialogLayoutResId, null);
    }

    private void onDialogClosed(boolean positiveResult) {
        if (positiveResult) {
            minutesEd.clearFocus();
            secondsEd.clearFocus();
            int minutes =  Integer.parseInt(minutesEd.getText().toString());
            int secs =  Integer.parseInt(secondsEd.getText().toString());
            int type = minutes > 0 ? 1 : 0;
            PreferencesUtils.setUserUpdate(getContext() , type);
            long frequencyMillis = getFrequencyMillis(type, minutes>0 ? minutes : secs);
            if (callChangeListener(Long.valueOf(frequencyMillis))) {
                setFrequencyMillis(frequencyMillis);
                return;
            }
            return;
        }
        this.viewFrequencyMillis = -1;
    }

    private void setFrequencyMillis(long frequencyMillis) {
        if (frequencyMillis < MIN_FREQUENCY_MILLIS) {
            frequencyMillis = MIN_FREQUENCY_MILLIS;
        }
        this.viewFrequencyMillis = frequencyMillis;
        int frequencyTypeId = PreferencesUtils.getUserUpdate(getContext());
        int frequencyValue = parseFrequencyValue(frequencyMillis, frequencyTypeId);
        setSummary(getContext().getResources().getQuantityString(FREQUENCY_TYPE_PLURALS[frequencyTypeId], frequencyValue, new Object[]{Integer.valueOf(frequencyValue)}));
        if (frequencyMillis != this.baseFrequencyMillis) {
            this.baseFrequencyMillis = frequencyMillis;
            persistLong(frequencyMillis);
            notifyChanged();
        }
        Log.e("PREF","FREQ:"+this.viewFrequencyMillis+" "+this.baseFrequencyMillis);
    }

    private long getFrequencyMillis() {
        return this.baseFrequencyMillis;
    }

    @Override
    public Parcelable onSaveInstanceState() {
        SavedState myState = new SavedState(super.onSaveInstanceState());
        myState.baseFrequencyMillis = getFrequencyMillis();
        if (!(this.minutesEd == null || this.secondsEd == null)) {
            int minutes =  Integer.parseInt(minutesEd.getText().toString());
            int secs =  Integer.parseInt(secondsEd.getText().toString());
            myState.viewFrequencyMillis = getFrequencyMillis(minutes > 0 ? 1 : 0, minutes>0 ? minutes : secs);
        }
        return myState;
    }

    @Override
    public void onRestoreInstanceState(Parcelable state) {
        if (state == null || !state.getClass().equals(SavedState.class)) {
            super.onRestoreInstanceState(state);
            return;
        }
        SavedState myState = (SavedState) state;
        setFrequencyMillis(myState.baseFrequencyMillis);
        this.viewFrequencyMillis = myState.viewFrequencyMillis;
        super.onRestoreInstanceState(myState.getSuperState());
    }
}
