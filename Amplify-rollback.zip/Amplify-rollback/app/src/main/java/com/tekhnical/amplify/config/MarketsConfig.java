package com.tekhnical.amplify.config;

import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.market.*;
import com.tekhnical.amplify.model.market.futures.BinanceFuture;
import com.tekhnical.amplify.model.market.futures.BitMEX;
import com.tekhnical.amplify.model.market.futures.BitfinexFuture;
import com.tekhnical.amplify.model.market.futures.Bybit;
import com.tekhnical.amplify.model.market.futures.Deribit;
import com.tekhnical.amplify.model.market.futures.FTXFuture;
import com.tekhnical.amplify.model.market.futures.HuobiFuture;
import com.tekhnical.amplify.model.market.futures.KrakenFuture;
import com.tekhnical.amplify.model.market.futures.OkexFutures;

import java.util.LinkedHashMap;

public class MarketsConfig {
    public static final String EXCHANGEAPI = "https://api.coingecko.com/api/";
    public static final String STOCKAPI = "https://cloud.iexapis.com/stable/";
    public static final LinkedHashMap<String, Market> MARKETS = new LinkedHashMap<>();
    public static final LinkedHashMap<String, Market> FUTURE_MARKETS = new LinkedHashMap<>();

    static {
        // TODO Add here new Market
        addFutureMarket(new Deribit());
        addFutureMarket(new Bybit());
        addMarket(new SerumDex());
        addMarket(new JustSwap());
        addMarket(new Uniswap());
        addMarket(new UniswapV2());
        addMarket(new UniswapV1());
        addMarket(new CurveFinance());
        addMarket(new Aave());
        addMarket(new CompoundFinance());
        addMarket(new Balancer());
        addMarket(new Kyber());
        addMarket(new Tokenlon());
        addMarket(new Synthetix());
        addMarket(new Sushiswap());

        addMarket(new Bibox());
        addMarket(new YoBit());
        addMarket(new BtcBox());
        addMarket(new BitBay());
        addMarket(new STEX());
        addMarket(new BitForex());
        addMarket(new Ovex());
        addMarket(new Luno());
        addMarket(new Kucoin());
        addMarket(new BigOne());
        addMarket(new Bitubu());
        addMarket(new BinanceDex());
        addMarket(new QTrade());
        addMarket(new Bitget());
        addMarket(new DragonEx());
        addMarket(new Tidex());
        addMarket(new CoinField());
        addMarket(new Crex24());
        addMarket(new Currency());
        addMarket(new Bitbns());
        addMarket(new Novadax());
        addMarket(new Gopax());
        addMarket(new BithumbGlobal());
        addMarket(new Bitrue());
        addMarket(new Phemex());
        addMarket(new Coinone());
        addMarket(new CoinTiger());
        addMarket(new XT());
        addMarket(new LBank());
        addMarket(new Upbit());
        addMarket(new Namebase());
        addMarket(new HuobiIndonesia());
        addMarket(new Coindcx());
        addMarket(new TheRock());
        addMarket(new Kuna());
        addMarket(new BitPanda());
        addMarket(new Okcoin());
        addMarket(new BTCmarket());
        addMarket(new Korbit());
        addMarket(new DyDx());
        addMarket(new Wazirx());
        addMarket(new AlterDice());
        addMarket(new BTSE());
        addMarket(new GmoJapan());
        addMarket(new Oceanex());
        addMarket(new Latoken());
        addMarket(new Paribu());
        addMarket(new Hotbit());
        addMarket(new Bilaxy());
        addMarket(new Probit());
        addMarket(new HitBtc());
        addMarket(new Coinsbit());
        addMarket(new WhiteBit());
        addMarket(new BW());
        addMarket(new Bkex());
        addMarket(new Bitopro());
        addMarket(new Bitso());
        addMarket(new CexIO());
        addMarket(new Indodax());
        addMarket(new Atomars());
        addMarket(new Bitkub());
        addMarket(new Bitbank());
        addMarket(new Exmo());
        addMarket(new BitFlyer());
        addMarket(new Bitmart());
        addMarket(new BitTrex());
        addMarket(new Quoine());
        addMarket(new Bitstamp());
        addFutureMarket(new FTXFuture());
        addMarket(new FTX());
        addMarket(new Btcturk());
        addFutureMarket(new BitMEX());
        addMarket(new Bitmax());
        addFutureMarket(new HuobiFuture());
        addMarket(new Huobi());
        addMarket(new Bithumb());
        addMarket(new Maicoin());
        addMarket(new Poloniex());
        addFutureMarket(new BitfinexFuture());
        addMarket(new Bitfinex());
        addMarket(new Coinbase());
        addFutureMarket(new OkexFutures());
        addMarket(new Okex());
        addMarket(new Gemini());
        addMarket(new BinanceUS());
        addMarket(new Gate());
        addFutureMarket(new KrakenFuture());
        addMarket(new Kraken());
        addFutureMarket(new BinanceFuture());
        addMarket(new Binance());
    }

    public static final void addMarket(Market market) {
        MARKETS.put(market.key, market);
    }

    public static final void addFutureMarket(Market market) {
        FUTURE_MARKETS.put(market.key, market);
    }
}
