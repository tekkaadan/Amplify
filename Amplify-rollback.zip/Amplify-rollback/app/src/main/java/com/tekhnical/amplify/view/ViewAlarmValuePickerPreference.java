package com.tekhnical.amplify.view;

import android.annotation.TargetApi;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.dialog.CustomDialog;
import com.tekhnical.amplify.model.CurrencySubunit;
import com.tekhnical.amplify.content.AlarmRecord;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.util.AlarmRecordHelper;
import com.tekhnical.amplify.util.CurrencyUtils;
import com.tekhnical.amplify.util.Utils;
import com.tekhnical.amplify.view.generic.ViewDialogPreference;

public class ViewAlarmValuePickerPreference extends ViewDialogPreference {
    private AlarmRecord alarmRecord;
    private OnValueChangedListener onValueSelectedListener;
    private String prefix;
    private CurrencySubunit subunit;
    private String sufix;
    private double value = -1.0d;

    public interface OnValueChangedListener {
        boolean onValueChanged(ViewAlarmValuePickerPreference viewAlarmValuePickerPreference, double d);
    }

    public ViewAlarmValuePickerPreference(Context context) {
        super(context);
    }

    public ViewAlarmValuePickerPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @TargetApi(11)
    public ViewAlarmValuePickerPreference(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public String getEntry() {
        return getContext().getString(R.string.checker_add_alarm_type_value_format, new Object[]{this.prefix != null ? this.prefix : "", AlarmRecordHelper.getValueForAlarmType(this.subunit, this.alarmRecord), this.sufix != null ? this.sufix : ""});
    }

    public void setCheckerAndAlarmRecord(CheckerRecord checkerRecord, AlarmRecord alarmRecord2) {
        this.subunit = CurrencyUtils.getCurrencySubunit(checkerRecord.getCurrencyDst(), checkerRecord.getCurrencySubunitDst());
        this.alarmRecord = alarmRecord2;
    }

    public void setValue(double value2) {
        if (getValue() != value2 && (this.onValueSelectedListener == null || this.onValueSelectedListener.onValueChanged(this, value2))) {
            this.value = value2;
        }
        setSummary(getEntry());
    }

    public double getValue() {
        return this.value;
    }

    public void setPrefix(String prefix2) {
        this.prefix = prefix2;
    }

    public void setSufix(String sufix2) {
        this.sufix = sufix2;
    }

    @Override
    public void onPrepareDialog(CustomDialog builder) {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.alarm_value_picker_dialog, null);
        TextView prefixView = (TextView) view.findViewById(R.id.prefixView);
        final EditText valueView = (EditText) view.findViewById(R.id.valueView);
        valueView.addTextChangedListener(new TextWatcher() {
            int selectionEnd;
            int selectionStart;

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                this.selectionStart = valueView.getSelectionStart();
                this.selectionEnd = valueView.getSelectionEnd();
                valueView.removeTextChangedListener(this);
                if (s.toString().contains(",")) {
                    valueView.setText(s.toString().replace(',', '.'));
                }
                valueView.addTextChangedListener(this);
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void afterTextChanged(Editable s) {
                valueView.setSelection(this.selectionStart, this.selectionEnd);
            }
        });
        TextView sufixView = (TextView) view.findViewById(R.id.sufixView);
        prefixView.setText(this.prefix);
        valueView.setText(AlarmRecordHelper.getValueForAlarmType(this.subunit, this.alarmRecord).replace(',', '.'));
        Utils.setSelectionAfterLastLetter(valueView);
        sufixView.setText(this.sufix);
        valueView.post(new Runnable() {
            public void run() {
                Utils.showKeyboard(ViewAlarmValuePickerPreference.this.getContext(), valueView);
            }
        });
        builder.setPositiveButton(getResources().getString(R.string.ok), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.hideKeyboard(ViewAlarmValuePickerPreference.this.getContext(), valueView);
                double newValue = 1.0d;
                try {
                    newValue = AlarmRecordHelper.parseEnteredValueForAlarmType(ViewAlarmValuePickerPreference.this.subunit, ViewAlarmValuePickerPreference.this.alarmRecord, Double.parseDouble(valueView.getText().toString().replace(',', '.')));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                ViewAlarmValuePickerPreference.this.setValue(newValue);
                builder.dismiss();
            }
        });
        builder.setView(view);
    }

    public void setOnValueChangedListener(OnValueChangedListener onValueSelectedListener2) {
        this.onValueSelectedListener = onValueSelectedListener2;
    }
}
