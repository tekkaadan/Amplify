package com.tekhnical.amplify.volley.generic;

import android.os.AsyncTask;
import com.android.volley.RequestQueue;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.tekhnical.amplify.volley.UnknownVolleyError;
import java.util.concurrent.ExecutionException;

public abstract class GenericVolleyAsyncTask<T> extends AsyncTask<Void, Void, Object> {
    private final ErrorListener errorListener;
    private final Listener<T> listener;
    protected final RequestQueue requestQueue;

    public abstract Object doNetworkInBackground() throws Exception;

    public GenericVolleyAsyncTask(RequestQueue requestQueue2, Listener<T> listener2, ErrorListener errorListener2) {
        this.requestQueue = requestQueue2;
        this.listener = listener2;
        this.errorListener = errorListener2;
    }

    @Override
    public final Object doInBackground(Void... params) {
        try {
            return doNetworkInBackground();
        } catch (ExecutionException e) {
            if (e.getCause() != null) {
                return e.getCause();
            }
            return e;
        } catch (Throwable th) {
            return th;
        }
    }

    @Override
    public void onPostExecute(Object result) {
        super.onPostExecute(result);
        if (isCancelled() || result == null) {
            return;
        }
        if (!(result instanceof Throwable)) {
            try {
                this.listener.onResponse((T) result);
            } catch (Throwable e) {
                e.printStackTrace();
            }
        } else if (result instanceof VolleyError) {
            this.errorListener.onErrorResponse((VolleyError) result);
        } else {
            this.errorListener.onErrorResponse(new UnknownVolleyError((Throwable) result));
        }
    }
}
