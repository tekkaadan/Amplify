package com.tekhnical.amplify.model.market.futures;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.FuturesMarket;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class BinanceFuture extends FuturesMarket {
    public static final String ID = "binance_futures";
    private static final String NAME = "Binance Futures";
    private static final String TTS_NAME = "Binance Futures";
    private static final String URL = "https://fapi.binance.com/fapi/v1/ticker/24hr?symbol=%1$s";
    private static final String URL_CURRENCY_PAIRS = "https://fapi.binance.com/fapi/v1/exchangeInfo";

    public BinanceFuture() {
        super(ID,NAME, TTS_NAME, null,new int[]{1,2,3,4});
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo, int i) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    @Override
    public int getImageUrl() {
        return R.drawable.binance_futures;
    }
    /*@Override
    public String getImageUrl() {
        //return "https://assets.coingecko.com/markets/images/466/small/binance_futures.jpg";
        return "file:///android_asset/logos/BinanceFutures.png";
    }*/

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject,"volume");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject,"highPrice");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject,"lowPrice");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject,"lastPrice");
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray resultJsonArray = jsonObject.getJSONArray("symbols");
        for (int i = 0; i < resultJsonArray.length(); i++) {
            JSONObject pairObject = resultJsonArray.getJSONObject(i);
            list.add(new CurrencyPairInfo(pairObject.getString("baseAsset"),pairObject.getString("quoteAsset"),pairObject.getString("symbol")));

        }
    }

}
