package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Bitbank extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "BitBank";
    private static final String TTS_NAME = "BitBank";
    private static final String URL = "https://public.bitbank.cc/%1$s/ticker";
    private static final String CURRENCIES_URL = "https://api.bitbank.cc/v1/spot/pairs";

    public Bitbank() {
        super("bitbank", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }


    /*@Override
    public String getImageUrl() {
        //return "https://assets.coingecko.com/markets/images/122/small/bitbank.jpg";
        return "file:///android_asset/logos/BitBank.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bitbank;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject json, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = json.getJSONObject("data");
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "buy");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "sell");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "vol");
        if (jsonObject.has("timestamp"))
            ticker.timestamp = jsonObject.getLong("timestamp");
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONObject dataObject = jsonObject.getJSONObject("data");
        JSONArray jsonArray = dataObject.getJSONArray("pairs");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject pairObject = jsonArray.getJSONObject(i);
            if (pairObject.has("name"))
                list.add(new CurrencyPairInfo(pairObject.getString("base_asset").toUpperCase(),pairObject.getString("quote_asset").toUpperCase(),pairObject.getString("name")));
        }
    }

}
