package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class BitForex extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "BitForex";
    private static final String TTS_NAME = "Bit Forex";
    private static final String URL = "https://api.bitforex.com/api/v1/market/ticker?symbol=%1$s";
    private static final String CURRENCIES_URL = "https://api.bitforex.com/api/v1/market/symbols";

    public BitForex() {
        super("bitforex", NAME, TTS_NAME, null);
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/BitForex.png";
        //return "https://assets.coingecko.com/markets/images/214/small/BitForex-Logo.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bitforex;
    }
    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }


    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject("data");
        ticker.bid = ParseUtils.getDouble(jsonObject, "buy");
        ticker.ask = ParseUtils.getDouble(jsonObject, "sell");
        ticker.last = ParseUtils.getDouble(jsonObject, "last");
        ticker.high = ParseUtils.getDouble(jsonObject, "high");
        ticker.low = ParseUtils.getDouble(jsonObject, "low");
        ticker.vol = ParseUtils.getDouble(jsonObject, "vol");

    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = json.getJSONArray("data");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("symbol")){
                String symbol = jsonObject.getString("symbol");
                String[] splits = symbol.split("-");
                if (splits.length>=3)
                    list.add(new CurrencyPairInfo(splits[1].toUpperCase(),splits[2].toUpperCase(),symbol));
            }
        }
    }

}
