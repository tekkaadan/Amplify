package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Novadax extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Novadax";
    private static final String TTS_NAME = "Novadax";
    private static final String URL = "https://api.novadax.com/v1/market/ticker?symbol=%1$s";
    private static final String CURRENCIES_URL = "https://api.novadax.com/v1/common/symbols";

    public Novadax() {
        super("novadax", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/NovaDAX.png";
        //return "https://assets.coingecko.com/markets/images/328/small/preview-full-novadax-exchange.jpg";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.novadax;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject("data");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "lastPrice");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high24h");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low24h");
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "bid");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "ask");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "baseVolume24h");
        if (jsonObject.has("timestamp"))
            ticker.timestamp = jsonObject.getLong("timestamp");
    }


    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = json.getJSONArray("data");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("symbol")){
                list.add(new CurrencyPairInfo(jsonObject.getString("baseCurrency").toUpperCase(),jsonObject.getString("quoteCurrency").toUpperCase(),jsonObject.getString("symbol")));
            }
        }
    }
}
