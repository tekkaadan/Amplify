package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class WhiteBit extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "WhiteBit";
    private static final String TTS_NAME = "White Bit";
    private static final String URL = "https://whitebit.com/api/v1/public/ticker?market=%1$s";
    private static final String CURRENCIES_URL = "https://whitebit.com/api/v1/public/markets";

    public WhiteBit() {
        super("whitebit", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    @Override
    public int getImageUrl() {
        return R.drawable.whitebit;
    }
    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/WhiteBIT.png";
        //return "https://assets.coingecko.com/markets/images/418/small/whitebit.png";
    }*/

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject("result");
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "bid");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "ask");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "volume");
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = jsonObject.getJSONArray("result");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject pairObject = jsonArray.getJSONObject(i);
            if (pairObject.has("name"))
            list.add(new CurrencyPairInfo(pairObject.getString("stock"),pairObject.getString("money"),pairObject.getString("name")));

        }
    }

}
