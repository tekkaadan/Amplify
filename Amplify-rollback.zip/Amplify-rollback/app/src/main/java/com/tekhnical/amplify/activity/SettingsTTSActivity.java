package com.tekhnical.amplify.activity;

import android.os.Bundle;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.generic.SimpleFragmentSubActivity;
import com.tekhnical.amplify.fragment.SettingsTTSFragment;

public class SettingsTTSActivity extends SimpleFragmentSubActivity<SettingsTTSFragment> {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.setContentTheme(true);
        super.onCreate(savedInstanceState);
    }

    @Override
    public SettingsTTSFragment createChildFragment() {
        return new SettingsTTSFragment();
    }

    @Override
    public int getContentViewResId() {
        return R.layout.setting_main_activity;
    }

    @Override
    public String getContentViewTitle() {
        return getString(R.string.settings_activity_title);
    }

    /*@Override
    public String getContentViewTitle() {
        return getResources().getString(R.string.settings_tts_category_title);
    }*/
}
