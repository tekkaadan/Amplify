package com.tekhnical.amplify.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.fragment.app.Fragment;

import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.generic.SimpleFragmentSubActivity;
import com.tekhnical.amplify.fragment.CheckerAddFragment;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.receiver.MarketChecker;

public class CheckerAddActivity extends SimpleFragmentSubActivity<CheckerAddFragment> {
    public static final String EXTRA_CHECKER_RECORD = "checker_record";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.setContentTheme(false);
        super.onCreate(savedInstanceState);
        findViewById(R.id.drawerItem).setVisibility(View.GONE);
        /*if (MyApplication.APP_THEME == 3)
            findViewById(R.id.checker_parent).setBackgroundResource(R.drawable.main_background_gray);
        else if (MyApplication.APP_THEME == 4)
            findViewById(R.id.checker_parent).setBackgroundResource(R.drawable.main_background_sepia);*/
    }

    @Override
    public CheckerAddFragment createChildFragment() {
        CheckerRecord checkerRecord = (CheckerRecord) getIntent().getParcelableExtra(EXTRA_CHECKER_RECORD);
        if (checkerRecord == null) {
            long checkerRecordId = getIntent().getLongExtra(MarketChecker.EXTRA_CHECKER_RECORD_ID, 0);
            if (checkerRecordId > 0) {
                checkerRecord = CheckerRecord.get(checkerRecordId);
            }
        }
        return CheckerAddFragment.newInstance(checkerRecord, getIntent().getLongExtra(MarketChecker.EXTRA_ALARM_RECORD_ID, 0));
    }

    @Override
    public int getContentViewResId() {
        return R.layout.checkers_list_activity;
    }

    public void onBackPressed() {
        Fragment childFragment = getChildFragment();
        if (!(childFragment instanceof CheckerAddFragment) || !((CheckerAddFragment) childFragment).onBackPressed()) {
            super.onBackPressed();
        }
    }

    public static void startCheckerAddActivity(Context context, CheckerRecord checkerRecord) {
        startCheckerAddActivity(context, checkerRecord, -1, false);
    }

    public static void startCheckerAddActivity(Context context, CheckerRecord checkerRecord, long alarmRecordId, boolean newTask) {
        Intent intent = new Intent(context, CheckerAddActivity.class);
        intent.putExtra(EXTRA_CHECKER_RECORD, checkerRecord);
        intent.putExtra(MarketChecker.EXTRA_ALARM_RECORD_ID, alarmRecordId);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
}
