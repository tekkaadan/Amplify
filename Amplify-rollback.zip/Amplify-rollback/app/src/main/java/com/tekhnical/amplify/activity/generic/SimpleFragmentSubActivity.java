package com.tekhnical.amplify.activity.generic;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.fragment.app.Fragment;

public abstract class SimpleFragmentSubActivity<T extends Fragment> extends SimpleFragmentActivity<T> {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(getSupportActionBar()!=null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        //TODO
        if (item.getItemId() != 16908332) {
            return super.onOptionsItemSelected(item);
        }
        onBackPressed();
        return true;
    }
}
