package com.tekhnical.amplify.util;

import com.tekhnical.amplify.model.ExchangeModel;
import com.tekhnical.amplify.model.StockGlobalQuote;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiInterface {

    @GET("ref-data/symbols")
    Call<List<ExchangeModel>> getExchanges(@Query("token") String token);

    @GET("stock/{symbol}/quote")
    Call<StockGlobalQuote> quoteStock(@Path("symbol") String symbol, @Query("token") String token);

    /*@GET("v3/exchanges")
    Call<List<ExchangeModel>> getExchanges(@Query("per_page") int count);

    @GET("query")
    Call<StockSearchList> searchStock(@Query("function") String function, @Query("keywords") String keyword, @Query("apikey") String api);

    @GET("query")
    Call<StockGlobalQuote> quoteStock(@Query("function") String function, @Query("symbol") String symbol, @Query("apikey") String api);
    */
}

