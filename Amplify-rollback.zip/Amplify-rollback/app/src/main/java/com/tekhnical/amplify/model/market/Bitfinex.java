package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class Bitfinex extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Bitfinex";
    private static final String TTS_NAME = "Bitfinex";
    private static final String URL = "https://api.bitfinex.com/v1/pubticker/%1$s";
    private static final String URL_CURRENCY_PAIRS = "https://api.bitfinex.com/v1/symbols";

    public Bitfinex() {
        super("bitfinex",NAME, TTS_NAME, null);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        String pairId = checkerInfo.getCurrencyPairId();
        if (pairId == null) {
            pairId = String.format("%1$s%2$s", new Object[]{checkerInfo.getCurrencyBaseLowerCase(), checkerInfo.getCurrencyCounterLowerCase()});
        }
        return String.format(URL, new Object[]{pairId});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Bitfinex.png";
        //return "https://assets.coingecko.com/markets/images/486/small/bitfinex.jpg";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bitfinex;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "bid");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "ask");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "volume");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last_price");
        //ticker.timestamp = ParseUtils.getLongFromString(jsonObject,"timestamp") * 1000;
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray pairsArray = new JSONArray(responseString);
        for (int i = 0; i < pairsArray.length(); i++) {
            String pairId = pairsArray.getString(i);
            if (pairId != null ) {
                if( pairId.length() == 6) {
                    pairs.add(new CurrencyPairInfo(pairId.substring(0, 3).toUpperCase(Locale.US), pairId.substring(3).toUpperCase(Locale.US), pairId));
                }
                else if(pairId.contains(":")){
                    pairs.add(new CurrencyPairInfo(pairId.substring(0,pairId.indexOf(":")).toUpperCase(Locale.US),pairId.substring(pairId.indexOf(":")+1).toUpperCase(Locale.US),pairId));
                }
            }
        }
    }
}
