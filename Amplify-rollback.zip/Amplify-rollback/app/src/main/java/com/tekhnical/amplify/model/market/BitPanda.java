package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class BitPanda extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "BitPanda";
    private static final String TTS_NAME = "BitPanda";
    private static final String URL = "https://api.exchange.bitpanda.com/public/v1/market-ticker/%1$s";
    private static final String CURRENCIES_URL = "https://api.exchange.bitpanda.com/public/v1/instruments";

    public BitPanda() {
        super("bitpanda", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Bitpanda.png";
        //return "https://assets.coingecko.com/markets/images/474/small/bitpanda-pro-logo.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.bitpanda;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        //JSONObject jsonObject = tickerObject.getJSONObject("result");
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "best_bid");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "best_ask");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last_price");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "base_volume");

    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("state") && jsonObject.getString("state").equalsIgnoreCase("ACTIVE")){
                String base = jsonObject.getJSONObject("base").getString("code");
                String counter = jsonObject.getJSONObject("quote").getString("code");
                pairs.add(new CurrencyPairInfo(base,counter,base+"_"+counter));
            }
        }
    }

}
