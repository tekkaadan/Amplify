package com.tekhnical.amplify.appwidget;

import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.os.Bundle;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.generic.SimpleFragmentSubActivity;

public class WidgetConfigureActivity extends SimpleFragmentSubActivity<WidgetConfigureFragment> {
    private int appWidgetId = 0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.setContentTheme(false);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            this.appWidgetId = extras.getInt("appWidgetId", 0);
        }
        super.onCreate(savedInstanceState);
        WidgetProvider.updateWdgetWithId(this, AppWidgetManager.getInstance(this), this.appWidgetId);
        Intent resultValue = new Intent();
        resultValue.putExtra("appWidgetId", this.appWidgetId);
        setResult(RESULT_OK, resultValue);
    }



    @Override
    public WidgetConfigureFragment createChildFragment() {
        return WidgetConfigureFragment.newInstance(this.appWidgetId);
    }

    public void finish() {
        WidgetProvider.updateWdgetWithId(this, AppWidgetManager.getInstance(this), this.appWidgetId);
        super.finish();
    }

    @Override
    public int getContentViewResId() {
        return R.layout.setting_main_activity;
    }
}
