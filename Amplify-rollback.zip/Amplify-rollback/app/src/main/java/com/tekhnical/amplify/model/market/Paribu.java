package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class Paribu extends Market {
    public static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    public static final String NAME = "Paribu";
    public static final String TTS_NAME = "Paribu";
    public static final String URL = "https://www.paribu.com/ticker";


    public Paribu() {
        super("paribu",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return URL;
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return URL;
    }

    /*@Override
        public String getImageUrl() {
            return "file:///android_asset/logos/Paribu.png";
            //return "https://assets.coingecko.com/markets/images/136/small/paribu.jpg";
        }*/
    @Override
    public int getImageUrl() {
        return R.drawable.paribu;
    }
    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray pairNames = jsonObject.names();
        for (int i = 0; i < pairNames.length(); i++) {
            String pairId = pairNames.getString(i);
            if (pairId != null) {
                String[] currencies = pairId.split("_");
                if (currencies.length == 2) {
                    list.add(new CurrencyPairInfo(currencies[1], currencies[0], pairId));
                }
            }
        }
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject dataJsonObject = jsonObject.getJSONObject(checkerInfo.getCurrencyPairId());
        ticker.bid = ParseUtils.getDouble(dataJsonObject, "highestBid");
        ticker.ask = ParseUtils.getDouble(dataJsonObject, "lowestAsk");
        ticker.vol = ParseUtils.getDouble(dataJsonObject, "volume");
        ticker.high = ParseUtils.getDouble(dataJsonObject, "high24hr");
        ticker.low = ParseUtils.getDouble(dataJsonObject, "low24hr");
        ticker.last = ParseUtils.getDouble(dataJsonObject, "last");
    }
}
