package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Wazirx extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Wazirx";
    private static final String TTS_NAME = "Wazirx";
    private static final String URL = "https://api.wazirx.com/api/v2/tickers";

    public Wazirx() {
        super("wazirx", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return URL;
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/WazirX.png";
        //return "https://assets.coingecko.com/markets/images/274/small/wazirx.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.wazirx;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject(checkerInfo.getCurrencyPairId());
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "buy");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "sell");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "volume");
        if (jsonObject.has("at"))
            ticker.timestamp = jsonObject.getLong("at");
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = json.names();
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = json.getJSONObject(jsonArray.getString(i));
            list.add(new CurrencyPairInfo(jsonObject.getString("base_unit").toUpperCase(),jsonObject.getString("quote_unit").toUpperCase(),jsonArray.getString(i)));

        }
    }

}
