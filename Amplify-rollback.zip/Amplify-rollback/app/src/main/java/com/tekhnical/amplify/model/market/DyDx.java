package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class DyDx extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "DyDx";
    private static final String TTS_NAME = "DyDx";
    private static final String URL = "https://api.dydx.exchange/v3/stats/%1$s";
    private static final String CURRENCIES_URL = "https://api.dydx.exchange/v3/markets";

    public DyDx() {
        super("dydx", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/dYdX.png";
        //return "https://assets.coingecko.com/markets/images/421/small/dydx.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.dydx;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject markets = tickerObject.getJSONObject("markets");
        String id = checkerInfo.getCurrencyPairId();
        if (!markets.has(id))
            id = checkerInfo.getCurrencyBase()+"-"+checkerInfo.getCurrencyCounter();
        JSONObject jsonObject = markets.getJSONObject(id);
        ticker.last = ParseUtils.getDouble(jsonObject, "close");
        ticker.bid = ParseUtils.getDouble(jsonObject, "open");
        ticker.ask = ParseUtils.getDouble(jsonObject, "close");
        ticker.high = ParseUtils.getDouble(jsonObject, "high");
        ticker.low = ParseUtils.getDouble(jsonObject, "low");
        ticker.vol = ParseUtils.getDouble(jsonObject, "baseVolume");

    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONObject markets = json.getJSONObject("markets");
        JSONArray jsonArray = markets.names();
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = markets.getJSONObject(jsonArray.getString(i));
            if (jsonObject.has("market")){
                String splits[] = jsonObject.getString("market").split("-");
                if (splits.length>=2)
                    list.add(new CurrencyPairInfo(splits[0],splits[1],jsonObject.getString("market")));
            }
        }
    }

}
