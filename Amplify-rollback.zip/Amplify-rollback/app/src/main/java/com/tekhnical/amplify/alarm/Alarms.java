package com.tekhnical.amplify.alarm;

public class Alarms {
    public static final String ALARM_ALERT_ACTION = "com.tekhnical.amplify.alarm.ALARM_ALERT";
    public static final String ALARM_DISMISS_ACTION = "com.tekhnical.amplify.alarm.ALARM_DISMISS";
    public static final String ALARM_DONE_ACTION = "com.tekhnical.amplify.alarm.ALARM_DONE";
    public static final String ALARM_KILLED = "alarm_killed";
    public static final String ALARM_KILLED_TIMEOUT = "alarm_killed_timeout";
    public static final String ALARM_REPLACED = "alarm_replaced";
}
