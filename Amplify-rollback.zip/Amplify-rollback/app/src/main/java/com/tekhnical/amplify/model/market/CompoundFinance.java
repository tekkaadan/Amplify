package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class CompoundFinance extends Market {
    private static final String NAME = "Compound Finance";
    private static final String TTS_NAME = "Compound Finance";
    private static final String ID = "compound_finance";
    private static final String URL = "https://api.coingecko.com/api/v3/exchanges/"+ID+"/tickers";
    public CompoundFinance() {
        super(ID,NAME, TTS_NAME, null);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return URL;
    }

    /*@Override
    public String getImageUrl() {
        //return "https://assets.coingecko.com/markets/images/52/small/binance.jpg";
        return "file:///android_asset/logos/Binance.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.compound;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject object, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray jsonArray = object.getJSONArray("tickers");
        for (int i=0;i<jsonArray.length();i++){
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if(jsonObject.getString("base").equalsIgnoreCase(checkerInfo.getCurrencyBase()) && jsonObject.getString("target").equalsIgnoreCase(checkerInfo.getCurrencyCounter())) {
                ticker.vol = ParseUtils.getDouble(jsonObject, "volume");
                ticker.last = ParseUtils.getDouble(jsonObject, "last");
                if (jsonObject.has("converted_last")) {
                    ticker.usd = ParseUtils.getDouble(jsonObject.getJSONObject("converted_last"), "usd");
                }
            }
        }

    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL;
    }


    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject object, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = object.getJSONArray("tickers");
        for (int i=0;i<jsonArray.length();i++){
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            //coin_id,target_coin_id
            list.add(new CurrencyPairInfo(jsonObject.getString("base").toUpperCase(),jsonObject.getString("target").toUpperCase(),jsonObject.getString("base")));
        }
    }
}
