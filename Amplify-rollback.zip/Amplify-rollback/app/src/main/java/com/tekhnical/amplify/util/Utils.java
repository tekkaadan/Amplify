package com.tekhnical.amplify.util;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.preference.ListPreference;
import androidx.viewpager.widget.PagerAdapter;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.dialog.DonateDialog;

public class Utils {
    private static final String GITHUB_URL = "https://github.com/mobnetic/BitcoinChecker/";
    private static final String BINANCE_URL = "https://www.binance.com/en/register?ref=10253058";
    private static final String FTX_URL = "https://ftx.com/#a=amplifytracker";
    public static final String APIKEY = "ZLUPW1012FY2Q53L";
    public static final String STOCKAPIKEY = "pk_1c542e08c9714dc2813f1954bb27700d";

    public static boolean checkStoragePermission(Activity activity){
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, 100);
            return false;
        }
        else
            return true;
    }
    public static String getMarketType(Context context, int type){
        return type == 1? context.getString(R.string.futures): type == 2? context.getString(R.string.stocks) : context.getString(R.string.spots);
    }
    public static void vibrate(Context context){
        Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        // Vibrate for 500 milliseconds
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            //deprecated in API 26
            v.vibrate(50);
        }
    }
    public static void showToast(Context context, int textResId) {
        showToast(context, textResId, false);
    }

    public static void showToast(Context context, int textResId, boolean isLong) {
        showToast(context, context.getString(textResId), isLong);
    }

    public static void showToast(Context context, String text) {
        showToast(context, text, false);
    }

    public static void showToast(Context context, String text, boolean isLong) {
        Toast.makeText(context.getApplicationContext(), text, isLong ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT).show();
    }

    public static void setViewError(TextView textView, int errorMsgResId) {
        setViewError(textView, (CharSequence) textView.getContext().getString(errorMsgResId));
    }

    public static void setViewError(TextView textView, CharSequence errorMsg) {
        textView.setFocusableInTouchMode(true);
        textView.requestFocus();
        textView.setError(errorMsg);
    }

    public static int getPixels(Context context, int dp) {
        return (int) (getPixelsF(context, (float) dp) + 0.5f);
    }

    public static float getPixelsF(Context context, float dp) {
        return context.getResources().getDisplayMetrics().density * dp;
    }

    public static int getSpPixels(Context context, int sp) {
        return (int) (TypedValue.applyDimension(2, (float) sp, context.getResources().getDisplayMetrics()) + 0.5f);
    }

    public static void setSelectionAfterLastLetter(EditText editTextView) {
        editTextView.setSelection(editTextView.getText().length());
    }

    public static boolean isNetworkConnectionAvailable(Context context) {
        NetworkInfo activeNetwork = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnectedOrConnecting();
    }

    public static boolean isIntentAvailable(Context context, Intent intent) {
        return context.getPackageManager().queryIntentActivities(intent, 65536).size() > 0;
    }

    public static void sendEmail(Context context, String emailAddress, String subject) {
        try {
            Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto", emailAddress, null));
            emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
            context.startActivity(Intent.createChooser(emailIntent, context.getString(R.string.generic_send_email)));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static boolean goToGooglePlay(Context context, String packageName) {
        return goToWebPage(context, "market://details?id=" + packageName);
    }

    public static boolean goToWebPage(Context context, String address) {
        try {
            context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(address)));
            return true;
        } catch (Throwable th) {
            return false;
        }
    }

    public static boolean goToGitHub(Context context) {
        return goToWebPage(context, GITHUB_URL);
    }

    public static boolean goToGitHubIssues(Context context) {
        return goToWebPage(context, GITHUB_URL+"issues");
    }

    public static void hideKeyboard(Context context, View editText) {
        try {
            ((InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(editText.getWindowToken(), 0);
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    public static void showKeyboard(Context context, View editText) {
        editText.requestFocus();
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(editText, 1);
        imm.restartInput(editText);
    }

    public static boolean handleIntListOnPreferenceChange(ListPreference listPreference, Object newValue) {
        try {
            CharSequence[] entries = listPreference.getEntries();
            int index = listPreference.findIndexOfValue((String) newValue);
            if (index < 0 || index >= entries.length) {
                index = 0;
            }
            listPreference.setSummary(listPreference.getEntries()[index]);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void showDonateDialog(Context mContext) {

        DonateDialog cDialog = new DonateDialog(mContext);
        cDialog.setTitle(mContext.getString(R.string.settings_about_donate_title));
        cDialog.setPositiveButton(mContext.getString(R.string.settings_about_donate_title), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cDialog.dismiss();
            }
        });
        cDialog.setAdapter(new PagerAdapter() {
            @Override
            public int getCount() {
                return 2;
            }

            @NonNull
            @Override
            public Object instantiateItem(@NonNull ViewGroup container, int position) {
                LayoutInflater inflater = LayoutInflater.from(mContext);
                View layout = null;
                if (position == 0){
                    layout = inflater.inflate(R.layout.fragment_bitcoin,container,false);
                    TextView codeTv= layout.findViewById(R.id.code_tv);
                    ImageView copyView = layout.findViewById(R.id.copy_code_iv);
                    copyView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            copyToClipboard(codeTv.getText().toString());
                        }
                    });
                }
                else{
                    layout = inflater.inflate(R.layout.fragment_eth,container,false);
                    TextView codeTv= layout.findViewById(R.id.code_tv);
                    ImageView copyView = layout.findViewById(R.id.copy_code_iv);
                    copyView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            copyToClipboard(codeTv.getText().toString());
                        }
                    });
                }
                container.addView(layout);
                return layout;
            }

            private void copyToClipboard(String text){
                ClipboardManager clipboard = (ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("CODE",text);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(mContext, "Copied to clipboard", Toast.LENGTH_SHORT).show();
            }
            @Override
            public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
                return view == object;
            }

            @Nullable
            @Override
            public CharSequence getPageTitle(int position) {
                if(position == 0)
                    return "BTC";
                else
                    return "ETH";
            }
        });
        cDialog.show();
    }

    public static void showTradingDialog(Context mContext) {

        DonateDialog cDialog = new DonateDialog(mContext);
        cDialog.setTitle(mContext.getString(R.string.settings_about_trading_title));
        cDialog.setPositiveButton(mContext.getString(R.string.settings_about_trading_signup), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cDialog.donatePager.getCurrentItem() == 0)
                    goToWebPage(mContext,BINANCE_URL);
                else
                    goToWebPage(mContext,FTX_URL);
            }
        });
        cDialog.setAdapter(new PagerAdapter() {
            @Override
            public int getCount() {
                return 2;
            }

            @NonNull
            @Override
            public Object instantiateItem(@NonNull ViewGroup container, int position) {
                LayoutInflater inflater = LayoutInflater.from(mContext);
                View layout = null;
                if (position == 0){
                    layout = inflater.inflate(R.layout.fragment_trading,container,false);
                    ImageView icon = layout.findViewById(R.id.trading_iv);
                    icon.setImageResource(R.drawable.bnb_trading);
                    TextView codeTv= layout.findViewById(R.id.code_tv);
                    codeTv.setText(BINANCE_URL);
                    ImageView copyView = layout.findViewById(R.id.copy_code_iv);
                    copyView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            copyToClipboard(codeTv.getText().toString());
                        }
                    });
                }
                else{
                    layout = inflater.inflate(R.layout.fragment_trading,container,false);
                    ImageView icon = layout.findViewById(R.id.trading_iv);
                    icon.setImageResource(R.drawable.ftx_trading);
                    TextView codeTv= layout.findViewById(R.id.code_tv);
                    codeTv.setText(FTX_URL);
                    ImageView copyView = layout.findViewById(R.id.copy_code_iv);
                    copyView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            copyToClipboard(codeTv.getText().toString());
                        }
                    });
                }
                container.addView(layout);
                return layout;
            }

            private void copyToClipboard(String text){
                ClipboardManager clipboard = (ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("CODE",text);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(mContext, "Copied to clipboard", Toast.LENGTH_SHORT).show();
            }
            @Override
            public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
                return view == object;
            }

            @Nullable
            @Override
            public CharSequence getPageTitle(int position) {
                if(position == 0)
                    return "BINANCE";
                else
                    return "FTX";
            }
        });
        cDialog.show();
    }
}
