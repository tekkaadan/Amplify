package com.tekhnical.amplify.model.market;

import android.util.Log;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class Huobi extends Market {
    private static final String NAME = "Huobi";
    private static final String TTS_NAME = "Huobi";
    private static final String URL = "https://api.huobi.pro/market/detail/merged?symbol=%s%s";
    private static final String URL_CURRENCY_PAIRS = "https://api.huobi.pro/v1/common/symbols";

    public Huobi() {
        super("huobi","Huobi", "Huobi", null);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyBaseLowerCase(), checkerInfo.getCurrencyCounterLowerCase()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Huobi.png";
        //return "https://assets.coingecko.com/markets/images/25/small/1481589873352_.pic_hd.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.huobi;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject tickerJsonObject = jsonObject.getJSONObject("tick");
        Log.e("HUOBI",tickerJsonObject.toString());
        if(tickerJsonObject.has("bid")) {
            ticker.bid = convert(tickerJsonObject.getJSONArray("bid").getDouble(0));
        }
        if (tickerJsonObject.has("ask")) {
            ticker.ask = convert(tickerJsonObject.getJSONArray("ask").getDouble(0));
        }
        ticker.vol = convert(tickerJsonObject.getDouble("vol"));
        ticker.high = convert(tickerJsonObject.getDouble("high"));
        ticker.low = convert(tickerJsonObject.getDouble("low"));
        ticker.last = convert(tickerJsonObject.getDouble("close"));
    }

    public Double convert(double value){
        DecimalFormat df = new DecimalFormat("0.##E0");
        String formattedVal = df.format(value);
        return Double.parseDouble(formattedVal);
    }
    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> pairs) throws Exception {
        if ("ok".equalsIgnoreCase(jsonObject.getString("status"))) {
            JSONArray data = jsonObject.getJSONArray("data");
            for (int i = 0; i < data.length(); i++) {
                pairs.add(new CurrencyPairInfo(ParseUtils.getString(data.getJSONObject(i),"base-currency").toUpperCase(Locale.US), ParseUtils.getString(data.getJSONObject(i),"quote-currency").toUpperCase(Locale.US), null));
            }
            return;
        }
        throw new Exception("Parse currency pairs error.");
    }
}
