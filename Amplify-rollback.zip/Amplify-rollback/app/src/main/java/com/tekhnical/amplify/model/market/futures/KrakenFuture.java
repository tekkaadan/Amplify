package com.tekhnical.amplify.model.market.futures;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.FuturesMarket;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class KrakenFuture extends FuturesMarket {
    public static final String ID = "kraken_futures";
    private static final String NAME = "Kraken Future";
    private static final String TTS_NAME = "Kraken Future";
    private static final String URL = "https://futures.kraken.com/derivatives/api/v3/tickers";
    private static final String URL_CURRENCY_PAIRS = "https://futures.kraken.com/derivatives/api/v3/tickers";

    public KrakenFuture() {
        super(ID,NAME, TTS_NAME, null,new int[]{3,5,6});
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo, int contractType) {
        return URL;
    }

    private String fixCurrency(String currency) {
        if (VirtualCurrency.BTC.equals(currency)) {
            return VirtualCurrency.XBT;
        }
        if (VirtualCurrency.VEN.equals(currency)) {
            return VirtualCurrency.XVN;
        }
        if (VirtualCurrency.DOGE.equals(currency)) {
            return VirtualCurrency.XDG;
        }
        return currency;
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/KrakenFutures.png";
    }
*/
    @Override
    public int getImageUrl() {
        return R.drawable.kraken_futures;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray jsonArray = jsonObject.getJSONArray("tickers");
        for (int i=0;i<jsonArray.length();i++) {
            JSONObject pairObject = jsonArray.getJSONObject(i);
            if (pairObject.getString("symbol").equalsIgnoreCase(checkerInfo.getCurrencyPairId())) {
                ticker.bid = ParseUtils.getDouble(pairObject, "bid");
                ticker.ask = ParseUtils.getDouble(pairObject, "ask");
                ticker.vol = ParseUtils.getDouble(pairObject, "vol24h");
                ticker.last = ParseUtils.getDouble(pairObject, "last");
            }
        }
    }

    private double getDoubleFromJsonArrayObject(JSONObject jsonObject, String arrayKey) throws Exception {
        if(jsonObject.has(arrayKey)) {
            JSONArray jsonArray = jsonObject.getJSONArray(arrayKey);
            if (jsonArray.length() > 0)
                return Double.parseDouble(jsonArray.getString(0));
        }
        return 0.0d;
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = jsonObject.getJSONArray("tickers");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject pairObject = jsonArray.getJSONObject(i);
            if (pairObject.has("pair")) {
                String[] splits = pairObject.getString("pair").split(":");
                if (splits.length>=2)
                    pairs.add(new CurrencyPairInfo(splits[0],splits[1], pairObject.getString("symbol")));
            }
        }
    }

    private String parseCurrency(String currency) {
        if (currency != null && currency.length() >= 2) {
            char firstChar = currency.charAt(0);
            if (firstChar == 'Z' || firstChar == 'X') {
                currency = currency.substring(1);
            }
        }
        if (VirtualCurrency.XBT.equals(currency)) {
            return VirtualCurrency.BTC;
        }
        if (VirtualCurrency.XVN.equals(currency)) {
            return VirtualCurrency.VEN;
        }
        if (VirtualCurrency.XDG.equals(currency)) {
            return VirtualCurrency.DOGE;
        }
        return currency;
    }
}
