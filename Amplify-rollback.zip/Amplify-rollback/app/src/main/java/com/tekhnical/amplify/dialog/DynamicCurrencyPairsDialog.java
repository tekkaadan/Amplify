package com.tekhnical.amplify.dialog;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.TextView;

import androidx.cardview.widget.CardView;

import butterknife.ButterKnife;
import butterknife.BindView;
import com.android.volley.RequestQueue;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.util.AsyncTaskCompat;
import com.tekhnical.amplify.util.CheckErrorsUtils;
import com.tekhnical.amplify.util.CurrencyPairsMapHelper;
import com.tekhnical.amplify.util.FormatUtils;
import com.tekhnical.amplify.util.HttpsHelper;
import com.tekhnical.amplify.volley.DynamicCurrencyPairsVolleyAsyncTask;
import com.nineoldandroids.animation.ObjectAnimator;
import com.nineoldandroids.animation.ValueAnimator;
import com.nineoldandroids.view.ViewHelper;

public abstract class DynamicCurrencyPairsDialog extends Dialog implements OnDismissListener {
    private CurrencyPairsMapHelper currencyPairsMapHelper;
    private DynamicCurrencyPairsVolleyAsyncTask dynamicCurrencyPairsVolleyAsyncTask;
    private final Market market;
    @BindView(R.id.refreshImageView)
    View refreshImageView;
    @BindView(R.id.refreshImageWrapper)
    View refreshImageWrapper;
    private final RequestQueue requestQueue;
    private ValueAnimator rotateAnim;
    @BindView(R.id.statusView)
    TextView statusView;
    @BindView(R.id.dialog_parent)
    CardView parentCard;
    public abstract void onPairsUpdated(Market market2, CurrencyPairsMapHelper currencyPairsMapHelper2);

    @SuppressLint({"InflateParams"})
    protected DynamicCurrencyPairsDialog(Context context, Market market2, CurrencyPairsMapHelper currencyPairsMapHelper2) {
        super(context);
        getWindow().getAttributes().windowAnimations = R.style.ExitDialogAnimation;
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        //setInverseBackgroundForced(true);
        this.requestQueue = HttpsHelper.newRequestQueue(context);
        this.market = market2;
        this.currencyPairsMapHelper = currencyPairsMapHelper2;
        //setTitle(R.string.checker_add_dynamic_currency_pairs_dialog_title);
        //setButton(-3, context.getString(R.string.ok), (OnClickListener) null);
        setContentView(R.layout.dynamic_currency_pairs_dialog);
        getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        ButterKnife.bind(this);
        int theme = MyApplication.getAppTheme(getContext());
        if (theme == 3) {
            findViewById(R.id.dialog_button_layout).setBackgroundResource(R.drawable.custom_dialog_button_gray);
            parentCard.setCardBackgroundColor(getContext().getResources().getColor(R.color.theme_gray_light));
            refreshImageWrapper.setBackgroundResource(R.drawable.dialog_button_gray);
        }
        else if (theme == 4) {
            findViewById(R.id.dialog_button_layout).setBackgroundResource(R.drawable.custom_dialog_button_sepia);
            parentCard.setCardBackgroundColor(getContext().getResources().getColor(R.color.theme_sepia_light));
            refreshImageWrapper.setBackgroundResource(R.drawable.dialog_button_sepia);
        }
        TextView titleView = findViewById(R.id.dialog_title);
        titleView.setText(R.string.checker_add_dynamic_currency_pairs_dialog_title);
        findViewById(R.id.ok_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        setOnDismissListener(this);
        this.refreshImageWrapper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DynamicCurrencyPairsDialog.this.startRefreshing();
            }
        });
        refreshStatusView(null);
        //setView(view);
    }

    public void onDismiss(DialogInterface dialog) {
        this.requestQueue.cancelAll((Object) this);
        if (this.dynamicCurrencyPairsVolleyAsyncTask != null) {
            this.dynamicCurrencyPairsVolleyAsyncTask.cancel(true);
        }
        this.currencyPairsMapHelper = null;
    }

    private void startRefreshing() {
        setCancelable(false);
        startRefreshingAnim();
        this.dynamicCurrencyPairsVolleyAsyncTask = new DynamicCurrencyPairsVolleyAsyncTask(this.requestQueue, getContext(), this.market, new Listener<CurrencyPairsMapHelper>() {
            public void onResponse(CurrencyPairsMapHelper currencyPairsMapHelper) {
                DynamicCurrencyPairsDialog.this.dynamicCurrencyPairsVolleyAsyncTask = null;
                DynamicCurrencyPairsDialog.this.currencyPairsMapHelper = currencyPairsMapHelper;
                DynamicCurrencyPairsDialog.this.refreshStatusView(null);
                DynamicCurrencyPairsDialog.this.stopRefreshingAnim();
                DynamicCurrencyPairsDialog.this.onPairsUpdated(DynamicCurrencyPairsDialog.this.market, currencyPairsMapHelper);
            }
        }, new ErrorListener() {
            public void onErrorResponse(VolleyError error) {
                DynamicCurrencyPairsDialog.this.dynamicCurrencyPairsVolleyAsyncTask = null;
                error.printStackTrace();
                DynamicCurrencyPairsDialog.this.refreshStatusView(CheckErrorsUtils.parseErrorMsg(DynamicCurrencyPairsDialog.this.getContext(), error));
                DynamicCurrencyPairsDialog.this.stopRefreshingAnim();
            }
        });
        AsyncTaskCompat.execute(this.dynamicCurrencyPairsVolleyAsyncTask, new Void[0]);
    }

    private void refreshStatusView(String errorMsg) {
        String dateString;
        if (this.currencyPairsMapHelper == null || this.currencyPairsMapHelper.getDate() <= 0) {
            dateString = getContext().getString(R.string.checker_add_dynamic_currency_pairs_dialog_last_sync_never);
        } else {
            dateString = FormatUtils.formatSameDayTimeOrDate(getContext(), this.currencyPairsMapHelper.getDate());
        }
        this.statusView.setText(getContext().getString(R.string.checker_add_dynamic_currency_pairs_dialog_last_sync, new Object[]{dateString}));
        if (this.currencyPairsMapHelper != null && this.currencyPairsMapHelper.getPairsCount() > 0) {
            this.statusView.append("\n" + getContext().getString(R.string.checker_add_dynamic_currency_pairs_dialog_pairs, new Object[]{Integer.valueOf(this.currencyPairsMapHelper.getPairsCount())}));
        }
        if (errorMsg != null) {
            this.statusView.append("\n" + CheckErrorsUtils.formatError(getContext(), errorMsg));
        }
    }

    public void startRefreshingAnim() {
        setCancelable(false);
        this.refreshImageWrapper.setEnabled(false);
        this.rotateAnim = ObjectAnimator.ofFloat((Object) this.refreshImageView, "rotation", 0.0f, 360.0f);
        this.rotateAnim.setDuration(750);
        this.rotateAnim.setInterpolator(new AccelerateDecelerateInterpolator());
        this.rotateAnim.setRepeatCount(-1);
        this.rotateAnim.setRepeatMode(1);
        this.rotateAnim.start();
    }

    public void stopRefreshingAnim() {
        setCancelable(true);
        this.refreshImageWrapper.setEnabled(true);
        if (this.rotateAnim != null) {
            this.rotateAnim.cancel();
            this.rotateAnim = null;
            ViewHelper.setRotation(this.refreshImageView, 0.0f);
        }
    }
}
