package com.tekhnical.amplify.fragment.generic;

import android.os.Bundle;
import android.speech.tts.TextToSpeech.OnInitListener;

import androidx.preference.PreferenceFragmentCompat;

import com.tekhnical.amplify.util.TTSHelper;

public class TTSAwareFragment extends PreferenceFragmentCompat implements OnInitListener {
    private boolean isTTSAvailable;

    public void onCreate(Bundle paramBundle) {
        super.onCreate(paramBundle);
        onCreateBeforeInitTTS(paramBundle);
        TTSHelper.initTTS(getActivity(), this);
    }

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {

    }

    public void onCreateBeforeInitTTS(Bundle paramBundle) {
    }

    public boolean isTTSAvailable() {
        return this.isTTSAvailable;
    }

    public void onTTSAvailable(boolean available) {
    }

    public final void onInit(int status) {
        this.isTTSAvailable = TTSHelper.isStatusSuccess(status);
        onTTSAvailable(this.isTTSAvailable);
    }
}
