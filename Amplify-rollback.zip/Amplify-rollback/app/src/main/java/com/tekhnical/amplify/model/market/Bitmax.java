package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Bitmax extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String ID = "bitmax";
    private static final String NAME = "BitMax";
    private static final String TTS_NAME = "BitMax";
//    private static final String URL = "https://bitmax.io/api/pro/v1/ticker?symbol=%1$s";
//    private static final String CURRENCIES_URL = "https://bitmax.io/api/pro/v1/products";
    private static final String URL = "https://api.coingecko.com/api/v3/exchanges/"+ID+"/tickers?coin_ids=%1$s";
    private static final String CURRENCY_URL = "https://api.coingecko.com/api/v3/exchanges/"+ID+"/tickers?page=%1$s";

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return  String.format(URL,checkerInfo.getCurrencyBaseLowerCase());
    }
    public String getCurrencyPairsUrl(int requestId) {
        return String.format(CURRENCY_URL,requestId);
    }
    public Bitmax() {
        super("bitmax", NAME, TTS_NAME, null);
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/BitMax.png";
        //return "https://assets.coingecko.com/markets/images/6/small/bithumb_BI.png";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.bitmax;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject object, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray jsonArray = object.getJSONArray("tickers");
        for (int i=0;i<jsonArray.length();i++){
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if((jsonObject.getString("base").equalsIgnoreCase(checkerInfo.getCurrencyBase())) && jsonObject.getString("target").equalsIgnoreCase(checkerInfo.getCurrencyCounter())) {
                ticker.vol = ParseUtils.getDouble(jsonObject, "volume");
                ticker.last = ParseUtils.getDouble(jsonObject, "last");
                if (jsonObject.has("converted_last")) {
                    ticker.usd = ParseUtils.getDouble(jsonObject.getJSONObject("converted_last"), "usd");
                }
            }
        }

    }

    @Override
    public int getCurrencyPairsNumOfRequests() {
        return 4;
    }

    @Override
    public int getNumOfRequests(CheckerInfo checkerInfo) {
        return 4;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject object, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = object.getJSONArray("tickers");
        for (int i=0;i<jsonArray.length();i++){
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            //coin_id,target_coin_id
            list.add(new CurrencyPairInfo(jsonObject.getString("base").toUpperCase(),jsonObject.getString("target").toUpperCase(),jsonObject.getString("base")));
        }
    }
    /*
    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject("data");
        ticker.last = ParseUtils.getDouble(jsonObject, "close");
        ticker.high = ParseUtils.getDouble(jsonObject, "high");
        ticker.low = ParseUtils.getDouble(jsonObject, "low");
        ticker.vol = ParseUtils.getDouble(jsonObject, "volume");
        ticker.bid = getFirstPriceFromOrder(jsonObject, "bid");
        ticker.ask = getFirstPriceFromOrder(jsonObject, "ask");

    }

    private double getFirstPriceFromOrder(JSONObject jsonObject, String key) throws Exception {
        JSONArray array = jsonObject.getJSONArray(key);
        if (array.length() == 0) {
            return -1.0d;
        }
        return Double.parseDouble(array.getString(0));
    }
    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = json.getJSONArray("data");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("symbol")){
                list.add(new CurrencyPairInfo(jsonObject.getString("baseAsset"),jsonObject.getString("quoteAsset"),jsonObject.getString("symbol")));
            }
        }
    }*/

}
