package com.tekhnical.amplify.alarm;

import androidx.appcompat.app.AppCompatActivity;

public class AlarmDialogActivity extends AppCompatActivity {
}
