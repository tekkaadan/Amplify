package com.tekhnical.amplify.activity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import androidx.annotation.NonNull;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.generic.SimpleFragmentSubActivity;
import com.tekhnical.amplify.fragment.SettingsMainFragment;
import com.tekhnical.amplify.util.SoundFilesManager;
import com.tekhnical.amplify.util.Utils;

public class SettingsMainActivity extends SimpleFragmentSubActivity<SettingsMainFragment> {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.setContentTheme(true);
        super.onCreate(savedInstanceState);
        if(Utils.checkStoragePermission(this)) {
            SoundFilesManager.installRingtonesIfNeeded(this);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 ){
            if (grantResults.length>0 && grantResults[0]== PackageManager.PERMISSION_GRANTED){
                SoundFilesManager.installRingtonesIfNeeded(this);
            }
        }
    }


    @Override
    public int getContentViewResId() {
        return R.layout.setting_main_activity;
    }

    @Override
    public String getContentViewTitle() {
        return getString(R.string.settings_activity_title);
    }

    @Override
    public SettingsMainFragment createChildFragment() {
        return new SettingsMainFragment();
    }

    public static void startSettingsMainActivity(Context context, boolean showDonateDialog) {
        Intent intent = new Intent(context, SettingsMainActivity.class);
        context.startActivity(intent);
        //startSimpleDonateFragmentActivity(context, SettingsMainActivity.class, showDonateDialog);
    }
}
