package com.tekhnical.amplify.fragment;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.ListFragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.core.view.MenuItemCompat;

import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.MarketPickerListActivity;
import com.tekhnical.amplify.activity.SuggestNewExchangeActivity;
import com.tekhnical.amplify.adapter.MarketPickerListAdapter;
import com.tekhnical.amplify.config.MarketsConfig;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.util.PreferencesUtils;
import com.tekhnical.amplify.util.Utils;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MarketPickerListFragment extends ListFragment implements SearchView.OnQueryTextListener {
    public static final int SORT_MODE_ALPHABETICALLY = 0;
    public static final int SORT_MODE_NEWEST_FIRST = 1;
    private MarketPickerListAdapter adapter;
    private String searchQuery;
    private SearchView searchView;

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.adapter = new MarketPickerListAdapter(getActivity(), getActivity().getIntent().getStringExtra(MarketPickerListActivity.EXTRA_MARKET_KEY));
        getListView().setOnItemLongClickListener(this.adapter);
        this.searchQuery = savedInstanceState != null ? savedInstanceState.getString("searchQuery") : null;
        setHasOptionsMenu(true);
        getNewList();
    }

    public void onSaveInstanceState(Bundle outState) {
        outState.putString("searchQuery", this.searchQuery);
        super.onSaveInstanceState(outState);
    }

    public void onDestroyView() {
        super.onDestroyView();
        this.adapter = null;
    }

    private void getNewList() {
        boolean z = true;
        if (PreferencesUtils.getMarketPickerListSortMode(getActivity()) != 1) {
            z = false;
        }
        getNewList(z);
    }

    private void getNewList(boolean newestFirst) {
        List<Market> items = new ArrayList<>();
        Collection<Market> marketsList = null;
        if (MyApplication.appMarketType == 1)
            marketsList = MarketsConfig.FUTURE_MARKETS.values();
        else
            marketsList = MarketsConfig.MARKETS.values();
        if (newestFirst) {
            for (Market market : marketsList) {
                items.add(0, market);
            }
        } else {
            items.addAll(marketsList);
            Collections.sort(items, new Comparator<Market>() {
                public int compare(Market lhs, Market rhs) {
                    if (lhs.name == null || rhs == null) {
                        return 0;
                    }
                    return lhs.name.compareToIgnoreCase(rhs.name);
                }
            });
        }
        setNewList(items);
    }

    private void setNewList(List<Market> items) {
        this.adapter.swapItems(items);
        this.adapter.getFilter().filter(this.searchQuery);
        setListAdapter(this.adapter);
    }

    public void onListItemClick(@NonNull ListView l, @NonNull View v, int position, long id) {
        if (this.adapter != null) {
            Market market = this.adapter.getItem(position);
            if (market == null) {
                onSuggestMoreExchangesClicked();
                return;
            }
            Intent intent = new Intent();
            intent.putExtra(MarketPickerListActivity.EXTRA_MARKET_KEY, market.key);
            getActivity().setResult(Activity.RESULT_OK, intent);
            getActivity().finish();
        }
    }

    private void onSuggestMoreExchangesClicked() {
        SuggestNewExchangeActivity.startSettingsMainActivity(getActivity());
    }

    public boolean onBackPressed() {
        if (this.searchView == null || this.searchView.isIconified()) {
            return false;
        }
        this.searchView.setQuery("", true);
        this.searchView.setIconified(true);
        return true;
    }

    public void onCreateOptionsMenu(@NonNull Menu menu, MenuInflater inflater) {
        int checkedSortMenuItem;
        inflater.inflate(R.menu.market_picker_list_fragment, menu);
        switch (PreferencesUtils.getMarketPickerListSortMode(getActivity())) {
            case 1:
                checkedSortMenuItem = R.id.sortNewestFirstItem;
                break;
            default:
                checkedSortMenuItem = R.id.sortAlphabeticallyItem;
                break;
        }
        menu.findItem(checkedSortMenuItem).setChecked(true);
        this.searchView = (SearchView) MenuItemCompat.getActionView(menu.findItem(R.id.action_search));
        this.searchView.setOnQueryTextListener(this);
        this.searchView.setMinimumHeight(50);
        this.searchView.setQuery(this.searchQuery, false);
        if (!TextUtils.isEmpty(this.searchQuery)) {
            this.searchView.setIconified(false);
        }
        super.onCreateOptionsMenu(menu, inflater);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.sortAlphabeticallyItem) {
            PreferencesUtils.setMarketPickerListSortMode(getActivity(), 0);
            item.setChecked(true);
            getNewList(false);
            return true;
        } else if (item.getItemId() == R.id.sortNewestFirstItem) {
            PreferencesUtils.setMarketPickerListSortMode(getActivity(), 1);
            item.setChecked(true);
            getNewList(true);
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    public boolean onQueryTextChange(String searchQuery) {
        this.searchQuery = searchQuery;
        this.adapter.getFilter().filter(searchQuery);
        return true;
    }

    public boolean onQueryTextSubmit(String searchQuery) {
        Utils.hideKeyboard(getActivity(), this.searchView);
        return true;
    }
}
