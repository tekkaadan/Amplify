package com.tekhnical.amplify.activity;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.generic.SimpleFragmentSubActivity;
import com.tekhnical.amplify.fragment.CheckerAddAlarmFragment;
import com.tekhnical.amplify.content.AlarmRecord;
import com.tekhnical.amplify.content.CheckerRecord;

public class CheckerAddAlarmActivity extends SimpleFragmentSubActivity<CheckerAddAlarmFragment> {
    public static final String EXTRA_ALARM_RECORD = "alarm_record";
    public static final String EXTRA_ALARM_RECORD_INDEX = "alarm_record_index";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.setContentTheme(false);
        super.onCreate(savedInstanceState);
    }

    @Override
    public int getContentViewResId() {
        return R.layout.checker_add_alarm_activity;
    }

    @Override
    public CheckerAddAlarmFragment createChildFragment() {
        return CheckerAddAlarmFragment.newInstance((CheckerRecord) getIntent().getParcelableExtra(CheckerAddActivity.EXTRA_CHECKER_RECORD), (AlarmRecord) getIntent().getParcelableExtra(EXTRA_ALARM_RECORD));
    }

    public void finish() {
        int i = -1;
        Intent data = new Intent();
        boolean unsavedChanges = false;
        CheckerAddAlarmFragment fragment = (CheckerAddAlarmFragment) getChildFragment();
        if (fragment != null) {
            unsavedChanges = fragment.getUnsavedChanges();
            data.putExtra(EXTRA_ALARM_RECORD, fragment.getAlarmRecord());
        }
        data.putExtra(EXTRA_ALARM_RECORD_INDEX, getIntent().getIntExtra(EXTRA_ALARM_RECORD_INDEX, -1));
        if (!unsavedChanges) {
            i = 0;
        }
        setResult(i, data);
        super.finish();
    }

    public static void startCheckerAddAlarmActivity(Fragment fragment, int requestCode, CheckerRecord checkerRecord, AlarmRecord alarmRecord, int alarmRecordIndex) {
        Intent intent = new Intent(fragment.getActivity(), CheckerAddAlarmActivity.class);
        intent.putExtra(CheckerAddActivity.EXTRA_CHECKER_RECORD, checkerRecord);
        intent.putExtra(EXTRA_ALARM_RECORD, alarmRecord);
        intent.putExtra(EXTRA_ALARM_RECORD_INDEX, alarmRecordIndex);
        fragment.startActivityForResult(intent, requestCode);
    }
}
