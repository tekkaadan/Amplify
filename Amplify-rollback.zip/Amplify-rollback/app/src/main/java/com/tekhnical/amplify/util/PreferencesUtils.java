package com.tekhnical.amplify.util;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager;
import android.net.Uri;

import androidx.core.content.ContextCompat;
import androidx.preference.PreferenceManager;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.config.Settings;
import com.tekhnical.amplify.model.ExchangeModel;
import com.tekhnical.amplify.preferences.FrequencyPickerDialogPreference;
import com.robotoworks.mechanoid.Mechanoid;

import java.lang.reflect.Type;
import java.util.List;

public class PreferencesUtils {
    private static final String CHECKERS_LIST_SORT_MODE_KEY = "checkers_list_sort_mode";
    private static final String DEFAULT_ITEM_ADDED_KEY = "default_item_added";
    private static final String DONATION_MADE_KEY = "donation_made";
    private static final String EXCHANGE_TUTORIAL_DONE_KEY = "exchange_tutorial_done";
    private static final String MARKET_DEFAULT_KEY = "market_default";
    private static final String MARKET_PICKER_LIST_SORT_MODE_KEY = "market_picker_list_sort_mode";
    private static final String NEWS_SHOWN_KEY = "news_shown";
    private static final String DONATE_SHOWN_KEY = "donate_shown";
    private static final String USER_COUNTRY_KEY = "user_country";
    private static final String USER_DEFAULT_KEY = "user_default_screen";
    public static final String USER_DEFAULT_HINT_KEY = "user_default_screen_hint";
    public static final String USER_SYNC_HINT_KEY = "user_sync_hint";
    private static final String USER_GLOBAL_UPDATE_KEY = "user_global_update";
    private static final String ONBOARDING_KEY = "user_onboarding";
    private static final String EXCHNAGES = "user_exchanges_list";

    private static SharedPreferences getSharedPreferences(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context != null ? context.getApplicationContext() : Mechanoid.getApplicationContext());
    }

    public static void setExchanges(Context context, List<ExchangeModel> list) {
        Gson gson = new Gson();
        String json = gson.toJson(list);

        getSharedPreferences(context).edit().putString(EXCHNAGES, json).commit();
    }

    public static List<ExchangeModel> getExchanges(Context context){
        String json = getSharedPreferences(context).getString(EXCHNAGES, null);
        Type type = new TypeToken<List<ExchangeModel>>() {}.getType();
        return new Gson().fromJson(json,type);
    }

    public static boolean isDefaultItemAdded(Context context) {
        return getSharedPreferences(context).getBoolean(DEFAULT_ITEM_ADDED_KEY, false);
    }

    public static void setDefaultItemAdded(Context context) {
        getSharedPreferences(context).edit().putBoolean(DEFAULT_ITEM_ADDED_KEY, true).commit();
    }

    public static boolean wasNewsShown(Context context, int newsId) {
        return getSharedPreferences(context).getInt(NEWS_SHOWN_KEY, -1) >= newsId;
    }

    public static void setNewsShown(Context context, int newsId) {
        getSharedPreferences(context).edit().putInt(NEWS_SHOWN_KEY, newsId).commit();
    }
    public static int wasDonateShown(Context context) {
        return getSharedPreferences(context).getInt(DONATE_SHOWN_KEY, 0);
    }

    public static void setDonateShown(Context context, int newsId) {
        getSharedPreferences(context).edit().putInt(DONATE_SHOWN_KEY, newsId).commit();
    }

    public static boolean isExchangeTutorialDone(Context context) {
        return getSharedPreferences(context).getBoolean(EXCHANGE_TUTORIAL_DONE_KEY, false);
    }

    public static void setExchangeTutorialDone(Context context) {
        getSharedPreferences(context).edit().putBoolean(EXCHANGE_TUTORIAL_DONE_KEY, true).commit();
    }

    public static boolean getDonationMade(Context context) {
        return getSharedPreferences(context).getBoolean(DONATION_MADE_KEY, false);
    }

    public static void setDonationMade(Context context) {
        getSharedPreferences(context).edit().putBoolean(DONATION_MADE_KEY, true).commit();
    }

    public static int getCheckersListSortMode(Context context) {
        return getSharedPreferences(context).getInt(CHECKERS_LIST_SORT_MODE_KEY, 0);
    }

    public static void setCheckersListSortMode(Context context, int checkersListSortMode) {
        getSharedPreferences(context).edit().putInt(CHECKERS_LIST_SORT_MODE_KEY, checkersListSortMode).commit();
    }

    public static void setCheckGlobalFrequency(Context context, long frequency) {
        getSharedPreferences(context).edit().putLong(context.getString(R.string.settings_check_global_frequency_key), frequency).commit();
    }

    public static long getCheckGlobalFrequency(Context context) {
        return getSharedPreferences(context).getLong(context.getString(R.string.settings_check_global_frequency_key), FrequencyPickerDialogPreference.DEFAULT_FREQUENCY_MILLIS);
    }

    public static int getMarketPickerListSortMode(Context context) {
        return getSharedPreferences(context).getInt(MARKET_PICKER_LIST_SORT_MODE_KEY, 0);
    }

    public static void setMarketPickerListSortMode(Context context, int marketPickerListSortMode) {
        getSharedPreferences(context).edit().putInt(MARKET_PICKER_LIST_SORT_MODE_KEY, marketPickerListSortMode).commit();
    }

    public static String getMarketDefault(Context context) {
        String defaultVal="";
        if (MyApplication.appMarketType == 1)
            defaultVal="binance";
        else if(MyApplication.appMarketType == 0)
            defaultVal = "bitstamp";
        else
            defaultVal = "Default";
        return getSharedPreferences(context).getString(MARKET_DEFAULT_KEY, defaultVal);
    }

    public static void setMarketDefault(Context context, String marketDefault) {
        getSharedPreferences(context).edit().putString(MARKET_DEFAULT_KEY, marketDefault).commit();
    }

    public static String getUserCountry(Context context) {
        Settings.userCountry = getSharedPreferences(context).getString(USER_COUNTRY_KEY, null);
        return Settings.userCountry;
    }

    public static void setUserCountry(Context context, String userCountry) {
        Settings.userCountry = userCountry;
        getSharedPreferences(context).edit().putString(USER_COUNTRY_KEY, userCountry).commit();
    }
    public static void setUserHint(Context context, boolean hint) {
        getSharedPreferences(context).edit().putBoolean(ONBOARDING_KEY, hint).commit();
    }
    public static boolean getUserHint(Context context) {
        return getSharedPreferences(context).getBoolean(ONBOARDING_KEY, false);
    }

    public static void setUserDefault(Context context, int hint) {
        getSharedPreferences(context).edit().putInt(USER_DEFAULT_KEY, hint).commit();
    }
    public static int getUserDefault(Context context) {
        return getSharedPreferences(context).getInt(USER_DEFAULT_KEY, 1);
    }
    public static void setUserDefaultHint(Context context, boolean hint) {
        getSharedPreferences(context).edit().putBoolean(USER_DEFAULT_HINT_KEY, hint).commit();
    }
    public static boolean getUserDefaultHint(Context context) {
        return getSharedPreferences(context).getBoolean(USER_DEFAULT_HINT_KEY, false);
    }

    public static void setUserSyncHint(Context context, boolean hint) {
        getSharedPreferences(context).edit().putBoolean(USER_SYNC_HINT_KEY, hint).commit();
    }
    public static boolean getUserSyncHint(Context context) {
        return getSharedPreferences(context).getBoolean(USER_SYNC_HINT_KEY, false);
    }

    public static void setUserUpdate(Context context, int update) {
        getSharedPreferences(context).edit().putInt(USER_GLOBAL_UPDATE_KEY, update).commit();
    }
    public static int getUserUpdate(Context context) {
        return getSharedPreferences(context).getInt(USER_GLOBAL_UPDATE_KEY, 0);
    }

    public static void setCheckNotificationFearIndex(Context context, boolean enabled) {
        getSharedPreferences(context).edit().putBoolean(context.getString(R.string.settings_check_notification_fearindex_key), enabled).commit();
    }

    public static boolean getCheckNotificationFearIndex(Context context) {
        return getSharedPreferences(context).getBoolean(context.getString(R.string.settings_check_notification_fearindex_key), true);
    }

    public static void setCheckNotificationExpandable(Context context, boolean enabled) {
        getSharedPreferences(context).edit().putBoolean(context.getString(R.string.settings_check_notification_expandable_key), enabled).commit();
    }

    public static boolean getCheckNotificationExpandable(Context context) {
        return getSharedPreferences(context).getBoolean(context.getString(R.string.settings_check_notification_expandable_key), true);
    }

    public static void setCheckNotificationCustomLayout(Context context, boolean enabled) {
        getSharedPreferences(context).edit().putBoolean(context.getString(R.string.settings_check_notification_custom_layout_key), enabled).commit();
    }

    public static boolean getCheckNotificationCustomLayout(Context context) {
        return getSharedPreferences(context).getBoolean(context.getString(R.string.settings_check_notification_custom_layout_key), true);
    }

    public static void setCheckNotificationTicker(Context context, boolean enabled) {
        getSharedPreferences(context).edit().putBoolean(context.getString(R.string.settings_check_notification_ticker_key), enabled).commit();
    }
    public static boolean getCheckNotificationTicker(Context context) {
        return getSharedPreferences(context).getBoolean(context.getString(R.string.settings_check_notification_ticker_key), true);
    }

    public static void setCheckPortfolioTicker(Context context, String type, boolean enabled) {
        getSharedPreferences(context).edit().putBoolean(type, enabled).commit();
    }
    public static boolean getCheckPortfolioTicker(Context context, String type) {
        return getSharedPreferences(context).getBoolean(type, true);
    }

    public static String getSoundAlarmNotificationUp(Context context) {
        String uriString = null;
        if(ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            Uri defaultUri = SoundFilesManager.getUriForRingtone(context, SoundFilesManager.AMPLIFY_UP_CHEERS_FILENAME);
            uriString = getSharedPreferences(context).getString(context.getString(R.string.settings_sounds_alarm_notification_up_key), defaultUri != null ? defaultUri.toString() : null);

        }
        if (uriString == null) {
            return "android.resource://com.tekhnical.amplify/raw/corn_tracker_up_cheers";
        }
        return uriString;
    }

    public static void setSoundAlarmNotificationUp(Context context, String uri){
        getSharedPreferences(context).edit().putString(context.getString(R.string.settings_sounds_alarm_notification_up_key),uri).commit();
    }
    public static void setSoundAlarmNotificationDown(Context context, String uri){
        getSharedPreferences(context).edit().putString(context.getString(R.string.settings_sounds_alarm_notification_down_key),uri).commit();
    }
    public static String getSoundAlarmNotificationDown(Context context) {
        String uriString = null;
        if(ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {

            Uri defaultUri = SoundFilesManager.getUriForRingtone(context, SoundFilesManager.AMPLIFY_DOWN_ALERT_FILENAME);
            uriString = getSharedPreferences(context).getString(context.getString(R.string.settings_sounds_alarm_notification_down_key), defaultUri != null ? defaultUri.toString() : null);
        }
        if (uriString == null) {
            return "android.resource://com.tekhnical.amplify/raw/corn_tracker_down_alert";
        }
        return uriString;
    }

    public static int getSoundsAdvancedAlarmStream(Context context) {
        return getSharedPreferences(context).getInt(context.getString(R.string.settings_sounds_advanced_alarm_stream_key), 5);
    }

    public static boolean getTTSFormatSpeakBaseCurrency(Context context) {
        return getSharedPreferences(context).getBoolean(context.getString(R.string.settings_tts_format_speak_base_currency_key), true);
    }

    public static boolean getTTSFormatIntegerOnly(Context context) {
        return getSharedPreferences(context).getBoolean(context.getString(R.string.settings_tts_format_integer_only_key), true);
    }

    public static boolean getTTSFormatSpeakCounterCurrency(Context context) {
        return getSharedPreferences(context).getBoolean(context.getString(R.string.settings_tts_format_speak_counter_currency_key), false);
    }

    public static boolean getTTSFormatSpeakExchange(Context context) {
        return getSharedPreferences(context).getBoolean(context.getString(R.string.settings_tts_format_speak_exchange_key), false);
    }

    public static boolean getTTSDisplayOffOnly(Context context) {
        return getSharedPreferences(context).getBoolean(context.getString(R.string.settings_tts_screen_off_only_key), false);
    }

    public static boolean getTTSHeadphonesOnly(Context context) {
        return getSharedPreferences(context).getBoolean(context.getString(R.string.settings_tts_headphones_only_key), false);
    }

    public static int getTTSAdvancedStream(Context context) {
        return getSharedPreferences(context).getInt(context.getString(R.string.settings_tts_advanced_stream_key), 5);
    }

    private static Editor putDouble(Editor edit, String key, double value) {
        return edit.putLong(key, Double.doubleToRawLongBits(value));
    }

    private static double getDouble(SharedPreferences prefs, String key, double defaultValue) {
        return Double.longBitsToDouble(prefs.getLong(key, Double.doubleToLongBits(defaultValue)));
    }

    private static final void putObject(Context context, String key, Object obj) {
        String jsonString = null;
        if (obj != null) {
            try {
                jsonString = new Gson().toJson(obj);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        getSharedPreferences(context).edit().putString(key, jsonString).commit();
    }

    private static final <T> T getObject(Context context, String key, Class<T> clazz) {
        boolean z = false;
        try {
            return new Gson().fromJson(getSharedPreferences(context).getString(key, null), clazz);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
