package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;

import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class YoBit extends Market {
    private static final String NAME = "YoBit";
    private static final String TTS_NAME = "YoBit";
    private static final String URL = "https://yobit.net/api/3/ticker/%1$s";
    private static final String URL_CURRENCY_PAIRS = "https://yobit.net/api/3/info";

    public YoBit() {
        super("yobit",NAME, TTS_NAME, null);
    }

    /*public int getCautionResId() {
        return R.string.market_caution_yobit;
    }*/

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/yobit.png";
        //return "https://assets.coingecko.com/markets/images/46/small/yobit.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.yobit;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject tickerJsonObject = jsonObject.getJSONObject(jsonObject.names().getString(0));
        ticker.bid = tickerJsonObject.getDouble("buy");
        ticker.ask = tickerJsonObject.getDouble("sell");
        ticker.vol = tickerJsonObject.getDouble("vol");
        ticker.high = tickerJsonObject.getDouble("high");
        ticker.low = tickerJsonObject.getDouble("low");
        ticker.last = tickerJsonObject.getDouble("last");
        ticker.timestamp = tickerJsonObject.getLong("updated");
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray pairsNames = jsonObject.getJSONObject("pairs").names();
        for (int i = 0; i < pairsNames.length(); i++) {
            String pairId = pairsNames.getString(i);
            if (pairId != null) {
                String[] currencies = pairId.split("_");
                if (currencies.length == 2) {
                    pairs.add(new CurrencyPairInfo(currencies[0].toUpperCase(Locale.ENGLISH), currencies[1].toUpperCase(Locale.ENGLISH), pairId));
                }
            }
        }
    }
}
