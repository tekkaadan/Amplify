package com.tekhnical.amplify.view.generic;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.dialog.CustomDialog;
import com.tekhnical.amplify.dialog.ScreenDialog;

public abstract class ScreenDialogPreference extends ViewPreference {
    private ScreenDialog dialog;
    private CharSequence dialogTitle;

    public abstract CharSequence getEntry();

    public abstract void onPrepareDialog(ScreenDialog builder);

    public ScreenDialogPreference(Context context) {
        super(context);
    }

    public ScreenDialogPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @TargetApi(11)
    public ScreenDialogPreference(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    public void init(Context context, AttributeSet attrs) {
        super.init(context, attrs);
        if (attrs != null) {
            TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.ViewDialogPreference);
            setDialogTitle(a.getString(R.styleable.ViewDialogPreference_android_dialogTitle));
            a.recycle();
        }
    }

    public void setDialogTitle(CharSequence dialogTitle2) {
        if (TextUtils.isEmpty(dialogTitle2)) {
            dialogTitle2 = getTitle();
        }
        this.dialogTitle = dialogTitle2;
    }

    public CharSequence getDialogTitle() {
        return this.dialogTitle;
    }

    public void onClick(View v) {
//        Builder builder = new Builder(getContext());
//        builder.setInverseBackgroundForced(true);
//        builder.setTitle(this.dialogTitle);
//        builder.setNegativeButton(R.string.cancel, null);
        this.dialog = new ScreenDialog(getContext());
        this.dialog.setTitle(this.dialogTitle);
        onPrepareDialog(this.dialog);
        this.dialog.show();
    }

    public void dismiss() {
        this.dialog.dismiss();
    }

}
