package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Kyber extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Kyber";
    private static final String TTS_NAME = "Kyber";
    private static final String URL = "https://api.kyber.network/market";

    public Kyber() {
        super("kyber_network", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return URL;
    }

    @Override
    public int getImageUrl() {
        return R.drawable.kyber;
    }
    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/ZBG.png";
        //return "https://assets.coingecko.com/markets/images/256/small/zbg-exchange.jpg";
    }*/

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject json, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray jsonArray = json.getJSONArray("data");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("pair") && jsonObject.getString("pair").equalsIgnoreCase(checkerInfo.getCurrencyPairId())) {
                ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "current_bid");
                ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "current_ask");
                ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last_traded");
                ticker.low = ParseUtils.getDoubleFromString(jsonObject, "past_24h_low");
                ticker.high = ParseUtils.getDoubleFromString(jsonObject, "past_24h_high");
                ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "token_24h_volume");

                if (jsonObject.has("timestamp"))
                    ticker.timestamp = Long.parseLong(jsonObject.getString("timestamp"));
            }
        }
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = jsonObject.getJSONArray("data");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject pairObject = jsonArray.getJSONObject(i);
            if (pairObject.has("pair")) {
                list.add(new CurrencyPairInfo(pairObject.getString("base_symbol").toUpperCase(),pairObject.getString("quote_symbol").toUpperCase(),pairObject.getString("pair")));
            }
        }
    }

}
