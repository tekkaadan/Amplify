package com.tekhnical.amplify.alarm;

public class AlarmReceiver {
}
