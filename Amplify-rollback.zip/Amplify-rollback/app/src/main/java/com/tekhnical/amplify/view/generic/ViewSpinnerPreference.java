package com.tekhnical.amplify.view.generic;

import android.annotation.TargetApi;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.BaseAdapter;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.fragment.SpinnerDialogFragment;

import java.util.Arrays;

public class ViewSpinnerPreference extends ViewPreference {
    private BaseAdapter adapter;
    private String[] entries;
    private OnItemSelectedListener onItemSelectedListener;
    private int selection = -1;

    public interface OnItemSelectedListener {
        boolean onItemSelected(ViewSpinnerPreference viewSpinnerPreference, int i);
    }

    public ViewSpinnerPreference(Context context) {
        super(context);
    }

    public ViewSpinnerPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @TargetApi(11)
    public ViewSpinnerPreference(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public void setEntries(String[] entries2) {
        setEntriesAndSelection(entries2, 0);
    }

    public void setEntriesAndSelection(String[] entries2, int selection2) {
        this.entries = entries2;
        setSelection(selection2);
    }

    public void setEntriesAndSelection(BaseAdapter adapter2, String[] entries2, int selection2) {
        this.adapter = adapter2;
        setEntriesAndSelection(entries2, selection2);
    }

    public CharSequence[] getEntries() {
        return this.entries;
    }

    public CharSequence getEntry() {
        if (this.entries == null || this.selection < 0 || this.selection >= this.entries.length) {
            return null;
        }
        return this.entries[this.selection];
    }

    public void setSelection(int selection2) {
        setSelection(selection2, true);
    }

    public void setSelection(int selection2, boolean notifyChange) {
        if (getSelection() != selection2 && (!notifyChange || this.onItemSelectedListener == null || this.onItemSelectedListener.onItemSelected(this, selection2))) {
            this.selection = selection2;
        }
        setSummary(getEntry());
    }

    public int getSelection() {
        return this.selection;
    }

    public void onClick(View v) {
        SpinnerDialogFragment fragment = SpinnerDialogFragment.getInstance(this.entries,new ItemClickListener(){

            @Override
            public void OnItemClick(String item) {
                ViewSpinnerPreference.this.setSelection(Arrays.asList(entries).indexOf(item));
            }
        });

        fragment.setStyle(DialogFragment.STYLE_NO_FRAME, R.style.TransparentDialog);
        fragment.show(((FragmentActivity) getContext()).getSupportFragmentManager(), "SPINNER");
    }
    public interface ItemClickListener{
        public void OnItemClick(String item);
    }
    /*@Override
    public void onPrepareDialog(CustomDialog builder) {
        if (this.adapter == null) {
            builder.setSingleChoiceItems(this.entries, this.selection, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ViewSpinnerPreference.this.setSelection(which);
                    dialog.dismiss();
                }
            });
        } else {
            builder.setSingleChoiceItems(this.adapter, this.selection, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ViewSpinnerPreference.this.setSelection(which);
                    dialog.dismiss();
                }
            });
        }
    }*/

    public void setOnItemSelectedListener(OnItemSelectedListener onItemSelectedListener2) {
        this.onItemSelectedListener = onItemSelectedListener2;
    }
}
