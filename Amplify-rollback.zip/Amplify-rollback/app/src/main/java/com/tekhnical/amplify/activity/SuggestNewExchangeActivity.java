package com.tekhnical.amplify.activity;

import android.app.Activity;
import androidx.fragment.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.TextView;
import butterknife.ButterKnife;
import butterknife.BindView;
import butterknife.OnClick;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.generic.SimpleDonateFragmentSubActivity;
import com.tekhnical.amplify.util.Utils;

public class SuggestNewExchangeActivity extends SimpleDonateFragmentSubActivity<Fragment> {
    @BindView(R.id.suggestButton)
    View suggestButton;
    @BindView(R.id.textView)
    TextView textView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ButterKnife.bind((Activity) this);
        this.textView.setMovementMethod(LinkMovementMethod.getInstance());
    }

    @Override
    public Fragment createChildFragment() {
        return null;
    }

    @Override
    public int getContentViewResId() {
        return R.layout.suggest_new_exchange_activity;
    }

    @OnClick({R.id.donateButton})
    public void onDonateButtonClicked() {
        showDonateDialog();
    }

    @OnClick({R.id.suggestButton})
    public void onSuggestButtonClicked() {
        Utils.goToGitHubIssues(this);
    }

    public static void startSettingsMainActivity(Context context) {
        startSimpleDonateFragmentActivity(context, SuggestNewExchangeActivity.class, false);
    }
}
