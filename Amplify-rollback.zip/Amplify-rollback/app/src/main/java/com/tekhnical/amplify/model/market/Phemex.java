package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Phemex extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Phemex";
    private static final String TTS_NAME = "Phemex";
    private static final String URL = "https://api.phemex.com/md/spot/ticker/24hr?symbol=%1$s";
    private static final String CURRENCIES_URL = "https://api.phemex.com/exchange/public/cfg/v2/products";

    public Phemex() {
        super("phemex", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    @Override
    public int getImageUrl() {
        return R.drawable.phemex;
    }
    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Phemex.png";
        //return "https://assets.coingecko.com/markets/images/564/small/phemex_logo.jpg";
    }*/

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject("result");
        ticker.bid = ParseUtils.getDouble(jsonObject, "bidEp");
        ticker.ask = ParseUtils.getDouble(jsonObject, "askEp");
        ticker.last = ParseUtils.getDouble(jsonObject, "lastEp");
        ticker.high = ParseUtils.getDouble(jsonObject, "highEp");
        ticker.low = ParseUtils.getDouble(jsonObject, "lowEp");
        ticker.vol = ParseUtils.getDouble(jsonObject, "volumeEv");

    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONObject dataObject = json.getJSONObject("data");
        JSONArray jsonArray = dataObject.getJSONArray("products");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("baseCurrency")){
                list.add(new CurrencyPairInfo(jsonObject.getString("baseCurrency"),jsonObject.getString("quoteCurrency"),jsonObject.getString("symbol")));
            }

        }
    }

}
