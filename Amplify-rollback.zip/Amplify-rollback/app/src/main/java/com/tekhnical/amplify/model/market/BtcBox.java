package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import java.util.HashMap;
import java.util.LinkedHashMap;
import org.json.JSONObject;

public class BtcBox extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "BtcBox";
    private static final String TTS_NAME = "BTC Box";
    private static final String URL = "https://www.btcbox.co.jp/api/v1/ticker/";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{Currency.JPY});
    }

    public BtcBox() {
        super("btcbox",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/btcbox.jpg";
        //return "https://assets.coingecko.com/markets/images/154/small/btcbox.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.btcbox;
    }
    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return URL;
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = jsonObject.getDouble("buy");
        ticker.ask = jsonObject.getDouble("sell");
        ticker.vol = jsonObject.getDouble("vol");
        ticker.high = jsonObject.getDouble("high");
        ticker.low = jsonObject.getDouble("low");
        ticker.last = jsonObject.getDouble("last");
    }
}
