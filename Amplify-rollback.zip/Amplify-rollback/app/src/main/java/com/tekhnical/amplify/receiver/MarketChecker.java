package com.tekhnical.amplify.receiver;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.SystemClock;
import android.util.Log;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.RequestFuture;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.google.gson.Gson;
import com.tekhnical.amplify.appwidget.WidgetProvider;
import com.tekhnical.amplify.fragment.CheckersListFragment;
import com.tekhnical.amplify.fragment.SettingsNotificationsFragment;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.content.MaindbContract;
import com.tekhnical.amplify.content.MaindbContract.Checker;
import com.tekhnical.amplify.util.AsyncTaskCompat;
import com.tekhnical.amplify.util.CheckErrorsUtils;
import com.tekhnical.amplify.util.CheckerRecordHelper;
import com.tekhnical.amplify.util.HttpsHelper;
import com.tekhnical.amplify.util.NotificationUtils;
import com.tekhnical.amplify.util.PreferencesUtils;
import com.tekhnical.amplify.util.TickerUtils;
import com.tekhnical.amplify.volley.CheckerTotalVolleyAsyncTask;
import com.tekhnical.amplify.volley.CheckerVolleyAsyncTask;
import com.robotoworks.mechanoid.db.SQuery;
import com.robotoworks.mechanoid.db.SQuery.Op;
import com.tekhnical.amplify.volley.generic.GenericVolleyAsyncTask;
import com.tekhnical.amplify.volley.generic.GzipVolleyStringRequest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class MarketChecker extends BroadcastReceiver {
    private static final String ACTION_CHECK_MARKET = "com.tekhnical.amplify.receiver.action.check_market";
    public static final String EXTRA_ALARM_RECORD_ID = "alarm_record_id";
    public static final String EXTRA_CHECKER_RECORD_ID = "checker_record_id";
    private static final Object LOCK = new Object();
    private static RequestQueue requestQueue = null;

    public void onReceive(Context context, Intent intent) {
        if (intent != null && ACTION_CHECK_MARKET.equals(intent.getAction())) {
            long checkerRecordId = intent.getLongExtra(EXTRA_CHECKER_RECORD_ID, -1);
            if (checkerRecordId > 0) {
                try {
                    checkMarketAsyncForCheckerRecord(context, CheckerRecord.get(checkerRecordId));
                }catch (Exception e){
                    e.printStackTrace();
                    FirebaseCrashlytics.getInstance().recordException(e);
                }
            }
        }
    }

    public static void refreshAllEnabledCheckerRecords(Context context) {
        List<CheckerRecord> list = SQuery.newQuery().expr("enabled", Op.EQ, true).select(Checker.CONTENT_URI, CheckersListFragment.getSortOrderString(context));
        try{
            for (CheckerRecord checkerRecord : list ) {
                checkMarketAsyncForCheckerRecord(context, checkerRecord);
            }
        }catch (Exception e){
            e.printStackTrace();
            FirebaseCrashlytics.getInstance().recordException(e);
        }
    }

    public static void resetAlarmManagerForFearIndex(Context context, boolean checkNow) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        boolean show = PreferencesUtils.getCheckNotificationFearIndex(context);
        if (show) {
            if (checkNow) {
                try {
                    checkAsyncFearIndex(context, show);
                } catch (Exception e) {
                    e.printStackTrace();
                    FirebaseCrashlytics.getInstance().recordException(e);
                }
            }
            PendingIntent pi = createPendingIntentForMarket(context, -5);
            alarmManager.cancel(pi);
            alarmManager.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + 86400000, 86400000, pi);
            return;
        }
        alarmManager.cancel(createPendingIntentForMarket(context, -5));
    }

    public static void resetAlarmManager(Context context) {
        Context appContext = context.getApplicationContext();
        List<CheckerRecord> list = SQuery.newQuery().select(Checker.CONTENT_URI);
        for (CheckerRecord checkerRecord : list) {
            resetAlarmManagerForChecker(appContext, checkerRecord, true);
        }
    }

    public static void resetAlarmManagerForAllEnabledThatUseGlobalFrequency(Context context) {
        Context appContext = context.getApplicationContext();
        List<CheckerRecord> list = SQuery.newQuery().expr(MaindbContract.CheckerColumns.FREQUENCY, Op.EQ, -1).and().expr("enabled", Op.EQ, true).select(Checker.CONTENT_URI);
        for (CheckerRecord checkerRecord : list) {
            resetAlarmManagerForChecker(appContext, checkerRecord, true);
        }
    }

    public static void resetAlarmManagerForChecker(Context context, CheckerRecord checkerRecord, boolean checkNow) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (checkerRecord.getEnabled()) {
            if (checkNow) {
                try{
                    checkMarketAsyncForCheckerRecord(context, checkerRecord);
                }catch (Exception e){
                    e.printStackTrace();
                    FirebaseCrashlytics.getInstance().recordException(e);
                }
            }
            PendingIntent pi = createPendingIntentForMarket(context, checkerRecord.getId());
            alarmManager.cancel(pi);
            long frequency = CheckerRecordHelper.getDisplayedFrequency(context, checkerRecord);
            alarmManager.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + frequency, frequency, pi);
            return;
        }
        cancelCheckingForCheckerRecord(checkerRecord.getId());
        alarmManager.cancel(createPendingIntentForMarket(context, checkerRecord.getId()));
    }

    private static Intent createIntentForCheckerRecord(Context context, long checkerRecordId) {
        Intent intent = new Intent(context, MarketChecker.class);
        intent.setAction(ACTION_CHECK_MARKET);
        intent.putExtra(EXTRA_CHECKER_RECORD_ID, checkerRecordId);
        intent.setPackage(context.getPackageName());
        intent.setData(Uri.parse(intent.toUri(Intent.URI_ANDROID_APP_SCHEME)));
        return intent;
    }

    private static PendingIntent createPendingIntentForMarket(Context context, long checkerRecordId) {
        return PendingIntent.getBroadcast(context, (int) checkerRecordId, createIntentForCheckerRecord(context, checkerRecordId), PendingIntent.FLAG_CANCEL_CURRENT);
    }

    public static boolean isAlarmScheduledForChecker(Context context, long checkerRecordId) {
        return PendingIntent.getBroadcast(context, (int) checkerRecordId, createIntentForCheckerRecord(context, checkerRecordId),  PendingIntent.FLAG_UPDATE_CURRENT) != null;
    }

    public static void checkIfAlarmsAreSet(Context context) {
        final Context appContext = context.getApplicationContext();
        MarketChecker.resetAlarmManagerForFearIndex(context, true);
        AsyncTaskCompat.execute(new AsyncTask<Void, Void, Void>() {
            @Override
            public Void doInBackground(Void... unused) {
                Cursor cursor = SQuery.newQuery().select(Checker.CONTENT_URI, CheckerRecord.PROJECTION);
                if (cursor != null) {
                    if (cursor.moveToFirst()) {
                        do {
                            if (cursor.getInt(1) == 0 || !MarketChecker.isAlarmScheduledForChecker(appContext, (long) cursor.getInt(0))) {
                                MarketChecker.resetAlarmManagerForChecker(appContext, CheckerRecord.fromCursor(cursor), true);
                            }
                        } while (cursor.moveToNext());
                    }
                    cursor.close();
                }
                return null;
            }
        }, new Void[0]);
    }

    public static void cancelCheckingForCheckerRecord(long checkerRecordId) {
        CheckerVolleyAsyncTask.cancelCheckingForCheckerRecord(checkerRecordId);
    }

    public static void checkAsyncFearIndex(Context context, boolean show) {
        if (show) {
            synchronized (LOCK) {
                final Context appContext = context.getApplicationContext();
                if (requestQueue == null) {
                    requestQueue = HttpsHelper.newRequestQueue(appContext);
                }
                AsyncTaskCompat.execute(new GenericVolleyAsyncTask<Ticker>(requestQueue, new Listener<Ticker>() {
                    @Override
                    public void onResponse(Ticker response) {
                        if (response!=null && response.last >= 0) {
                            NotificationUtils.showHideFearIndexNotification(context, true, response);
                        }
                    }
                }, new ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                }) {
                    @Override
                    public Object doNetworkInBackground() throws Exception {
                        Ticker ticker = null;
                        try {
                            RequestFuture<String> nextFuture = RequestFuture.newFuture();
                            GzipVolleyStringRequest request = new GzipVolleyStringRequest("https://api.alternative.me/fng/", nextFuture, nextFuture);
                            request.setRetryPolicy(new DefaultRetryPolicy(8000, 1, 1.0f));
                            this.requestQueue.add(request);
                            String responseString = (String) nextFuture.get();
                            JSONObject extraObject = new JSONObject(responseString);
                            if(extraObject.has("data")){
                                JSONArray jsonArray = extraObject.getJSONArray("data");
                                JSONObject dataObject = jsonArray.getJSONObject(0);
                                ticker = new Ticker();
                                ticker.last = Double.parseDouble(dataObject.getString("value"));
                                ticker.icon = dataObject.getString("value_classification");
                                ticker.timestamp = Long.parseLong(dataObject.getString("timestamp"));
                            }
                            return ticker;
                        }catch (Exception e) {
                            return ticker;
                        }
                    }
                });
            }
        }
        else
            NotificationUtils.showHideFearIndexNotification(context, false, null);
    }
    public static void checkMarketAsyncForCheckerRecord(Context context, final CheckerRecord checkerRecord) {
        if (checkerRecord != null && checkerRecord.getEnabled()) {
            synchronized (LOCK) {
                final Context appContext = context.getApplicationContext();
                if (requestQueue == null) {
                    requestQueue = HttpsHelper.newRequestQueue(appContext);
                }

                AsyncTaskCompat.execute(new CheckerVolleyAsyncTask(requestQueue, checkerRecord, new Listener<Ticker>() {
                    public void onResponse(Ticker mainTicker) {
                        if (mainTicker != null) {
                            checkerRecord.setPreviousCheckTicker(checkerRecord.getLastCheckTicker());
                            checkerRecord.setLastCheckTicker(TickerUtils.toJson(mainTicker));
                        }
                        final double amount = Double.parseDouble(checkerRecord.getHoldings() != null ? checkerRecord.getHoldings(): "0");
                        if (amount>0 || (checkerRecord.getCurrencySubunitDst() == -2)) {
                            Ticker ticker = TickerUtils.fromJson(checkerRecord.getLastCheckTicker());
                            if (ticker!=null && ticker.usd>0){
                                if(checkerRecord.getCurrencySubunitDst() == -2) {
                                    if(mainTicker.high > 0)
                                        mainTicker.high = (mainTicker.high * ticker.usd)/mainTicker.last;
                                    if(mainTicker.low > 0)
                                        mainTicker.low = (mainTicker.low * ticker.usd)/mainTicker.last;
                                    mainTicker.last = ticker.usd;
                                }
                                checkerRecord.setHoldingsAmount(amount * ticker.usd);
                                MarketChecker.handleNewTicker(appContext, checkerRecord, mainTicker, null);
                            }else {
                                RequestQueue requestQueue = HttpsHelper.newRequestQueue(context);
                                AsyncTaskCompat.execute(new CheckerTotalVolleyAsyncTask(requestQueue, checkerRecord, new Response.Listener<Ticker>() {
                                    public void onResponse(Ticker ticker) {
                                        checkerRecord.setHoldingsAmount(amount * (ticker.last > 0 ? ticker.last : mainTicker.last));
                                        if(checkerRecord.getCurrencySubunitDst() == -2) {
                                            if(mainTicker.high > 0)
                                                mainTicker.high = (mainTicker.high * ticker.last)/mainTicker.last;
                                            if(mainTicker.low > 0)
                                                mainTicker.low = (mainTicker.low * ticker.last)/mainTicker.last;
                                            mainTicker.last = ticker.last;
                                        }
                                        MarketChecker.handleNewTicker(appContext, checkerRecord, mainTicker, null);
                                    }
                                }, new Response.ErrorListener() {
                                    public void onErrorResponse(VolleyError error) {
                                        error.printStackTrace();
                                        if (!(error instanceof NetworkError)) {
                                            //checkerRecord.setHoldingsAmount(amount);
                                            MarketChecker.handleNewTicker(appContext, checkerRecord, mainTicker, null);
                                        }
                                    }
                                }), new Void[0]);
                            }
                        }
                        else {
                            checkerRecord.setHoldingsAmount(0);
                            MarketChecker.handleNewTicker(appContext, checkerRecord, mainTicker, null);
                        }
                    }
                }, new ErrorListener() {
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        if (!(error instanceof NetworkError)) {
                            MarketChecker.handleNewTicker(appContext, checkerRecord, null, CheckErrorsUtils.parseErrorMsg(appContext, error));
                        }
                    }
                }), new Void[0]);
            }
        }
    }

    private static void handleNewTicker(Context appContext, CheckerRecord checkerRecord, Ticker ticker, String errorMsg) {
        checkerRecord.setLastCheckDate(System.currentTimeMillis());
        checkerRecord.setErrorMsg(errorMsg);
        if (ticker != null) {
            checkerRecord.setPreviousCheckTicker(checkerRecord.getLastCheckTicker());
            checkerRecord.setLastCheckTicker(TickerUtils.toJson(ticker));
        }
        checkerRecord.save();
        NotificationUtils.showOngoingNotification(appContext, checkerRecord, NotificationUtils.checkfThereIsAlertSituationAndShowAlertNotification(appContext, checkerRecord, ticker));
        NotificationUtils.showTotalPortfolioNotification(appContext);
        WidgetProvider.refreshWidget(appContext);
    }
}
