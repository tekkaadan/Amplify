package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class ZB extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "ZB";
    private static final String TTS_NAME = "ZB";
    private static final String URL = "http://api.zb.live/data/v1/ticker?market=%1$s";
    private static final String CURRENCIES_URL = "http://api.zb.live/data/v1/markets";


    public ZB() {
        super("zb", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    @Override
    public int getImageUrl() {
        return R.drawable.zb;
    }
    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/ZB.png";
        //return "https://assets.coingecko.com/markets/images/115/small/zb.jpg";
    }*/

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject("ticker");
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "buy");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "sell");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "vol");


    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = jsonObject.names();
        for (int i = 0; i < jsonArray.length(); i++) {
            String split[] = jsonArray.getString(i).split("_");
            if (split.length>=2)
                list.add(new CurrencyPairInfo(split[0].toUpperCase(),split[1].toUpperCase(),jsonArray.getString(i)));
        }
    }



}
