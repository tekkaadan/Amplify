package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class BW extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "BW";
    private static final String TTS_NAME = "BW";
    private static final String URL = "https://www.bw.com/api/data/v1/ticker?marketId=%1$s";
    private static final String CURRENCIES_URL = "https://www.bw.com/exchange/config/controller/website/marketcontroller/getByWebId";

    public BW() {
        super("bw", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }


    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/BW.png";
        //return "https://assets.coingecko.com/markets/images/326/small/bw.com.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.bw;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray jsonArray = jsonObject.getJSONArray("datas");
        if (jsonArray.length()>=5) {
            ticker.last = Double.parseDouble(jsonArray.getString(1));
            ticker.high = Double.parseDouble(jsonArray.getString(2));
            ticker.low = Double.parseDouble(jsonArray.getString(3));
            ticker.vol = Double.parseDouble(jsonArray.getString(4));

        }
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = jsonObject.getJSONArray("datas");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject pairObject = jsonArray.getJSONObject(i);
            String pair = pairObject.getString("name");
            String[] splits = pair.split("_");
            if (splits.length>=2){
                list.add(new CurrencyPairInfo(splits[0].toUpperCase(),splits[1].toUpperCase(),pairObject.getInt("marketId")+""));
            }
        }
    }

}
