package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class BTSE extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "BTSE";
    private static final String TTS_NAME = "BTSE";
    private static final String CURRENCIES_URL = "https://api.btse.com/futures/api/v2.1/market_summary";

    public BTSE() {
        super("btse", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return CURRENCIES_URL;
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/BTSE.jpg";
        //return "https://assets.coingecko.com/markets/images/465/small/BTSE.jpg";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.btse;
    }
    @Override
    public void parseTicker(int requestId, String responseString, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i=0;i<jsonArray.length();i++){
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("symbol") && jsonObject.getString("symbol").equals(checkerInfo.getCurrencyPairId())) {
                ticker.last = ParseUtils.getDouble(jsonObject, "last");
                ticker.high = ParseUtils.getDouble(jsonObject, "high24Hr");
                ticker.low = ParseUtils.getDouble(jsonObject, "low24Hr");
                ticker.bid = ParseUtils.getDouble(jsonObject, "highestBid");
                ticker.ask = ParseUtils.getDouble(jsonObject, "lowestAsk");
                ticker.vol = ParseUtils.getDouble(jsonObject, "volume");
            }
        }
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("symbol")){
                pairs.add(new CurrencyPairInfo(jsonObject.getString("base").toUpperCase(),jsonObject.getString("quote").toUpperCase(),jsonObject.getString("symbol")));
            }
        }
    }


}
