package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Bkex extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Bkex";
    private static final String TTS_NAME = "Bkex";
    private static final String URL1 = "https://api.bkex.com/v1/q/ticker?pair=%1$s";
    private static final String URL2 = "https://api.bkex.com/v1/q/ticker/price?pair=%1$s";
    private static final String CURRENCIES_URL = "https://api.bkex.com/v1/exchangeInfo";

    public Bkex() {
        super("bkex", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        if (requestId == 0)
            return String.format(URL1, new Object[]{checkerInfo.getCurrencyPairId()});
        else
            return String.format(URL2, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/BKEX.png";
        //return "https://assets.coingecko.com/markets/images/293/small/logo.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bkex;
    }
    @Override
    public int getNumOfRequests(CheckerInfo checkerInfo) {
        return 2;
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject json, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = json.getJSONObject("data");
        if (requestId == 0) {
            ticker.high = ParseUtils.getDouble(jsonObject, "h");
            ticker.low = ParseUtils.getDouble(jsonObject, "l");
            ticker.vol = ParseUtils.getDouble(jsonObject, "a");
        }else{
            ticker.last = ParseUtils.getDouble(jsonObject,"price");
        }
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONObject data = json.getJSONObject("data");
        JSONArray jsonArray = data.getJSONArray("pairs");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("pair")){
                String split[] = jsonObject.getString("pair").split("_");
                if (split.length>=2)
                    list.add(new CurrencyPairInfo(split[0],split[1],jsonObject.getString("pair")));
            }
        }
    }

}
