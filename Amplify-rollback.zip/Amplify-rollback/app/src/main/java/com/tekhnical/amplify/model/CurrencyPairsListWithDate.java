package com.tekhnical.amplify.model;

import java.util.List;

public class CurrencyPairsListWithDate {
    public long date;
    public List<CurrencyPairInfo> pairs;
}
