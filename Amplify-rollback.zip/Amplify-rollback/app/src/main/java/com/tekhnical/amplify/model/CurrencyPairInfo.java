package com.tekhnical.amplify.model;

public class CurrencyPairInfo implements Comparable<CurrencyPairInfo> {
    protected final String currencyBase;
    protected final String currencyCounter;
    protected final String currencyPairId;

    public CurrencyPairInfo(String currencyBase2, String currencyCounter2, String currencyPairId2) {
        this.currencyBase = currencyBase2;
        this.currencyCounter = currencyCounter2;
        this.currencyPairId = currencyPairId2;
    }

    public String getCurrencyBase() {
        return this.currencyBase;
    }

    public String getCurrencyCounter() {
        return this.currencyCounter;
    }

    public String getCurrencyPairId() {
        return this.currencyPairId;
    }

    public int compareTo(CurrencyPairInfo another) throws NullPointerException {
        if (this.currencyBase == null || another.currencyBase == null || this.currencyCounter == null || another.currencyCounter == null) {
            throw new NullPointerException();
        }
        int compBase = this.currencyBase.compareToIgnoreCase(another.currencyBase);
        return compBase != 0 ? compBase : this.currencyCounter.compareToIgnoreCase(another.currencyCounter);
    }
}
