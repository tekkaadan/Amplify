package com.tekhnical.amplify.model;

public class CurrencySubunit {
    public final boolean allowDecimal;
    public final String name;
    public final long subunitToUnit;

    public CurrencySubunit(String name2, long subunitToUnit2) {
        this(name2, subunitToUnit2, true);
    }

    public CurrencySubunit(String name2, long subunitToUnit2, boolean allowDecimal2) {
        this.name = name2;
        this.subunitToUnit = subunitToUnit2;
        this.allowDecimal = allowDecimal2;
    }
}
