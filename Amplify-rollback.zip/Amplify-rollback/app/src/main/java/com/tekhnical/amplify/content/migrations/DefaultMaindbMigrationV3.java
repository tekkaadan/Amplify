package com.tekhnical.amplify.content.migrations;

import android.database.sqlite.SQLiteDatabase;
import com.robotoworks.mechanoid.db.SQLiteMigration;

/* renamed from: com.tekhnical.amplify.db.content.migrations.DefaultMaindbMigrationV3 */
public class DefaultMaindbMigrationV3 extends SQLiteMigration {
    public void onBeforeUp(SQLiteDatabase db) {
    }

    @Override
    public void up(SQLiteDatabase db) {
        db.execSQL("alter table checker add column lastCheckDate integer ");
    }

    public void onAfterUp(SQLiteDatabase db) {
    }
}
