package com.tekhnical.amplify.fragment;

import android.annotation.SuppressLint;
import android.content.ContentProviderOperation;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.robotoworks.mechanoid.Mechanoid;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.CheckerAddActivity;
import com.tekhnical.amplify.adapter.CheckerFuturesListAdapter;
import com.tekhnical.amplify.appwidget.WidgetProvider;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.content.MaindbContract;
import com.tekhnical.amplify.content.MaindbContract.Checker;
import com.tekhnical.amplify.fragment.generic.ActionModeListFragment;
import com.tekhnical.amplify.receiver.MarketChecker;
import com.tekhnical.amplify.util.AsyncTaskCompat;
import com.tekhnical.amplify.util.CheckerRecordHelper;
import com.tekhnical.amplify.util.PreferencesUtils;
import com.tekhnical.amplify.util.Utils;

import java.util.ArrayList;


public class CheckerFuturesListFragment extends ActionModeListFragment<Cursor> implements LoaderManager.LoaderCallbacks<Cursor>, CheckerFuturesListAdapter.OnItemClickListener {

    private CheckerFuturesListAdapter adapter;
    private AsyncTask<ArrayList<ContentProviderOperation>, Void, Void> dragAndDropUpateTask;
    private MenuItem sortByManuallyItem;


    @SuppressLint("ResourceType")
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.checkers_list_fragment, container,false);
        //ListFragmentLayout.setupIds(view);
        setHasOptionsMenu(true);
        view.findViewById(R.id.empty_id).setId(0x00ff0001);
        view.findViewById(R.id.progress_container_id).setId(0x00ff0002);
        view.findViewById(R.id.list_container_id).setId(0x00ff0003);
        TextView titleView = view.findViewById(R.id.checker_list_title);
        titleView.setText(Utils.getMarketType(getContext(),1));
        TextView addCheckerBtn = view.findViewById(R.id.add_checker_btn);
        addCheckerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckerAddActivity.startCheckerAddActivity(getContext(), null);
            }
        });
        ImageView backView = view.findViewById(R.id.back_button);
        backView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
        /*totalHoldingsParent = view.findViewById(R.id.total_holdings_item);
        totalView = view.findViewById(R.id.lastCheckValueView);
        totalTimeView = view.findViewById(R.id.lastCheckTimeView);
        btnTotalOn = view.findViewById(R.id.btn_on);
        btnTotalOff = view.findViewById(R.id.btn_off);
        totalView.setText(" " + FormatUtils.formatPriceWithCurrency(0, "USD"));
        totalTimeView.setText(FormatUtils.formatSameDayTimeOrDate(getContext(), new Date().getTime()));
        btnTotalOff.addOnCheckedChangeListener(new MaterialButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(MaterialButton button, boolean isChecked) {
                if (btnTotalOn.isChecked() == isChecked)
                    btnTotalOn.setChecked(!isChecked);
            }
        });
        btnTotalOn.addOnCheckedChangeListener(new MaterialButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(MaterialButton button, boolean isChecked) {
                if (btnTotalOff.isChecked() == isChecked)
                    btnTotalOff.setChecked(!isChecked);
                if (isChecked)
                    NotificationUtils.showTotalPortfolioNotification(getContext());
                else
                    NotificationUtils.clearPortfolioNotification(getContext(),marketType);
            }
        });
        */
        return view;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setHasOptionsMenu(true);
        /*this.mPullToRefreshLayout = view.findViewById(R.id.swipe_refresh_view);
        this.mPullToRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if(mPullToRefreshLayout!=null)
                    mPullToRefreshLayout.setRefreshing(true);
                onRefreshStarted(null);
            }
        });*/
        this.adapter = new CheckerFuturesListAdapter(getActivity(), this);
        setListAdapter(this.adapter);
        setListShownNoAnimation(false);
        setEmptyText(getString(R.string.checkers_list_empty_text));
        TextView emptyView = (TextView) getListView().getEmptyView();
        emptyView.setTextColor(getResources().getColor(R.color.list_divider));
        getListView().setDividerHeight(0);
        getListView().setDivider(null);
        getListView().setSelector(R.drawable.list_selector_background_transition_holo_light);
        enableActionModeOrContextMenu();
        getLoaderManager().restartLoader(0, null, this);
        //MarketChecker.refreshAllEnabledCheckerRecords(getActivity());
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        editCheckerRecord((Cursor) adapter.getItem(position));
    }

    public void onDestroyView() {
        super.onDestroyView();
    }


    private void editCheckerRecord(Cursor cursor) {
        CheckerAddActivity.startCheckerAddActivity(getActivity(), CheckerRecord.fromCursor(cursor));
    }

    private void deleteCheckerRecord(Cursor cursor, boolean refresh) {
        CheckerRecord checkerRecord = CheckerRecord.fromCursor(cursor);
        CheckerRecordHelper.doBeforeDelete(getActivity(), checkerRecord);
        CheckerRecord.fromCursor(cursor).delete(refresh);
        CheckerRecordHelper.doAfterDelete(getActivity(), checkerRecord);
    }

    private void onDrop(int from, int to) {
        if (from != to) {
            final Context appContext = getActivity().getApplicationContext();
            ArrayList<ContentProviderOperation> ops = new ArrayList<>();
            Cursor cursor = this.adapter.getCursor();
            if (cursor != null) {
                cursor.moveToFirst();
                while (!cursor.isAfterLast()) {
                    /*long sortOrder = (long) this.adapter.getListPosition(cursor.getPosition());
                    ops.add(ContentProviderOperation.newUpdate(Checker.CONTENT_URI.buildUpon().appendPath(String.valueOf(cursor.getLong(0))).appendQueryParameter(MechanoidContentProvider.PARAM_NOTIFY, String.valueOf(false)).build()).withValue(MaindbContract.CheckerColumns.SORT_ORDER, Long.valueOf(sortOrder)).build());
                    cursor.moveToNext();*/
                }
            }
            if (this.dragAndDropUpateTask != null) {
                this.dragAndDropUpateTask.cancel(true);
            }
            this.dragAndDropUpateTask = new AsyncTask<ArrayList<ContentProviderOperation>, Void, Void>() {
                @Override
                public Void doInBackground(ArrayList<ContentProviderOperation>... ops) {
                    try {
                        Mechanoid.getContentResolver().applyBatch(MaindbContract.CONTENT_AUTHORITY, ops[0]);
                        PreferencesUtils.setCheckersListSortMode(CheckerFuturesListFragment.this.getActivity(), 0);
                        if (CheckerFuturesListFragment.this.sortByManuallyItem != null) {
                            CheckerFuturesListFragment.this.sortByManuallyItem.setChecked(true);
                        }
                        WidgetProvider.refreshWidget(appContext);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return null;
                }
            };
            try {
                AsyncTaskCompat.execute(this.dragAndDropUpateTask, ops);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, Cursor cursor) {
        editCheckerRecord((Cursor) adapter.getItem(position));
    }

    /*@Override
    public void onCreateOptionsMenu(@NonNull Menu menu, MenuInflater inflater) {
        int checkedSortMenuItem;
        inflater.inflate(R.menu.checkers_list_fragment, menu);
        this.sortByManuallyItem = menu.findItem(R.id.sortByManuallyItem);
        switch (PreferencesUtils.getCheckersListSortMode(getActivity())) {
            case 1:
                checkedSortMenuItem = R.id.sortByCurrencyItem;
                break;
            case 2:
                checkedSortMenuItem = R.id.sortByExchangeItem;
                break;
            default:
                checkedSortMenuItem = R.id.sortByManuallyItem;
                break;
        }
        menu.findItem(checkedSortMenuItem).setChecked(true);
        super.onCreateOptionsMenu(menu, inflater);
    }*/

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.sortByManuallyItem:
                PreferencesUtils.setCheckersListSortMode(getActivity(), 0);
                item.setChecked(true);
                getLoaderManager().restartLoader(0, null, CheckerFuturesListFragment.this);
                WidgetProvider.refreshWidget(getActivity());
                return true;
            case R.id.sortByCurrencyItem:
                PreferencesUtils.setCheckersListSortMode(getActivity(), 1);
                item.setChecked(true);
                getLoaderManager().restartLoader(0, null, CheckerFuturesListFragment.this);
                WidgetProvider.refreshWidget(getActivity());
                return true;
            case R.id.sortByExchangeItem:
                PreferencesUtils.setCheckersListSortMode(getActivity(), 2);
                item.setChecked(true);
                getLoaderManager().restartLoader(0, null, CheckerFuturesListFragment.this);
                WidgetProvider.refreshWidget(getActivity());
                return true;
            case R.id.refreshAllItem:
                onRefreshStarted(null);
                return true;
                default:
                    return false;
        }

    }

    private void onRefreshStarted(View unused) {
        if (getActivity() != null) {
            MarketChecker.refreshAllEnabledCheckerRecords(getActivity());
//            this.mPullToRefreshLayout.postDelayed(this.refreshAllCompleteRunnable, 2000);
        }
    }

    @Override
    public int getActionModeOrContextMenuResId() {
        return R.menu.checkers_list_fragment_cab;
    }

    @Override
    public void onActionModeItemsCheckedCountChanged(ActionMode mode, int checkedItemCount) {
        boolean z = true;
        MenuItem findItem = mode.getMenu().findItem(R.id.editItem);
        if (checkedItemCount != 1) {
            z = false;
        }
        findItem.setVisible(z);
        super.onActionModeItemsCheckedCountChanged(mode, checkedItemCount);
    }

    @Override
    public boolean onActionModeOrContextMenuItemClicked(int menuItemId, Cursor checkedItem, int listItemPosition, int checkedItemsCount, boolean isForLastItem) {
        switch (menuItemId) {
            case R.id.deleteItem :
                deleteCheckerRecord(checkedItem, isForLastItem);
                return true;
            case R.id.editItem :
                editCheckerRecord(checkedItem);
                return true;
            default:
                return super.onActionModeOrContextMenuItemClicked(menuItemId, checkedItem, listItemPosition, checkedItemsCount, isForLastItem);
        }
    }

    @Override
    public void onActionModeActive(boolean active) {
        super.onActionModeActive(active);
        this.adapter.setActionModeActive(active);
    }

    private void setNewList(Cursor cursor) {
        if (getView() != null && getActivity() != null) {
            if (cursor != null) {
                if (cursor.getCount()>0){
                    double total = 0;
                    boolean check = false;
                    while (cursor.moveToNext()){
                        check = true;
                        CheckerRecord item = CheckerRecord.fromCursor(cursor);
                        total = total +item.getHoldingsAmount();
                    }
                    /*if (total >0) {
                        totalView.setText(" " + FormatUtils.formatPriceWithCurrency(total, "USD"));
                        totalTimeView.setText(FormatUtils.formatSameDayTimeOrDate(getContext(), new Date().getTime()));
                        totalHoldingsParent.setVisibility(View.VISIBLE);
                    }
                    else if (check)
                        totalHoldingsParent.setVisibility(View.GONE);*/

                }
                cursor.moveToFirst();
                this.adapter.swapCursor(cursor);
            }
            setListShown(true);
        }
    }

    @NonNull
    @Override
    public Loader<Cursor> onCreateLoader(int arg0, Bundle arg1) {
//        String selection = marketType == 1 ? MaindbContract.CheckerColumns.MARKET_KEY +" IN (? , ? , ? , ? , ? , ? , ? , ? , ?)"
//                :MaindbContract.CheckerColumns.MARKET_KEY +" NOT IN (? , ? , ? , ? , ? , ? , ? , ? , ?)";
//        return new CursorLoader(getActivity(), Checker.CONTENT_URI, CheckerRecord.PROJECTION, selection, new String[]{BinanceFuture.ID,BitfinexFuture.ID,BitMEX.ID,Bybit.ID,Deribit.ID,FTXFuture.ID,HuobiFuture.ID,KrakenFuture.ID,OkexFutures.ID}, getSortOrderString(getActivity()));
        return new CursorLoader(getActivity(),Checker.CONTENT_URI,CheckerRecord.PROJECTION,MaindbContract.CheckerColumns.MARKET_TYPE+" = "+1,null,getSortOrderString(getActivity()));
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor data) {
        setNewList(data);
    }


    @Override
    public void onLoaderReset(@NonNull Loader<Cursor> loader) {
        setNewList(null);
    }

    public static String getSortOrderString(Context context) {
        switch (PreferencesUtils.getCheckersListSortMode(context)) {
            case 1:
                return "currencySrc ASC, currencyDst ASC, marketKey ASC";
            case 2:
                return "marketKey ASC, currencySrc ASC, currencyDst ASC";
            default:
                return "sortOrder ASC";
        }
    }

    @Override
    public void onItemClick(int position) {
        editCheckerRecord((Cursor) adapter.getItem(position));
    }

    @Override
    public void onItemLongClick(View view,int position) {
        PopupMenu popup = new PopupMenu(getContext(),view);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.checkers_list_fragment_cab,popup.getMenu());
        popup.show();
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.deleteItem :
                        deleteCheckerRecord((Cursor) adapter.getItem(position), true);
                        return true;
                    case R.id.editItem :
                        editCheckerRecord((Cursor) adapter.getItem(position));
                        return true;
                    default:
                        return false;
                }
            }
        });
    }
}
