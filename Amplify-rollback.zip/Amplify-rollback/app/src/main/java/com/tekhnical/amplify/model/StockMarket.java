package com.tekhnical.amplify.model;

import android.util.Log;

import com.google.gson.Gson;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.util.ParseUtils;
import com.tekhnical.amplify.util.Utils;

import org.json.JSONObject;

import java.util.HashMap;

public class StockMarket extends Market {

    private static final String URL = "https://cloud.iexapis.com/stable/stock/%1$s/quote?token=%2$s";

    public StockMarket(String id, String name, String ttsName, HashMap<String, String[]> currencyPairs) {
        super(id, name, ttsName, currencyPairs);
    }

    @Override
    public int getImageUrl() {
        return R.drawable.stock;
    }
    @Override
    public String getUrl(int i, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{key,Utils.STOCKAPIKEY});
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        Log.e("TICKER",jsonObject.toString());
        ticker.last = ParseUtils.getDouble(jsonObject, "latestPrice");
        try {
            ticker.high = ParseUtils.getDouble(jsonObject, "high");
            ticker.low = ParseUtils.getDouble(jsonObject, "low");
            ticker.vol = jsonObject.getLong("latestVolume");
            ticker.mc = jsonObject.getLong("marketCap");
            ticker.ch1d = jsonObject.getDouble("changePercent");
        }catch (Exception e){e.printStackTrace();}

    }
}
