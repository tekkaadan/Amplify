package com.tekhnical.amplify.fragment;


import android.content.Context;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.tabs.TabLayout;
import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.CheckersListActivity;
import com.tekhnical.amplify.util.PreferencesUtils;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    public ViewPager2 homePager;
    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                int defaultPage = PreferencesUtils.getUserDefault(getContext()) - 1;
                if(homePager.getCurrentItem() != defaultPage){
                    homePager.setCurrentItem(defaultPage);
                }
            }
        };

        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        homePager = view.findViewById(R.id.home_pager);
        setPager();
    }

    public void setPager() {
        if(getActivity() != null){
            CheckersListActivity activity = (CheckersListActivity) getActivity();
            activity.findViewById(R.id.appbar_icon).setVisibility(View.VISIBLE);
        }
        homePager.setUserInputEnabled(false);
        homePager.setAdapter(new FragmentStateAdapter(this) {
            @NonNull
            @Override
            public Fragment createFragment(int position) {
                switch (position){
                    case 0:
                        return new CheckersListFragment();
                    case 1:
                        return new CheckerFuturesListFragment();
                    case 2:
                        return new CheckerStockListFragment();
                    default:
                        return new CheckersListFragment();
                }
            }

            @Override
            public int getItemCount() {
                return 3;
            }
        });
        homePager.setOffscreenPageLimit(1);
        homePager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
           @Override
           public void onPageSelected(int position) {
               super.onPageSelected(position);
               //homePager.setCurrentItem(position, false);
               MyApplication.appMarketType = position;
           }
        });
        new Handler().postDelayed(() -> {
            homePager.setCurrentItem(MyApplication.isRefresh != -1 ? MyApplication.isRefresh : PreferencesUtils.getUserDefault(getContext()) - 1, false);
            MyApplication.isRefresh = -1;
        }, 100);
    }
}
