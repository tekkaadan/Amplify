package com.tekhnical.amplify.activity.generic;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import androidx.fragment.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.PreferencesUtils;
import com.tekhnical.amplify.util.Utils;

public abstract class SimpleDonateFragmentSubActivity<T extends Fragment> extends SimpleFragmentSubActivity<T> {
    private static final String EXTRA_SHOW_DONATE_DIALOG = "show_donate_dialog";
    private static final int REQ_DONATE_BTC = 10001;
    private static final int REQ_DONATE_DOGE = 10002;
    private static final int REQ_DONATE_LTC = 10003;
    protected static final String TAG = SimpleDonateFragmentSubActivity.class.getSimpleName();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getIntent().getBooleanExtra(EXTRA_SHOW_DONATE_DIALOG, false)) {
            showDonateDialog();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    protected static void startSimpleDonateFragmentActivity(Context context, Class<?> clazz, boolean showDonateDialog) {
        Intent intent = new Intent(context, clazz);
        intent.putExtra(EXTRA_SHOW_DONATE_DIALOG, showDonateDialog);
        context.startActivity(intent);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if ((requestCode == REQ_DONATE_BTC || requestCode == REQ_DONATE_DOGE || requestCode == REQ_DONATE_LTC) && resultCode == -1) {
            onDonateSuccess(true);
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void showDonateDialog() {
        new Builder(this).setTitle(R.string.settings_about_donate_title).setNegativeButton(R.string.cancel, new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                SimpleDonateFragmentSubActivity.this.getIntent().removeExtra(SimpleDonateFragmentSubActivity.EXTRA_SHOW_DONATE_DIALOG);
            }
        }).setOnCancelListener(new OnCancelListener() {
            public void onCancel(DialogInterface dialog) {
                SimpleDonateFragmentSubActivity.this.getIntent().removeExtra(SimpleDonateFragmentSubActivity.EXTRA_SHOW_DONATE_DIALOG);
            }
        }).setItems(getResources().getStringArray(R.array.settings_about_donate_options), new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                SimpleDonateFragmentSubActivity.this.getIntent().removeExtra(SimpleDonateFragmentSubActivity.EXTRA_SHOW_DONATE_DIALOG);
                switch (which) {
                    case 0:
                        SimpleDonateFragmentSubActivity.this.makeDonationBtc(SimpleDonateFragmentSubActivity.this);
                        return;
                    case 1:
                        SimpleDonateFragmentSubActivity.this.makeDonationDoge(SimpleDonateFragmentSubActivity.this);
                        return;
                    case 2:
                        SimpleDonateFragmentSubActivity.this.makeDonationLtc(SimpleDonateFragmentSubActivity.this);
                        return;
                    default:
                        return;
                }
            }
        }).show();
    }

    private final void makeDonationBtc(Activity context) {
        makeDonationVirtual(context, VirtualCurrency.BTC, REQ_DONATE_BTC, "bitcoin:1KyLY5sT1Ffa6ctFPFpdL2bxhSAxNqfvMA?amount=0.02", "de.schildbach.wallet", "Bitcoin");
    }

    private final void makeDonationDoge(Activity context) {
        makeDonationVirtual(context, VirtualCurrency.DOGE, REQ_DONATE_DOGE, "dogecoin:D81kyZ49E132enb7ct7RcPGpjgsrN7bsd7?amount=45000", "de.langerhans.wallet", "Dogecoin");
    }

    private final void makeDonationLtc(Activity context) {
        makeDonationVirtual(context, VirtualCurrency.LTC, REQ_DONATE_LTC, "litecoin:LZ3EiK42o5nbDW3cwiaKUptFQ9eBA3x1vw?amount=1.8", "de.schildbach.wallet_ltc", "Litecoin");
    }

    private final void makeDonationVirtual(final Activity context, String virtualCurrency, int reqCode, String uriString, final String walletPackageName, String walletName) {
        Intent donateIntent = new Intent("android.intent.action.VIEW", Uri.parse(uriString));
        if (Utils.isIntentAvailable(context, donateIntent)) {
            context.startActivityForResult(donateIntent, reqCode);
            return;
        }
        new Builder(context).setTitle(R.string.settings_about_donate_fail_virtual_alert_title).setMessage(getString(R.string.settings_about_donate_fail_virtual_alert_text, new Object[]{virtualCurrency, walletName})).setNegativeButton(R.string.cancel, null).setPositiveButton(R.string.ok, new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Utils.goToGooglePlay(context, walletPackageName);
            }
        }).show();
    }

    public void onDonateSuccess(boolean showSuccessToast) {
        if (showSuccessToast) {
            Utils.showToast((Context) this, (int) R.string.settings_about_donate_success, true);
        }
        PreferencesUtils.setDonationMade(this);
    }
}
