package com.tekhnical.amplify.volley;

import android.text.TextUtils;
import android.util.Log;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.ParseError;
import com.android.volley.RequestQueue;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.toolbox.RequestFuture;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.model.currency.CurrencyIds;
import com.tekhnical.amplify.util.CheckerRecordHelper;
import com.tekhnical.amplify.util.CurrencyUtils;
import com.tekhnical.amplify.util.MarketsConfigUtils;
import com.tekhnical.amplify.volley.generic.GenericVolleyAsyncTask;
import com.tekhnical.amplify.volley.generic.GzipVolleyStringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;

public class CheckerVolleyAsyncTask extends GenericVolleyAsyncTask<Ticker> implements CheckerRecordRequestIfc {
    private static final ArrayList<CheckerVolleyAsyncTask> CHECKERS_TASKS = new ArrayList<>();
    protected final CheckerInfo checkerInfo;
    private final CheckerRecord checkerRecord;
    private CurrencyIds currencyIds;
    public CheckerVolleyAsyncTask(RequestQueue requestQueue, CheckerRecord checkerRecord2, Listener<Ticker> listener, ErrorListener errorListener) {
        super(requestQueue, listener, errorListener);
        this.checkerRecord = checkerRecord2;
        this.checkerInfo = CheckerRecordHelper.createCheckerInfo(checkerRecord2);
        this.currencyIds = new CurrencyIds();
    }

    public long getCheckerRecordId() {
        if (this.checkerRecord != null) {
            return this.checkerRecord.getId();
        }
        return -1;
    }

    @Override
    public void onPreExecute() {
        super.onPreExecute();
        if (CHECKERS_TASKS != null) {
            CHECKERS_TASKS.add(this);
        }
    }

    @Override
    public Object doNetworkInBackground() throws Exception {
        Market market = MarketsConfigUtils.getMarketByKey(this.checkerRecord.getMarketKey());
        String responseString = null;
        Ticker ticker = null;

        try {
            RequestFuture<String> future = RequestFuture.newFuture();
            String url = market.getUrl(0, this.checkerInfo);
            if (!isCancelled() && !TextUtils.isEmpty(url)) {
                GzipVolleyStringRequest request = new GzipVolleyStringRequest(url, future, future);
                request.setRetryPolicy(new DefaultRetryPolicy(8000, 1, 1.0f));
                this.requestQueue.add(request);
                responseString = (String) future.get();
            }
            ticker = market.parseTickerMain(0, responseString, new Ticker(), this.checkerInfo);

            if(checkerRecord.getCurrencySrc()!= null && CurrencyIds.CURRENCY_IDS.containsKey(checkerRecord.getCurrencySrc().toLowerCase())) {
                String extraUrl = "https://api.coingecko.com/api/v3/coins/" + CurrencyIds.CURRENCY_IDS.get(checkerRecord.getCurrencySrc().toLowerCase())[0] + "?localization=false&tickers=false&community_data=false&developer_data=false";
                RequestFuture<String> nextFuture = RequestFuture.newFuture();
                GzipVolleyStringRequest request = new GzipVolleyStringRequest(extraUrl, nextFuture, nextFuture);
                request.setRetryPolicy(new DefaultRetryPolicy(8000, 1, 1.0f));
                this.requestQueue.add(request);
                responseString = (String) nextFuture.get();
                parseExtraTicker(responseString, ticker);
            }
        } catch (Throwable th) {
            th.printStackTrace();
        }
        if (ticker!=null) {
            int numOfRequests = market.getNumOfRequests(this.checkerInfo);
            if (isCancelled() || numOfRequests <= 1) {
                return ticker;
            }
            for (int requestId = 1; requestId <= numOfRequests+1; requestId++) {
                try {
                    String nextUrl = market.getUrl(requestId, this.checkerInfo);
                    if (!isCancelled() && !TextUtils.isEmpty(nextUrl)) {
                        RequestFuture<String> nextFuture = RequestFuture.newFuture();
                        this.requestQueue.add(new GzipVolleyStringRequest(nextUrl, nextFuture, nextFuture));
                        market.parseTickerMain(requestId, (String) nextFuture.get(), ticker, this.checkerInfo);
                    }
                } catch (Throwable e2) {
                    e2.printStackTrace();
                }
            }
            return ticker;

        } else {
            try {
                return new CheckerErrorParsedError(market.parseErrorMain(0, responseString, this.checkerInfo));
            } catch (Exception e) {
                return new ParseError((Throwable) e);
            }
        }
    }

    private void parseExtraTicker(String responseString, Ticker ticker) throws JSONException {
        JSONObject extraObject = new JSONObject(responseString);
        if(extraObject.has("image")){
            ticker.icon = extraObject.getJSONObject("image").getString("small");
        }
        if(extraObject.has("market_data")){
            JSONObject marketObject = extraObject.getJSONObject("market_data");
            ticker.cs = marketObject.getDouble("circulating_supply");
            if (marketObject.has("market_cap")){
                JSONObject marketCapObject = marketObject.getJSONObject("market_cap");
                if(marketCapObject.has(checkerInfo.getCurrencyCounterLowerCase())){
                    ticker.mc = marketCapObject.getLong(checkerInfo.getCurrencyCounterLowerCase());
                }else{
                    ticker.mc = marketCapObject.getLong("usd");
                }
            }
            if(marketObject.has("price_change_percentage_1h_in_currency")){
                JSONObject marketCapObject = marketObject.getJSONObject("price_change_percentage_1h_in_currency");
                if(marketCapObject.has(checkerInfo.getCurrencyCounterLowerCase())){
                    ticker.ch1h = marketCapObject.getDouble(checkerInfo.getCurrencyCounterLowerCase());
                }
                else{
                    ticker.ch1h = marketCapObject.getDouble("usd");
                }
            }
            if(marketObject.has("price_change_percentage_24h_in_currency")){
                JSONObject marketCapObject = marketObject.getJSONObject("price_change_percentage_24h_in_currency");
                if(marketCapObject.has(checkerInfo.getCurrencyCounterLowerCase())){
                    ticker.ch1d = marketCapObject.getDouble(checkerInfo.getCurrencyCounterLowerCase());
                }
                else{
                    ticker.ch1d = marketCapObject.getDouble("usd");
                }
            }
            if(marketObject.has("price_change_percentage_7d_in_currency")){
                JSONObject marketCapObject = marketObject.getJSONObject("price_change_percentage_7d_in_currency");
                if(marketCapObject.has(checkerInfo.getCurrencyCounterLowerCase())){
                    ticker.ch7d = marketCapObject.getDouble(checkerInfo.getCurrencyCounterLowerCase());
                }
                else{
                    ticker.ch7d = marketCapObject.getDouble("usd");
                }
            }
        }
    }

    @Override
    public void onPostExecute(Object result) {
        if (CHECKERS_TASKS != null) {
            CHECKERS_TASKS.remove(this);
        }
        super.onPostExecute(result);
    }

    @Override
    public void onCancelled() {
        if (CHECKERS_TASKS != null) {
            CHECKERS_TASKS.remove(this);
        }
        super.onCancelled();
    }

    public static void cancelCheckingForCheckerRecord(long checkerRecordId) {
        if (CHECKERS_TASKS != null && checkerRecordId > 0) {
            Iterator it = CHECKERS_TASKS.iterator();
            while (it.hasNext()) {
                CheckerVolleyAsyncTask checkerVolleyAsyncTask = (CheckerVolleyAsyncTask) it.next();
                if (checkerVolleyAsyncTask != null && checkerVolleyAsyncTask.getCheckerRecordId() == checkerRecordId) {
                    checkerVolleyAsyncTask.cancel(true);
                }
            }
        }
    }
}
