package com.tekhnical.amplify.util;

import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.CurrencyPairsListWithDate;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class CurrencyPairsMapHelper {
    private final HashMap<String, String[]> currencyPairs = new LinkedHashMap();
    private final HashMap<String, String> currencyPairsIds = new HashMap<>();
    private long date;
    private int pairsCount = 0;

    public CurrencyPairsMapHelper(CurrencyPairsListWithDate currencyPairsListWithDate) {
        Integer currentCurrencyGroupSize;
        if (currencyPairsListWithDate != null) {
            this.date = currencyPairsListWithDate.date;
            List<CurrencyPairInfo> sortedPairs = currencyPairsListWithDate.pairs;
            this.pairsCount = sortedPairs.size();
            HashMap<String, Integer> currencyGroupSizes = new HashMap<>();
            for (CurrencyPairInfo currencyPairInfo : sortedPairs) {
                Integer currentCurrencyGroupSize2 = (Integer) currencyGroupSizes.get(currencyPairInfo.getCurrencyBase());
                if (currentCurrencyGroupSize2 == null) {
                    currentCurrencyGroupSize = Integer.valueOf(1);
                } else {
                    currentCurrencyGroupSize = Integer.valueOf(currentCurrencyGroupSize2.intValue() + 1);
                }
                currencyGroupSizes.put(currencyPairInfo.getCurrencyBase(), currentCurrencyGroupSize);
            }
            int currentGroupPositionToInsert = 0;
            for (CurrencyPairInfo currencyPairInfo2 : sortedPairs) {
                String[] currencyGroup = this.currencyPairs.get(currencyPairInfo2.getCurrencyBase());
                if (currencyGroup == null) {
                    currencyGroup = new String[(currencyGroupSizes.get(currencyPairInfo2.getCurrencyBase())).intValue()];
                    this.currencyPairs.put(currencyPairInfo2.getCurrencyBase(), currencyGroup);
                    currentGroupPositionToInsert = 0;
                } else {
                    currentGroupPositionToInsert++;
                }
                currencyGroup[currentGroupPositionToInsert] = currencyPairInfo2.getCurrencyCounter();
                if (currencyPairInfo2.getCurrencyPairId() != null) {
                    this.currencyPairsIds.put(createCurrencyPairKey(currencyPairInfo2.getCurrencyBase(), currencyPairInfo2.getCurrencyCounter()), currencyPairInfo2.getCurrencyPairId());
                }
            }
        }
    }

    public long getDate() {
        return this.date;
    }

    public HashMap<String, String[]> getCurrencyPairs() {
        return this.currencyPairs;
    }

    public String getCurrencyPairId(String currencyBase, String currencyCounter) {
        return (String) this.currencyPairsIds.get(createCurrencyPairKey(currencyBase, currencyCounter));
    }

    public int getPairsCount() {
        return this.pairsCount;
    }

    private String createCurrencyPairKey(String currencyBase, String currencyCounter) {
        return String.format("%1$s_%2$s", new Object[]{currencyBase, currencyCounter});
    }
}
