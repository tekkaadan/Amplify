package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class Bitso extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Bitso";
    private static final String TTS_NAME = "Bitso";
    private static final String URL = "https://api.bitso.com/public/info";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{"MXN"});
        CURRENCY_PAIRS.put(VirtualCurrency.ETH, new String[]{VirtualCurrency.BTC, "MXN"});
        CURRENCY_PAIRS.put(VirtualCurrency.XRP, new String[]{VirtualCurrency.BTC, "MXN"});
        CURRENCY_PAIRS.put(VirtualCurrency.BCH, new String[]{VirtualCurrency.BTC});
        CURRENCY_PAIRS.put(VirtualCurrency.LTC, new String[]{VirtualCurrency.BTC, "MXN"});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Bitso.png";
        //return "https://assets.coingecko.com/markets/images/33/small/luno.jpg";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bitso;
    }
    public Bitso() {
        super("bitso",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return URL;
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        String pairId = checkerInfo.getCurrencyPairId();
        if (pairId == null) {
            pairId = checkerInfo.getCurrencyBaseLowerCase() + "_" + checkerInfo.getCurrencyCounterLowerCase();
        }
        JSONObject pairJsonObject = jsonObject.getJSONObject("payload").getJSONObject(pairId);
        ticker.bid = ParseUtils.getDoubleFromString(pairJsonObject, "buy");
        ticker.ask = ParseUtils.getDoubleFromString(pairJsonObject, "sell");
        ticker.vol = ParseUtils.getDoubleFromString(pairJsonObject, "volume");
        ticker.last = ParseUtils.getDoubleFromString(pairJsonObject, "rate");
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray pairIds = jsonObject.getJSONObject("payload").names();
        for (int i = 0; i < pairIds.length(); i++) {
            String pairId = pairIds.getString(i);
            if (pairId != null) {
                String[] currencies = pairId.split("_");
                if (currencies.length >= 2) {
                    pairs.add(new CurrencyPairInfo(currencies[0].toUpperCase(Locale.US), currencies[1].toUpperCase(Locale.US), pairId));
                }
            }
        }
    }
}
