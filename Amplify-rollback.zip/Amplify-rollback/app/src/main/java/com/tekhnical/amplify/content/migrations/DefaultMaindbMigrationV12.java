package com.tekhnical.amplify.content.migrations;

import android.database.sqlite.SQLiteDatabase;

import com.robotoworks.mechanoid.db.SQLiteMigration;

public class DefaultMaindbMigrationV12 extends SQLiteMigration {
    public void onBeforeUp(SQLiteDatabase db) {
    }

    @Override
    public void up(SQLiteDatabase db) {
        db.execSQL("alter table checker add column holdingsAmount double not null default 0 ");
        db.execSQL("alter table checker add column frequencyType int not null default 0 ");
    }

    public void onAfterUp(SQLiteDatabase db) {
    }
}
