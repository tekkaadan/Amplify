package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class LBank extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "LBank";
    private static final String TTS_NAME = "LBank";
    private static final String URL = "https://api.lbkex.com/v1/ticker.do?symbol=%1$s";
    private static final String CURRENCIES_URL = "https://api.lbkex.com/v1/currencyPairs.do";

    public LBank() {
        super("lbank", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    @Override
    public int getImageUrl() {
        return R.drawable.lbank;
    }
    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/LBank.png";
        //return "https://assets.coingecko.com/markets/images/115/small/zb.jpg";
    }*/

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject("ticker");
        ticker.last = ParseUtils.getDouble(jsonObject, "latest");
        ticker.high = ParseUtils.getDouble(jsonObject, "high");
        ticker.low = ParseUtils.getDouble(jsonObject, "low");
        ticker.vol = ParseUtils.getDouble(jsonObject, "vol");
        if (tickerObject.has("timestamp"))
            ticker.timestamp = tickerObject.getLong("timestamp");
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            String pair = jsonArray.getString(i);
            String[] split = pair.split("_");
            if (split.length>=2)
                pairs.add(new CurrencyPairInfo(split[0],split[1],pair));

        }
    }

}
