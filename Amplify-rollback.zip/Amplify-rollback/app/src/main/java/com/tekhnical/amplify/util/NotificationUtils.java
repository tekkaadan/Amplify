package com.tekhnical.amplify.util;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Build.VERSION;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.internal.view.SupportMenu;
import androidx.core.app.NotificationCompat.Builder;

import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.SpannedString;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.RemoteViews;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.AppWidgetTarget;
import com.bumptech.glide.request.target.NotificationTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.google.gson.Gson;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.CheckerAddActivity;
import com.tekhnical.amplify.activity.CheckersListActivity;
import com.tekhnical.amplify.alarm.AlarmKlaxonHelper;
import com.tekhnical.amplify.model.CurrencySubunit;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.content.AlarmRecord;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.content.MaindbContract;
import com.tekhnical.amplify.content.MaindbContract.Checker;
import com.tekhnical.amplify.receiver.MarketChecker;
import com.tekhnical.amplify.receiver.NotificationAndWidgetReceiver;
import com.robotoworks.mechanoid.db.SQuery;
import com.robotoworks.mechanoid.db.SQuery.Op;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.net.URL;
import java.util.List;

public class NotificationUtils {
    private static final String NOTIFICATION_ALARM_TAG = "alarm";
    private static final String NOTIFICATION_CHECKER_TAG = "checker";

    public static void showOngoingNotification(Context context, CheckerRecord checkerRecord, boolean doNotSpeakTTS) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (checkerRecord != null) {
            if (checkerRecord.getEnabled()) {
                Market market = MarketsConfigUtils.getMarketByKey(checkerRecord.getMarketKey());
                Ticker lastCheckTicker = TickerUtils.fromJson(checkerRecord.getLastCheckTicker());
                if (market == null) {
                    return;
                }
                if (lastCheckTicker != null || checkerRecord.getErrorMsg() != null) {
                    Ticker previousCheckTicker = null;
                    String currencySrcWithContractType = FormatUtils.getCurrencySrcWithContractType(checkerRecord.getCurrencySrc(), market, (int) checkerRecord.getContractType());
                    CurrencySubunit subunitDst = CurrencyUtils.getCurrencySubunit(checkerRecord.getCurrencyDst(), checkerRecord.getCurrencySubunitDst());
                    if (checkerRecord.getNotificationPriority() >= -2) {
                        int iconResId ;
                        int iconBackgroundResId;
                        long timestamp;
                        CharSequence title;
                        CharSequence tickerMsg;
                        CharSequence contentText;
                        CharSequence bigStyleContentText = null;
                        Intent intent;
                        Object[] objArr;
                        if (checkerRecord.getErrorMsg() != null) {
                            iconResId = getIconResIdForNotification(null, null);
                            iconBackgroundResId = getIconBackgroundResIdForTickersLollipop(null, null);
                            timestamp = checkerRecord.getLastCheckDate();
                            objArr = new Object[2];
                            objArr[0] = context.getString(R.string.generic_currency_pair, new Object[]{currencySrcWithContractType, checkerRecord.getCurrencyDst()});
                            objArr[1] = market.name;
                            title = String.format(context.getString(R.string.notification_ongoing_title_error), objArr[0],objArr[1]);
                            tickerMsg = context.getString(R.string.check_error_generic_prefix, new Object[]{checkerRecord.getErrorMsg()});
                            contentText = tickerMsg;
                            bigStyleContentText = contentText;
                        } else if (lastCheckTicker != null) {
                            SpannableStringBuilder spannableStringBuilder;
                            Object contentText2;
                            previousCheckTicker = TickerUtils.fromJson(checkerRecord.getPreviousCheckTicker());
                            iconResId = getIconResIdForNotification(previousCheckTicker, lastCheckTicker);
                            iconBackgroundResId = getIconBackgroundResIdForTickersLollipop(previousCheckTicker, lastCheckTicker);
                            timestamp = lastCheckTicker.timestamp;
                            if(currencySrcWithContractType == null){
                                title = Html.fromHtml(context.getString(R.string.notification_ongoing_title_error, new Object[]{"<b>" + FormatUtilsBase.formatPriceWithCurrency(lastCheckTicker.last, subunitDst) + "</b>", market.name}));
                            }else
                                title = Html.fromHtml(context.getString(R.string.notification_ongoing_title, new Object[]{currencySrcWithContractType, "<b>" + FormatUtilsBase.formatPriceWithCurrency(lastCheckTicker.last, subunitDst) + "</b>", market.name}));
                            tickerMsg = title;
                            Spanned textLine1 = null;
                            if (lastCheckTicker.high >= 0.0d && lastCheckTicker.low >= 0.0d) {
                                textLine1 = Html.fromHtml(context.getString(R.string.notification_ongoing_text, new Object[]{"<b>" + FormatUtilsBase.formatPriceWithCurrency(lastCheckTicker.high, subunitDst) + "</b>", "<b>" + FormatUtilsBase.formatPriceWithCurrency(lastCheckTicker.low, subunitDst) + "</b>"}));
                            }
                            SpannableStringBuilder textLine2 = new SpannableStringBuilder();
                            if (lastCheckTicker.bid >= 0.0d) {
                                spannableStringBuilder = textLine2;
                                spannableStringBuilder.append(Html.fromHtml(context.getString(R.string.notification_ongoing_text_bid, new Object[]{"<b>" + FormatUtilsBase.formatPriceWithCurrency(lastCheckTicker.bid, subunitDst) + "</b>"})));
                            }
                            if (lastCheckTicker.ask >= 0.0d) {
                                if (textLine2.length() > 0) {
                                    textLine2.append(context.getString(R.string.notification_ongoing_text_separator));
                                }
                                spannableStringBuilder = textLine2;
                                spannableStringBuilder.append(Html.fromHtml(context.getString(R.string.notification_ongoing_text_ask, new Object[]{"<b>" + FormatUtilsBase.formatPriceWithCurrency(lastCheckTicker.ask, subunitDst) + "</b>"})));
                            }
                            Spanned textLine3 = null;
                            if (lastCheckTicker.vol >= 0.0d) {
                                objArr = new Object[1];
                                objArr[0] = "<b>" + FormatUtilsBase.formatPriceWithCurrency(lastCheckTicker.vol, checkerRecord.getCurrencySrc()) + "</b>";
                                textLine3 = Html.fromHtml(context.getString(R.string.notification_ongoing_text_volume, objArr));
                            }
                            contentText = "";
                            SpannableStringBuilder ssb = new SpannableStringBuilder();
                            if (textLine1 != null && textLine1.length() > 0) {
                                contentText = textLine1;
                                ssb.append(textLine1);
                            }
                            if (textLine2 != null && textLine2.length() > 0) {
                                if (ssb.length() > 0) {
                                    ssb.append("\n");
                                }
                                ssb.append(textLine2);
                            }
                            if (textLine3 != null && textLine3.length() > 0) {
                                if (ssb.length() > 0) {
                                    ssb.append("\n");
                                }
                                ssb.append(textLine3);
                            }
                            if (TextUtils.isEmpty(ssb)) {
                                contentText = new SpannedString(context.getString(R.string.notification_ongoing_text_no_info));
                                ssb.append(contentText);
                            }
                        } else {
                            return;
                        }
                        Builder builder = new Builder(context).setSmallIcon(R.drawable.amplify_icon).setContentTitle(title).setContentText(contentText).setOngoing(true).setOnlyAlertOnce(true).setWhen(timestamp).setPriority(-2).setContentIntent(createMainActivityPendingIntent(context));
                        if (PreferencesUtils.getCheckNotificationTicker(context)) {
                            builder.setTicker(tickerMsg);
                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            NotificationChannel mChannel = new NotificationChannel("cid", context.getString(R.string.app_name), NotificationManager.IMPORTANCE_HIGH);
                            builder.setChannelId("cid");
                            notificationManager.createNotificationChannel(mChannel);
                        }

                        if (PreferencesUtils.getCheckNotificationCustomLayout(context)) {
                            RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.notification_ongoing);
                            remoteViews.setImageViewResource(R.id.iconView, market.getImageUrl());
                            if (VERSION.SDK_INT >= 21) {
                                //remoteViews.setInt(R.id.iconView, "setBackgroundResource", iconBackgroundResId);
                                builder.setColor(context.getResources().getColor(getIconBackgroundColorResIdForTickersLollipop(previousCheckTicker, lastCheckTicker)));
                            }
                            remoteViews.setTextViewText(R.id.notificationTitle, title);
                            remoteViews.setTextViewText(R.id.notificationText, contentText);
                            intent = new Intent(NotificationAndWidgetReceiver.ACTION_NOTIFICATION_REFRESH, null, context, NotificationAndWidgetReceiver.class);
                            intent.putExtra(MarketChecker.EXTRA_CHECKER_RECORD_ID, checkerRecord.getId());
                            remoteViews.setOnClickPendingIntent(R.id.refreshButton, PendingIntent.getBroadcast(context, (int) checkerRecord.getId(), intent, PendingIntent.FLAG_UPDATE_CURRENT));
                            builder.setContent(remoteViews);

                        }
                        if (PreferencesUtils.getCheckNotificationExpandable(context)) {
                            NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle();
                            bigTextStyle.setBigContentTitle(title);
                            bigTextStyle.bigText(bigStyleContentText);
                            builder.setStyle(bigTextStyle);
                            builder.addAction(R.drawable.ic_notify_edit, context.getString(R.string.generic_edit), createCheckerDetailsPendingIntent(context, checkerRecord));
                            intent = new Intent(NotificationAndWidgetReceiver.ACTION_NOTIFICATION_REFRESH, null, context, NotificationAndWidgetReceiver.class);
                            intent.putExtra(MarketChecker.EXTRA_CHECKER_RECORD_ID, checkerRecord.getId());
                            builder.addAction(R.drawable.ic_notify_refresh, context.getString(R.string.generic_refresh), PendingIntent.getBroadcast(context, (int) checkerRecord.getId(), intent, PendingIntent.FLAG_UPDATE_CURRENT));
                        }
                        Notification notification = builder.build();
                        /*NotificationTarget notificationTarget = new NotificationTarget(context,R.id.iconView,remoteViews,notification, (int) checkerRecord.getId(),"checker");
                        Glide.with(context.getApplicationContext())
                                .asBitmap()
                                .load(market.getImageUrl())
                                .into(notificationTarget);*/
                        try {
                            notificationManager.notify("checker", (int) checkerRecord.getId(), notification);
                        }catch (Exception e) {
                            e.printStackTrace();
                            FirebaseCrashlytics.getInstance().recordException(e);
                        }
                    } else {
                        notificationManager.cancel("checker", (int) checkerRecord.getId());
                    }
                    if (!doNotSpeakTTS && checkerRecord.getTtsEnabled() && lastCheckTicker != null && checkerRecord.getErrorMsg() == null) {
                        TTSHelper.speak(context.getApplicationContext(), FormatUtils.formatTextForTTS(context, lastCheckTicker.last, checkerRecord, subunitDst, market));
                        return;
                    }
                    return;
                }
                return;
            }
            notificationManager.cancel("checker", (int) checkerRecord.getId());
        }
    }

    //TODO
    public static void showTotalPortfolioNotification(Context context){
        /*Cursor cursor =  SQuery.newQuery().select(Checker.CONTENT_URI,CheckerRecord.PROJECTION_PORTFOLIO, new String[]{ MaindbContract.CheckerColumns.CURRENCY_SRC});
        if (cursor != null) {
            if (cursor.getCount()>0){
                while (cursor.moveToNext()){
                    CheckerRecord item = CheckerRecord.fromCursor(cursor);
                    double total = item.getHoldingsAmount();
                    String srcCurrency = item.getCurrencySrc() != null ? item.getCurrencySrc() : item.getMarketKey();
                    Ticker lastCheckTicker = TickerUtils.fromJson(item.getLastCheckTicker());
                    Log.e("TOTAL",srcCurrency + " "+total);
                    if (total>0){
                        showPortfolioNotification(context,total,srcCurrency,lastCheckTicker);
                    }
                    else{
                        clearPortfolioNotification(context,srcCurrency);
                    }
                }
            }
            cursor.moveToFirst();
        }*/
        boolean isSpots = PreferencesUtils.getCheckPortfolioTicker(context,context.getString(R.string.spots));
        boolean isFutures = PreferencesUtils.getCheckPortfolioTicker(context,context.getString(R.string.futures));
        boolean isStocks = PreferencesUtils.getCheckPortfolioTicker(context,context.getString(R.string.stocks));
        List<CheckerRecord> list =  SQuery.newQuery().select(Checker.CONTENT_URI);
        double totalSpot=0, totalFuture = 0, totalStock = 0;
        for (CheckerRecord checkerRecord : list ) {
            if (checkerRecord.getHoldings() != null) {
                long marketType = checkerRecord.getMarketType();
                if (marketType == 0) {
                    totalSpot = totalSpot + checkerRecord.getHoldingsAmount();
                } else if (marketType == 1) {
                    totalFuture = totalFuture + checkerRecord.getHoldingsAmount();
                } else {
                    totalStock = totalStock + checkerRecord.getHoldingsAmount();
                }
            }
        }
        if (totalSpot>0 && isSpots){
            showPortfolioNotification(context,totalSpot,-1);
        }
        else{
            clearPortfolioNotification(context, -1);
        }

        if (totalFuture>0 && isFutures){
            showPortfolioNotification(context,totalFuture,-2);
        }
        else{
            clearPortfolioNotification(context, -2);
        }

        if (totalStock>0 && isStocks){
            showPortfolioNotification(context,totalStock,-3);
        }
        else{
            clearPortfolioNotification(context, -3);
        }
    }
    public static void showPortfolioNotification(Context context,double total, int code){
        int iconResId = getIconResIdForNotification(null, null);
        int iconBackgroundResId = getIconBackgroundResIdForTickersLollipop(null, null);
        //int marketType = CurrencyUtils.getCurrencyIcon(currency);
        String marketType = code == -1? context.getString(R.string.spots) : code == -2? context.getString(R.string.futures) : context.getString(R.string.stocks);
        String title = context.getString(R.string.app_name)+" "+marketType+" "+context.getString(R.string.portfolio);
        CharSequence contentText = Html.fromHtml(context.getString(R.string.notification_ongoing_portfolio_text, new Object[]{"<b>" + FormatUtilsBase.formatPriceWithCurrency(total, "USD") + "</b>"}));

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Builder builder = new Builder(context).setSmallIcon(iconResId).setContentTitle(title).setContentText(contentText).setOngoing(true).setOnlyAlertOnce(true).setPriority(-2).setContentIntent(createMainActivityPendingIntent(context));
        if (PreferencesUtils.getCheckNotificationTicker(context)) {
            builder.setTicker(contentText);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel mChannel = new NotificationChannel("cid", context.getString(R.string.app_name), NotificationManager.IMPORTANCE_HIGH);
            builder.setChannelId("cid");
            notificationManager.createNotificationChannel(mChannel);
        }

        if (PreferencesUtils.getCheckNotificationCustomLayout(context)) {
            RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.notification_ongoing);
            remoteViews.setImageViewResource(R.id.iconView, R.drawable.amplify_icon);
            if (VERSION.SDK_INT >= 21) {
                remoteViews.setInt(R.id.iconView, "setBackgroundResource", iconBackgroundResId);
                //builder.setColor(context.getResources().getColor(getIconBackgroundColorResIdForTickersLollipop(previousCheckTicker, lastCheckTicker)));
            }
            remoteViews.setTextViewText(R.id.notificationTitle, title);
            remoteViews.setTextViewText(R.id.notificationText, contentText);
            Intent intent = new Intent(NotificationAndWidgetReceiver.ACTION_NOTIFICATION_REFRESH, null, context, NotificationAndWidgetReceiver.class);
            intent.putExtra(MarketChecker.EXTRA_CHECKER_RECORD_ID, -2);
            remoteViews.setOnClickPendingIntent(R.id.refreshButton, PendingIntent.getBroadcast(context, -2, intent, PendingIntent.FLAG_UPDATE_CURRENT));
            builder.setContent(remoteViews);
        }
        if (PreferencesUtils.getCheckNotificationExpandable(context)) {
            NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle();
            bigTextStyle.setBigContentTitle(title);
            bigTextStyle.bigText(contentText);
            builder.setColor(context.getResources().getColor(R.color.background));
            builder.setStyle(bigTextStyle);
            Intent intent = new Intent(NotificationAndWidgetReceiver.ACTION_NOTIFICATION_REFRESH, null, context, NotificationAndWidgetReceiver.class);
            intent.putExtra(MarketChecker.EXTRA_CHECKER_RECORD_ID,-2);
            builder.addAction(R.drawable.ic_notify_refresh, context.getString(R.string.generic_refresh), PendingIntent.getBroadcast(context, -2, intent, PendingIntent.FLAG_UPDATE_CURRENT));
        }
        try {
            notificationManager.notify("checker", code, builder.build());
        }catch (Exception e){
            e.printStackTrace();
            FirebaseCrashlytics.getInstance().recordException(e);
        }

    }

    public static void showHideFearIndexNotification(Context context, boolean visible, Ticker value) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (visible) {
            int iconResId = getIconResIdForNotification(null, null);
            int iconBackgroundResId = getIconBackgroundResIdForTickersLollipop(null, null);
            String title = context.getString(R.string.cryptofearindex);
            CharSequence contentText = Html.fromHtml(context.getString(R.string.cryptofearindex_text, new Object[]{"<b>" + value.icon +":"+value.last + "%</b>"}));

            Builder builder = new Builder(context).setSmallIcon(iconResId).setContentTitle(title).setContentText(contentText).setOngoing(true).setOnlyAlertOnce(true).setPriority(-2).setContentIntent(createMainActivityPendingIntent(context));

            if (PreferencesUtils.getCheckNotificationTicker(context)) {
                builder.setTicker(contentText);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel mChannel = new NotificationChannel("cid", context.getString(R.string.app_name), NotificationManager.IMPORTANCE_HIGH);
                builder.setChannelId("cid");
                notificationManager.createNotificationChannel(mChannel);
            }

            if (PreferencesUtils.getCheckNotificationCustomLayout(context)) {
                RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.notification_ongoing);
                remoteViews.setImageViewResource(R.id.iconView, R.drawable.amplify_icon);
                if (VERSION.SDK_INT >= 21) {
                    remoteViews.setInt(R.id.iconView, "setBackgroundResource", iconBackgroundResId);
                    //builder.setColor(context.getResources().getColor(getIconBackgroundColorResIdForTickersLollipop(previousCheckTicker, lastCheckTicker)));
                }
                remoteViews.setTextViewText(R.id.notificationTitle, title);
                remoteViews.setTextViewText(R.id.notificationText, contentText);
                Intent intent = new Intent(NotificationAndWidgetReceiver.ACTION_NOTIFICATION_REFRESH, null, context, NotificationAndWidgetReceiver.class);
                intent.putExtra(MarketChecker.EXTRA_CHECKER_RECORD_ID, -5);
                remoteViews.setOnClickPendingIntent(R.id.refreshButton, PendingIntent.getBroadcast(context, -2, intent, PendingIntent.FLAG_UPDATE_CURRENT));
                builder.setContent(remoteViews);
            }
            if (PreferencesUtils.getCheckNotificationExpandable(context)) {
                NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle();
                bigTextStyle.setBigContentTitle(title);
                bigTextStyle.bigText(contentText);
                builder.setColor(context.getResources().getColor(R.color.background));
                builder.setStyle(bigTextStyle);
                Intent intent = new Intent(NotificationAndWidgetReceiver.ACTION_NOTIFICATION_REFRESH, null, context, NotificationAndWidgetReceiver.class);
                intent.putExtra(MarketChecker.EXTRA_CHECKER_RECORD_ID,-2);
                builder.addAction(R.drawable.ic_notify_refresh, context.getString(R.string.generic_refresh), PendingIntent.getBroadcast(context, -2, intent, PendingIntent.FLAG_UPDATE_CURRENT));
            }
            try {
                notificationManager.notify("checker", -5, builder.build());
            }catch (Exception e){
                e.printStackTrace();
                FirebaseCrashlytics.getInstance().recordException(e);
            }
        }
        else
            notificationManager.cancel("checker", -5);

    }

    public static void refreshOngoingNotifications(Context context) {
        List<CheckerRecord> list =  SQuery.newQuery().expr("enabled", Op.EQ, true).and().expr(MaindbContract.CheckerColumns.NOTIFICATION_PRIORITY, Op.GTEQ, -2).select(Checker.CONTENT_URI);
        for (CheckerRecord checkerRecord : list ) {
            showOngoingNotification(context, checkerRecord, true);
        }
        showTotalPortfolioNotification(context);
    }

    public static boolean checkfThereIsAlertSituationAndShowAlertNotification(Context context, CheckerRecord checkerRecord, Ticker ticker) {
        String soundAlarmNotificationUp;
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        boolean wasPriceSpoken = false;
        if (!checkerRecord.getEnabled()) {
            clearAlarmNotificationForCheckerRecord(context, notificationManager, checkerRecord);
            return false;
        } else if (checkerRecord.getErrorMsg() != null) {
            return false;
        } else {
            for (AlarmRecord alarmRecord : CheckerRecordHelper.getAlarmsForCheckerRecord(checkerRecord, false)) {
                if (alarmRecord != null) {
                    if (!alarmRecord.getEnabled()) {
                        notificationManager.cancel("alarm", (int) alarmRecord.getId());
                    } else {
                        boolean shouldAlarmBeTriggered = true;
                        boolean isDown = false;
                        Spanned text = null;
                        Spanned title = null;
                        String ttsString = "";
                        Market market = MarketsConfigUtils.getMarketByKey(checkerRecord.getMarketKey());
                        String currencySrcWithContractType = FormatUtils.getCurrencySrcWithContractType(checkerRecord.getCurrencySrc(), market, (int) checkerRecord.getContractType());
                        CurrencySubunit subunitDst = CurrencyUtils.getCurrencySubunit(checkerRecord.getCurrencyDst(), checkerRecord.getCurrencySubunitDst());

                        int alarmTypeInt = (int) alarmRecord.getType();
                        switch (alarmTypeInt) {
                            case 0:
                            case 1:
                            case 2:
                                Ticker lastCheckPointTicker = TickerUtils.fromJson(alarmRecord.getLastCheckPointTicker());
                                if (lastCheckPointTicker != null) {
                                    double percentageDifference = AlarmRecordHelper.getDifferenceForPercentageChange(lastCheckPointTicker.last, ticker.last);
                                    double alertTreshold = alarmRecord.getValue();
                                    if (alarmTypeInt != 0 || Math.abs(percentageDifference) >= alertTreshold) {
                                        if (alarmTypeInt != 1 || percentageDifference >= alertTreshold) {
                                            if (alarmTypeInt == 2 && percentageDifference > (-alertTreshold)) {
                                                shouldAlarmBeTriggered = false;
                                                break;
                                            } else {
                                                alarmRecord.setLastCheckPointTicker(TickerUtils.toJson(ticker));
                                                alarmRecord.save();
                                                isDown = percentageDifference < 0.0d;
                                                String ttsDownOrUpString = context.getString(isDown ? R.string.notification_alert_tts_text_down : R.string.notification_alert_tts_text_up);
                                                if(currencySrcWithContractType == null){
                                                    title = Html.fromHtml(context.getString(R.string.notification_ongoing_title_error, new Object[]{"<b>" + FormatUtilsBase.formatPriceWithCurrency(ticker.last, subunitDst) + "</b>", market.name}));
                                                }else
                                                    title = Html.fromHtml(context.getString(R.string.notification_alert_title_percent_change, new Object[]{currencySrcWithContractType, "<b>" + FormatUtilsBase.formatPriceWithCurrency(ticker.last, subunitDst) + "</b>", market.name}));

                                                Object[] objArr = new Object[3];
                                                objArr[0] = "<b>" + (percentageDifference > 0.0d ? "+" : "") + FormatUtils.formatDouble(percentageDifference, false) + "%</b>";
                                                objArr[1] = "<b>" + FormatUtils.formatPriceWithCurrency(lastCheckPointTicker.last, subunitDst) + "</b>";
                                                objArr[2] = FormatUtils.formatRelativeTime(context, lastCheckPointTicker.timestamp, ticker.timestamp, true);
                                                text = Html.fromHtml(context.getString(R.string.notification_alert_text_percent_change, objArr));
                                                ttsString = context.getString(R.string.notification_alert_tts_text_percent_value_change, new Object[]{ttsDownOrUpString, FormatUtils.formatTextForTTS(context, lastCheckPointTicker.last, checkerRecord, true, subunitDst, true, market, true), FormatUtils.formatTextForTTS(context, ticker.last, checkerRecord, true, subunitDst, false, market, false)});
                                                if (PreferencesUtils.getTTSFormatSpeakBaseCurrency(context)) {
                                                    ttsString = context.getString(R.string.tts_format_base_currency, new Object[]{checkerRecord.getCurrencySrc(), ttsString});
                                                    break;
                                                }
                                            }
                                        } else {
                                            shouldAlarmBeTriggered = false;
                                            break;
                                        }
                                    } else {
                                        shouldAlarmBeTriggered = false;
                                        break;
                                    }
                                } else {
                                    alarmRecord.setLastCheckPointTicker(TickerUtils.toJson(ticker));
                                    alarmRecord.save();
                                    shouldAlarmBeTriggered = false;
                                    break;
                                }
                                break;
                            case 3:
                            case 4:
                            case 5:
                                Ticker lastCheckPointTicker2 = TickerUtils.fromJson(alarmRecord.getLastCheckPointTicker());
                                if (lastCheckPointTicker2 != null) {
                                    BigDecimal alertTreshold2 = FormatUtils.fixSatoshi(alarmRecord.getValue());
                                    BigDecimal valueDifference = FormatUtils.fixSatoshi(ticker.last).subtract(FormatUtils.fixSatoshi(lastCheckPointTicker2.last));
                                    if (alarmTypeInt != 3 || valueDifference.abs().compareTo(alertTreshold2) >= 0) {
                                        if (alarmTypeInt == 4 && valueDifference.compareTo(alertTreshold2) < 0) {
                                            shouldAlarmBeTriggered = false;
                                            break;
                                        } else {
                                            if (alarmTypeInt == 5) {
                                                if (valueDifference.compareTo(alertTreshold2.negate()) > 0) {
                                                    shouldAlarmBeTriggered = false;
                                                    break;
                                                }
                                            }
                                            alarmRecord.setLastCheckPointTicker(TickerUtils.toJson(ticker));
                                            alarmRecord.save();
                                            isDown = valueDifference.doubleValue() < 0.0d;
                                            String ttsDownOrUpString2 = context.getString(isDown ? R.string.notification_alert_tts_text_down : R.string.notification_alert_tts_text_up);
                                            if(currencySrcWithContractType == null){
                                                title = Html.fromHtml(context.getString(R.string.notification_ongoing_title_error, new Object[]{"<b>" + FormatUtilsBase.formatPriceWithCurrency(ticker.last, subunitDst) + "</b>", market.name}));
                                            }else
                                                title = Html.fromHtml(context.getString(R.string.notification_alert_title_value_change, new Object[]{currencySrcWithContractType, "<b>" + FormatUtilsBase.formatPriceWithCurrency(ticker.last, subunitDst) + "</b>", market.name}));

                                            Object[] objArr2 = new Object[3];
                                            objArr2[0] = "<b>" + (valueDifference.doubleValue() > 0.0d ? "+" : "") + FormatUtils.formatPriceWithCurrency(valueDifference.doubleValue(), subunitDst) + "</b>";
                                            objArr2[1] = "<b>" + FormatUtils.formatPriceWithCurrency(lastCheckPointTicker2.last, subunitDst) + "</b>";
                                            objArr2[2] = FormatUtils.formatRelativeTime(context, lastCheckPointTicker2.timestamp, ticker.timestamp, true);
                                            text = Html.fromHtml(context.getString(R.string.notification_alert_text_value_change, objArr2));
                                            ttsString = context.getString(R.string.notification_alert_tts_text_percent_value_change, new Object[]{ttsDownOrUpString2, FormatUtils.formatTextForTTS(context, lastCheckPointTicker2.last, checkerRecord, true, subunitDst, true, market, true), FormatUtils.formatTextForTTS(context, ticker.last, checkerRecord, true, subunitDst, false, market, false)});
                                            if (PreferencesUtils.getTTSFormatSpeakBaseCurrency(context)) {
                                                ttsString = context.getString(R.string.tts_format_base_currency, new Object[]{checkerRecord.getCurrencySrc(), ttsString});
                                                break;
                                            }
                                        }
                                    } else {
                                        shouldAlarmBeTriggered = false;
                                        break;
                                    }
                                } else {
                                    alarmRecord.setLastCheckPointTicker(TickerUtils.toJson(ticker));
                                    alarmRecord.save();
                                    shouldAlarmBeTriggered = false;
                                    break;
                                }
                                break;
                            case 6:
                                if (ticker.last >= alarmRecord.getValue()) {
                                    isDown = false;
                                    if(currencySrcWithContractType == null){
                                        title = Html.fromHtml(context.getString(R.string.notification_ongoing_title_error, new Object[]{"<b>" + FormatUtilsBase.formatPriceWithCurrency(ticker.last, subunitDst) + "</b>", market.name}));
                                    }else
                                        title = Html.fromHtml(context.getString(R.string.notification_alert_title_greater_lower, new Object[]{currencySrcWithContractType, "<b>" + FormatUtilsBase.formatPriceWithCurrency(ticker.last, subunitDst) + "</b>", market.name}));

                                    text = Html.fromHtml(context.getString(R.string.notification_alert_text_greater_than, new Object[]{"<b>" + FormatUtils.formatPriceWithCurrency(alarmRecord.getValue(), subunitDst) + "</b>"}));
                                    ttsString = context.getString(R.string.notification_alert_tts_text_greater_lower, new Object[]{FormatUtils.formatTextForTTS(context, ticker.last, checkerRecord, subunitDst, market)});
                                    break;
                                } else {
                                    shouldAlarmBeTriggered = false;
                                    break;
                                }
                            case 7:
                                if (ticker.last <= alarmRecord.getValue()) {
                                    isDown = true;
                                    if(currencySrcWithContractType == null){
                                        title = Html.fromHtml(context.getString(R.string.notification_ongoing_title_error, new Object[]{"<b>" + FormatUtilsBase.formatPriceWithCurrency(ticker.last, subunitDst) + "</b>", market.name}));
                                    }else
                                        title = Html.fromHtml(context.getString(R.string.notification_alert_title_greater_lower, new Object[]{currencySrcWithContractType, "<b>" + FormatUtilsBase.formatPriceWithCurrency(ticker.last, subunitDst) + "</b>", market.name}));

                                    text = Html.fromHtml(context.getString(R.string.notification_alert_text_lower_than, new Object[]{"<b>" + FormatUtils.formatPriceWithCurrency(alarmRecord.getValue(), subunitDst) + "</b>"}));
                                    ttsString = context.getString(R.string.notification_alert_tts_text_greater_lower, new Object[]{FormatUtils.formatTextForTTS(context, ticker.last, checkerRecord, subunitDst, market)});
                                    break;
                                } else {
                                    shouldAlarmBeTriggered = false;
                                    break;
                                }
                            default:
                                shouldAlarmBeTriggered = false;
                                break;
                        }
                        if (!shouldAlarmBeTriggered) {
                            notificationManager.cancel("alarm", (int) alarmRecord.getId());
                        } else {
                            Builder builder = new Builder(context).setContentTitle(title).setContentText(text).setTicker(title).setOngoing(false).setAutoCancel(true).setOnlyAlertOnce(false).setWhen(ticker.timestamp).setPriority(2).setContentIntent(createCheckerAlertDetailsPendingIntent(context, checkerRecord, alarmRecord));
                            if (VERSION.SDK_INT >= 21) {
                                builder.setSmallIcon(R.drawable.amplify_icon);
                                builder.setColor(context.getResources().getColor(isDown ? R.color.circle_red : R.color.circle_green));
                            } else {
                                builder.setSmallIcon(R.drawable.amplify_icon);
                            }
                            builder.setDeleteIntent(createAlarmDismissPendingIntent(context, checkerRecord, alarmRecord));

                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                NotificationChannel mChannel = new NotificationChannel("cid", context.getString(R.string.app_name), NotificationManager.IMPORTANCE_HIGH);
                                builder.setChannelId("cid");
                                mChannel.enableLights(true);
                                if (alarmRecord.getSound()) {
                                    AudioAttributes audioAttributes = new AudioAttributes.Builder()
                                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                            .setUsage(AudioAttributes.USAGE_ALARM)
                                            .build();
                                    if (isDown) {
                                        soundAlarmNotificationUp = PreferencesUtils.getSoundAlarmNotificationDown(context);
                                    } else {
                                        soundAlarmNotificationUp = PreferencesUtils.getSoundAlarmNotificationUp(context);
                                    }
                                    mChannel.setSound(Uri.parse(soundAlarmNotificationUp), audioAttributes);
                                }
                                notificationManager.createNotificationChannel(mChannel);
                            }else{
                                if (0 != 0) {
                                    builder.addAction(R.drawable.ic_notification_small_close, context.getResources().getString(R.string.notification_alert_action_dismiss), AlarmKlaxonHelper.createAlarmKlaxonDismissPendingIntent(context, checkerRecord.getId(), alarmRecord.getId()));
                                } else if (alarmRecord.getSound()) {
                                    if (isDown) {
                                        soundAlarmNotificationUp = PreferencesUtils.getSoundAlarmNotificationDown(context);
                                    } else {
                                        soundAlarmNotificationUp = PreferencesUtils.getSoundAlarmNotificationUp(context);
                                    }
                                    builder.setSound(Uri.parse(soundAlarmNotificationUp), PreferencesUtils.getSoundsAdvancedAlarmStream(context));
                                }
                            }

                            if (alarmRecord.getVibrate()) {
                                builder.setVibrate(new long[]{0, 500, 250, 500});
                            }
                            if (alarmRecord.getLed()) {
                                builder.setLights(isDown ? Color.RED : Color.GREEN, 1000, 1000);
                            }
                            notificationManager.cancel("alarm", (int) alarmRecord.getId());
                            try {
                                notificationManager.notify("alarm", (int) alarmRecord.getId(), builder.build());
                                AlarmKlaxonHelper.startAlarmKlaxon(context, alarmRecord);
                            }catch (Exception e){
                                e.printStackTrace();
                                FirebaseCrashlytics.getInstance().recordException(e);
                            }
                            if (alarmRecord.getTtsEnabled() && !TextUtils.isEmpty(ttsString)) {
                                TTSHelper.speak(context.getApplicationContext(), ttsString);
                                wasPriceSpoken |= true;
                            }
                        }
                    }
                }
            }
            return wasPriceSpoken;
        }
    }

    public static PendingIntent createMainActivityPendingIntent(Context context) {
        Intent intent = new Intent(context, CheckersListActivity.class);
        intent.setFlags(603979776);
        return PendingIntent.getActivity(context, 0, intent, 0);
    }

    private static PendingIntent createCheckerDetailsPendingIntent(Context context, CheckerRecord checkerRecord) {
        Intent intent = new Intent(context, CheckerAddActivity.class);
        intent.putExtra(MarketChecker.EXTRA_CHECKER_RECORD_ID, checkerRecord.getId());
        return PendingIntent.getActivity(context, (int) checkerRecord.getId(), intent, 0);
    }

    private static PendingIntent createCheckerAlertDetailsPendingIntent(Context context, CheckerRecord checkerRecord, AlarmRecord alarmRecord) {
        Intent intent = new Intent(NotificationAndWidgetReceiver.ACTION_NOTIFICATION_CHECKER_ALARM_DETAILS, null, context, NotificationAndWidgetReceiver.class);
        intent.putExtra(MarketChecker.EXTRA_CHECKER_RECORD_ID, checkerRecord.getId());
        intent.putExtra(MarketChecker.EXTRA_ALARM_RECORD_ID, alarmRecord.getId());
        return PendingIntent.getBroadcast(context, (int) alarmRecord.getId(), intent, 0);
    }

    private static PendingIntent createAlarmDismissPendingIntent(Context context, CheckerRecord checkerRecord, AlarmRecord alarmRecord) {
        Intent intent = new Intent(NotificationAndWidgetReceiver.ACTION_NOTIFICATION_ALARM_DISMISS, null, context, NotificationAndWidgetReceiver.class);
        intent.putExtra(MarketChecker.EXTRA_CHECKER_RECORD_ID, checkerRecord.getId());
        intent.putExtra(MarketChecker.EXTRA_ALARM_RECORD_ID, alarmRecord.getId());
        return PendingIntent.getBroadcast(context, (int) alarmRecord.getId(), intent, PendingIntent.FLAG_CANCEL_CURRENT);
    }

    public static void clearOngoingNotification(Context context, CheckerRecord checkerRecord) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        clearOngoingNotificationForCheckerRecord(context, notificationManager, checkerRecord);
    }
    public static void clearPortfolioNotification(Context context, int code) {
        //int marketType =  CurrencyUtils.getCurrencyIcon(srcCurrency);
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel("checker", code);
    }

    private static void clearOngoingNotificationForCheckerRecord(Context context, NotificationManager notificationManager, CheckerRecord checkerRecord) {
        notificationManager.cancel("checker", (int) checkerRecord.getId());
    }

    public static void clearAlarmNotificationForCheckerRecord(Context context, CheckerRecord checkerRecord) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        clearAlarmNotificationForCheckerRecord(context, notificationManager, checkerRecord);
    }

    private static void clearAlarmNotificationForCheckerRecord(Context context, NotificationManager notificationManager, CheckerRecord checkerRecord) {
        for (Long longValue : CheckerRecordHelper.getAlarmsIdsForCheckerRecord(checkerRecord.getId())) {
            long alarmRecordId = longValue.longValue();
            if (alarmRecordId > 0) {
                notificationManager.cancel("alarm", (int) alarmRecordId);
            }
        }
    }

    public static void clearAlarmNotificationForAlarmRecord(Context context, long alarmRecordId) {
        if (alarmRecordId > 0) {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.cancel("alarm", (int) alarmRecordId);
        }
    }

    public static void clearNotificationsForCheckerRecord(Context context, CheckerRecord checkerRecord) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        clearOngoingNotificationForCheckerRecord(context, notificationManager, checkerRecord);
        clearAlarmNotificationForCheckerRecord(context, notificationManager, checkerRecord);
    }

    public static int getIconResIdForTickers(Ticker previousCheckTicker, Ticker lastCheckTicker, boolean useGrayRightIcon) {
        if (previousCheckTicker == null || lastCheckTicker == null || previousCheckTicker.last == lastCheckTicker.last) {
            return useGrayRightIcon ? R.drawable.ic_notify_right_gray : R.drawable.ic_notify_right;
        }
        if (lastCheckTicker.last > previousCheckTicker.last) {
            return R.drawable.ic_notify_up;
        }
        return R.drawable.ic_notify_down;
    }

    private static int getIconResIdForNotification(Ticker previousCheckTicker, Ticker lastCheckTicker) {
        boolean isLollipop = VERSION.SDK_INT >= 21;
        return (isLollipop ? R.drawable.amplify_icon : R.drawable.amplify_icon);
    }

    private static int getIconBackgroundResIdForTickersLollipop(Ticker previousCheckTicker, Ticker lastCheckTicker) {
        if (previousCheckTicker == null || lastCheckTicker == null || previousCheckTicker.last == lastCheckTicker.last) {
            return R.drawable.circle_gray;
        }
        if (lastCheckTicker.last > previousCheckTicker.last) {
            return R.drawable.circle_green;
        }
        return R.drawable.circle_red;
    }

    public static int getIconBackgroundColorResIdForTickersLollipop(Ticker previousCheckTicker, Ticker lastCheckTicker) {
        if (previousCheckTicker == null || lastCheckTicker == null || previousCheckTicker.last == lastCheckTicker.last) {
            return R.color.circle_gray;
        }
        if (lastCheckTicker.last > previousCheckTicker.last) {
            return R.color.circle_green;
        }
        return R.color.circle_red;
    }
}
