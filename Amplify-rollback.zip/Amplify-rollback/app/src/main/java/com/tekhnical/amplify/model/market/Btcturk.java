package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class Btcturk extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "BtcTurk";
    private static final String TTS_NAME = "Btc Turk";
    private static final String URL = "https://api.btcturk.com/api/v2/ticker";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{Currency.TRY});
        CURRENCY_PAIRS.put(VirtualCurrency.ETH, new String[]{VirtualCurrency.BTC, Currency.TRY});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/BTCTurk.png";
        //return "https://assets.coingecko.com/markets/images/223/small/BTCTurk-exchange.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.btcturk;
    }
    public Btcturk() {
        super("btcturk",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return URL;
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray tickerJsonArray = jsonObject.getJSONArray("data");
        String pairId = checkerInfo.getCurrencyBase() + checkerInfo.getCurrencyCounter();
        for (int i = 0; i < tickerJsonArray.length(); i++) {
            JSONObject tickerJsonObject = tickerJsonArray.getJSONObject(i);
            if (pairId.equals(tickerJsonObject.getString("pair"))) {
                ticker.bid = ParseUtils.getDouble(tickerJsonObject,"bid");
                ticker.ask = ParseUtils.getDouble(tickerJsonObject,"ask");
                ticker.vol = ParseUtils.getDouble(tickerJsonObject,"volume");
                ticker.high = ParseUtils.getDouble(tickerJsonObject,"high");
                ticker.low = ParseUtils.getDouble(tickerJsonObject,"low");
                ticker.last = ParseUtils.getDouble(tickerJsonObject,"last");
                ticker.timestamp = (long) (ParseUtils.getDouble(tickerJsonObject,"timestamp") * 1000);
                return;
            }
        }
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray resultJsonArray = jsonObject.getJSONArray("data");
        for (int i = 0; i < resultJsonArray.length(); i++) {
            JSONObject marketJsonObject = resultJsonArray.getJSONObject(i);
            if(marketJsonObject.has("pairNormalized") && marketJsonObject.has("pair")) {
                String exc = marketJsonObject.getString("pairNormalized");
                pairs.add(new CurrencyPairInfo(exc.substring(0,exc.indexOf("_")),exc.substring(exc.indexOf("_")+1), marketJsonObject.getString("pair")));
            }
        }
    }
}
