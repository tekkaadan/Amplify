package com.tekhnical.amplify.model.market.futures;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.FuturesMarket;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class HuobiFuture extends FuturesMarket {
    public static final String ID = "huobi_futures";
    private static final String NAME = "Huobi Future";
    private static final String TTS_NAME = "Huobi Future";
    private static final String URL = "https://api.hbdm.com/market/detail/merged?symbol=%s";
    private static final String URL_CURRENCY_PAIRS = "https://api.hbdm.com/api/v1/contract_contract_info";

    public HuobiFuture() {
        super(ID,"Huobi", "Huobi", null,new int[]{1,2,5,6});
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo,int contractType) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject tickerJsonObject = jsonObject.getJSONObject("tick");
        if(tickerJsonObject.has("bid"))
            ticker.bid = tickerJsonObject.getJSONArray("bid").getDouble(0);
        if (tickerJsonObject.has("ask"))
            ticker.ask = tickerJsonObject.getJSONArray("ask").getDouble(0);
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject,"vol");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject,"high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject,"low");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject,"close");
        ticker.usd = ParseUtils.getDoubleFromString(jsonObject,"close");
    }

    @Override
    public int getImageUrl() {
        return R.drawable.huobi_futures;
    }
    /*@Override
    public String getImageUrl() {
        //return "https://assets.coingecko.com/markets/images/433/small/huobifutures.png";
        return "file:///android_asset/logos/HuobiFutures.png";
    }*/

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> pairs) throws Exception {
        if ("ok".equalsIgnoreCase(jsonObject.getString("status"))) {
            JSONArray data = jsonObject.getJSONArray("data");
            for (int i = 0; i < data.length(); i++) {
                JSONObject pairObject = data.getJSONObject(i);
                String id = pairObject.getString("symbol");
                String contractType = pairObject.getString("contract_type");
                if (contractType.equalsIgnoreCase("this_week"))
                    id = id+"_CW";
                else if (contractType.equalsIgnoreCase("next_week"))
                    id = id +"_NW";
                else if (contractType.equalsIgnoreCase("quarter"))
                    id = id+"_CQ";
                else if (contractType.equalsIgnoreCase("next_quarter"))
                    id = id+"_NQ";
                pairs.add(new CurrencyPairInfo(ParseUtils.getString(pairObject,"symbol"), "USD", id));
            }
            return;
        }
        throw new Exception("Parse currency pairs error.");
    }
}
