package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class VebitCoin extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "VebitCoin";
    private static final String TTS_NAME = "Vebit Coin";
    private static final String URL = "https://prod-data-publisher.azurewebsites.net/api/ticker?sourcecoin=%1$s&targetcoin=%2$s";
    private static final String CURRENCIES_URL = "https://prod-data-publisher.azurewebsites.net/api/ticker";

    public VebitCoin() {
        super("vebitcoin", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyBaseLowerCase(),checkerInfo.getCurrencyCounterLowerCase()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Vebitcoin.png";
        //return "https://assets.coingecko.com/markets/images/220/small/vebitcoin.jpg";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.vebitcoin;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject(checkerInfo.getCurrencyPairId());
        ticker.bid = ParseUtils.getDouble(jsonObject, "Bid");
        ticker.ask = ParseUtils.getDouble(jsonObject, "Ask");
        ticker.last = ParseUtils.getDouble(jsonObject, "Price");
        ticker.high = ParseUtils.getDouble(jsonObject, "High");
        ticker.low = ParseUtils.getDouble(jsonObject, "Low");
        ticker.vol = ParseUtils.getDouble(jsonObject, "Volume");
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("SourceCoinCode")){
                pairs.add(new CurrencyPairInfo(jsonObject.getString("SourceCoinCode"),jsonObject.getString("TargetCoinCode"),jsonObject.getString("Id")));
            }
        }
    }

}
