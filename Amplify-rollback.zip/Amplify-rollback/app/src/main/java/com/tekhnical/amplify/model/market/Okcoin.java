package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class Okcoin extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "OKCoin";
    private static final String TTS_NAME = "OK Coin";
    private static final String URL_CURRENCY_PAIRS = "https://www.okcoin.com/api/spot/v3/instruments";
    private static final String URL = "https://www.okcoin.com/api/spot/v3/instruments/%1$s_%2$s/ticker";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{Currency.CNY, Currency.USD});
        CURRENCY_PAIRS.put(VirtualCurrency.LTC, new String[]{Currency.CNY, Currency.USD});
    }

    public Okcoin() {
        super("okcoin",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyBaseLowerCase(), checkerInfo.getCurrencyCounterLowerCase()});
    }

    @Override
    public int getImageUrl() {
        return R.drawable.okcoin;
    }
    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/OKCoin.png";
        //return "https://assets.coingecko.com/markets/images/415/small/okcoin.png";
    }*/

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerJsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDoubleFromString(tickerJsonObject,"bid");
        ticker.ask = ParseUtils.getDoubleFromString(tickerJsonObject,"ask");
        ticker.vol = ParseUtils.getDoubleFromString(tickerJsonObject,"base_volume_24h");
        ticker.high = ParseUtils.getDoubleFromString(tickerJsonObject,"high_24h");
        ticker.low = ParseUtils.getDoubleFromString(tickerJsonObject,"low_24h");
        ticker.last = ParseUtils.getDoubleFromString(tickerJsonObject,"last");
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray tickerArray = new JSONArray(responseString);
        for (int i = 0; i < tickerArray.length(); i++) {
            JSONObject tickerJsonObject = tickerArray.getJSONObject(i);
            if(tickerJsonObject.has("instrument_id")) {
                pairs.add(new CurrencyPairInfo(tickerJsonObject.getString("base_currency"), tickerJsonObject.getString("quote_currency"), tickerJsonObject.getString("instrument_id")));

            }
        }
    }
}
