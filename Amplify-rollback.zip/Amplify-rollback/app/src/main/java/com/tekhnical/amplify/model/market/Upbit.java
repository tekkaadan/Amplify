package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Upbit extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Upbit";
    private static final String TTS_NAME = "Upbit";
    private static final String URL = "https://api.upbit.com/v1/candles/days?market=%1$s";
    private static final String CURRENCIES_URL = "https://api.upbit.com/v1/market/all";


    public Upbit() {
        super("upbit", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Upbit.png";
        //return "https://assets.coingecko.com/markets/images/117/small/upbit.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.upbit;
    }
    @Override
    public void parseTicker(int requestId, String responseString, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        JSONObject jsonObject = jsonArray.getJSONObject(0);
        ticker.last = ParseUtils.getDouble(jsonObject, "trade_price");
        ticker.low = ParseUtils.getDouble(jsonObject, "low_price");
        ticker.high = ParseUtils.getDouble(jsonObject, "high_price");
        ticker.vol = ParseUtils.getDouble(jsonObject, "candle_acc_trade_volume");

    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            String[] split = jsonObject.getString("market").split("-");
            if (split.length >= 2)
                pairs.add(new CurrencyPairInfo(split[0], split[1], jsonObject.getString("market")));

        }
    }


}
