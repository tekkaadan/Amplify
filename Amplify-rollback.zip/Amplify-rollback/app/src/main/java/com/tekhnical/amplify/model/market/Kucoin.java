package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class Kucoin extends Market {
    private static final String NAME = "Kucoin";
    private static final String TTS_NAME = "Kucoin";
    private static final String URL = "https://api.kucoin.com/api/v1/market/stats?symbol=%1$s";
    private static final String URL_COINS_PAIRS = "https://api.kucoin.com/api/v1/symbols";

    public Kucoin() {
        super("kucoin",NAME, TTS_NAME, null);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

   /* @Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Kucoin.png";
        //return "https://assets.coingecko.com/markets/images/61/small/kucoin.jpg";
    }*/
   @Override
   public int getImageUrl() {
       return R.drawable.kukoin;
   }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject tickerJsonObject = jsonObject.getJSONObject("data");
        ticker.bid = ParseUtils.getDoubleFromString(tickerJsonObject,"buy");
        ticker.ask = ParseUtils.getDoubleFromString(tickerJsonObject,"sell");
        ticker.vol = ParseUtils.getDoubleFromString(tickerJsonObject,"vol");
        ticker.high = ParseUtils.getDoubleFromString(tickerJsonObject,"high");
        ticker.low = ParseUtils.getDoubleFromString(tickerJsonObject,"low");
        ticker.last = ParseUtils.getDoubleFromString(tickerJsonObject,"last");
        if(tickerJsonObject.has("time"))
            ticker.timestamp = tickerJsonObject.getLong("time");
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_COINS_PAIRS;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray data = jsonObject.getJSONArray("data");
        for (int i = 0; i < data.length(); i++) {
            JSONObject pairJsonObject = data.getJSONObject(i);
            if(pairJsonObject.has("quoteCurrency") && pairJsonObject.has("baseCurrency") && pairJsonObject.has("symbol"))
                pairs.add(new CurrencyPairInfo(pairJsonObject.getString("baseCurrency"), pairJsonObject.getString("quoteCurrency"), pairJsonObject.getString("symbol")));
        }
    }
}
