package com.tekhnical.amplify.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.tbuonomo.viewpagerdotsindicator.DotsIndicator;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.generic.OnboardingListener;
import com.tekhnical.amplify.fragment.OnboardingFragment;
import com.tekhnical.amplify.util.PreferencesUtils;

public class OnboadingActivity extends AppCompatActivity implements OnboardingListener {

    private ViewPager2 onBoardingPager;
    private LinearLayout parentLayout, nextBtn;
    private DotsIndicator pagerIndicator;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_onboading);
        parentLayout = findViewById(R.id.parent);
        onBoardingPager = findViewById(R.id.onboading_pager);
        pagerIndicator = findViewById(R.id.pager_indicator);
        nextBtn = findViewById(R.id.next_button);

        String[] titles = {"Amplify","Track","Notifications"};
        String[] descs = {"Amplify is a simple tracking application designed to track your favorite currency pairs in one place",
                "Easily track and manage your crypto portfolio, get insights and market data from over 300+ exchanges",
                "Enable notifications to see asset and stock price from over 100 exchanges right from your lock screen."};
        int[] icons = {R.drawable.intro1,R.drawable.intro2,R.drawable.intro3};

        //onBoardingPager.setUserInputEnabled(false);
        onBoardingPager.setAdapter(new FragmentStateAdapter(this) {
            @NonNull
            @Override
            public Fragment createFragment(int position) {
                return OnboardingFragment.newInstance(position,titles[position],descs[position],icons[position]);
            }

            @Override
            public int getItemCount() {
                return 3;
            }
        });
        onBoardingPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                if(position == 0){
                    parentLayout.setBackgroundResource(R.drawable.intro_back1);
                }
                else if(position == 1){
                    parentLayout.setBackgroundResource(R.drawable.intro_back2);
                }
                else if(position == 2){
                    parentLayout.setBackgroundResource(R.drawable.intro_back3);
                    PreferencesUtils.setUserHint(OnboadingActivity.this,true);
                }
            }
        });
        pagerIndicator.setViewPager2(onBoardingPager);
        onBoardingPager.setPageTransformer(new VerticalFlipTransformation());
        parentLayout.setBackgroundResource(R.drawable.intro_back1);
        onBoardingPager.setCurrentItem(0);
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeView(onBoardingPager.getCurrentItem()+1);
            }
        });
    }

    @Override
    public void changeView(int index) {
        if (index == 3){
            startActivity(new Intent(this,CheckersListActivity.class));
        }else {
            onBoardingPager.setCurrentItem(index);
        }
    }

    public class DepthTransformation implements ViewPager2.PageTransformer{
        @Override
        public void transformPage(View page, float position) {

            if (position < -1){    // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0){    // [-1,0]
                page.setAlpha(1);
                page.setTranslationX(0);
                page.setScaleX(1);
                page.setScaleY(1);

            }
            else if (position <= 1){    // (0,1]
                page.setTranslationX(-position*page.getWidth());
                page.setAlpha(1-Math.abs(position));
                page.setScaleX(1-Math.abs(position));
                page.setScaleY(1-Math.abs(position));

            }
            else {    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
        }
    }
    class HingeAnimation implements ViewPager2.PageTransformer{
        @Override
        public void transformPage(@NonNull View page, float position) {
            page.setTranslationX(-position*page.getWidth());
            page.setPivotX(0);
            page.setPivotY(0);

            if (position < -1){
                page.setAlpha(0);
            }
            else if(position <= 0){
                page.setRotation(90*Math.abs(position));
                page.setAlpha(1-Math.abs(position));
            }
            else if (position <= 1){
                page.setRotation(0);
                page.setAlpha(1);
            }
            else{
                page.setAlpha(0);
            }
        }
    }
    public class VerticalFlipTransformation implements ViewPager2.PageTransformer {
        @Override
        public void transformPage(View page, float position) {

            page.setTranslationX(-position * page.getWidth());
            page.setCameraDistance(12000);

            if (position < 0.5 && position > -0.5) {
                page.setVisibility(View.VISIBLE);
            } else {
                page.setVisibility(View.INVISIBLE);
            }
            if (position < -1){     // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0) {    // [-1,0]
                page.setAlpha(1);
                page.setRotationY(180 *(1-Math.abs(position)+1));

            }
            else if (position <= 1) {    // (0,1]
                page.setAlpha(1);
                page.setRotationY(-180 *(1-Math.abs(position)+1));

            }
            else {    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
        }
    }
    public class HorizontalFlipTransformation implements ViewPager2.PageTransformer {
        @Override
        public void transformPage(View page, float position) {

            page.setTranslationX(-position*page.getWidth());
            page.setCameraDistance(20000);

            if (position < 0.5 && position > -0.5){
                page.setVisibility(View.VISIBLE);
            }
            else {
                page.setVisibility(View.INVISIBLE);
            }
            if (position < -1){     // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0 ){    // [-1,0]
                page.setAlpha(1);
                page.setRotationX(180*(1-Math.abs(position)+1));

            }
            else if (position <= 1){    // (0,1]
                page.setAlpha(1);
                page.setRotationX(-180*(1-Math.abs(position)+1));

            }
            else {    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
        }
    }
    public class PopTransformation implements ViewPager2.PageTransformer {
        @Override
        public void transformPage(View page, float position) {

            page.setTranslationX(-position * page.getWidth());

            if (Math.abs(position) < 0.5) {
                page.setVisibility(View.VISIBLE);
                page.setScaleX(1 - Math.abs(position));
                page.setScaleY(1 - Math.abs(position));
            } else if (Math.abs(position) > 0.5) {
                page.setVisibility(View.GONE);
            }


        }
    }
    public class FadeOutTransformation implements ViewPager2.PageTransformer{
        @Override
        public void transformPage(View page, float position) {

            page.setTranslationX(-position*page.getWidth());

            page.setAlpha(1-Math.abs(position));
        }
    }
    public class CubeOutRotationTransformation implements ViewPager2.PageTransformer {
        @Override
        public void transformPage(View page, float position) {

            if (position < -1){    // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0) {    // [-1,0]
                page.setAlpha(1);
                page.setPivotX(page.getWidth());
                page.setRotationY(-90 * Math.abs(position));

            }
            else if (position <= 1){    // (0,1]
                page.setAlpha(1);
                page.setPivotX(0);
                page.setRotationY(90 * Math.abs(position));

            }
            else {    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
        }
    }
    public class CubeInRotationTransformation implements ViewPager2.PageTransformer{
        @Override
        public void transformPage(View page, float position) {

            page.setCameraDistance(20000);


            if (position < -1){     // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0){    // [-1,0]
                page.setAlpha(1);
                page.setPivotX(page.getWidth());
                page.setRotationY(90*Math.abs(position));

            }
            else if (position <= 1){    // (0,1]
                page.setAlpha(1);
                page.setPivotX(0);
                page.setRotationY(-90*Math.abs(position));

            }
            else{    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
        }
    }
    public class CubeOutScalingTransformation implements ViewPager2.PageTransformer{
        @Override
        public void transformPage(View page, float position) {

            if (position < -1){    // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0) {    // [-1,0]
                page.setAlpha(1);
                page.setPivotX(page.getWidth());
                page.setRotationY(-90 * Math.abs(position));

            }
            else if (position <= 1){    // (0,1]
                page.setAlpha(1);
                page.setPivotX(0);
                page.setRotationY(90 * Math.abs(position));

            }
            else {    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }

            if (Math.abs(position) <= 0.5){
                page.setScaleY(Math.max(0.4f,1-Math.abs(position)));
            }
            else if (Math.abs(position) <= 1){
                page.setScaleY(Math.max(0.4f,Math.abs(position)));
            }
        }
    }
    public class CubeInScalingTransformation implements ViewPager2.PageTransformer {
        @Override
        public void transformPage(View page, float position) {
            page.setCameraDistance(20000);


            if (position < -1){     // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0){    // [-1,0]
                page.setAlpha(1);
                page.setPivotX(page.getWidth());
                page.setRotationY(90*Math.abs(position));

            }
            else if (position <= 1){    // (0,1]
                page.setAlpha(1);
                page.setPivotX(0);
                page.setRotationY(-90*Math.abs(position));

            }
            else{    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }

            if (Math.abs(position) <= 0.5){
                page.setScaleY(Math.max(.4f,1-Math.abs(position)));
            }
            else if (Math.abs(position) <= 1){
                page.setScaleY(Math.max(.4f,Math.abs(position)));

            }


        }
    }
    public class CubeOutDepthTransformation implements ViewPager2.PageTransformer {
        @Override
        public void transformPage(View page, float position) {

            if (position < -1){    // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0) {    // [-1,0]
                page.setAlpha(1);
                page.setPivotX(page.getWidth());
                page.setRotationY(-90 * Math.abs(position));

            }
            else if (position <= 1){    // (0,1]
                page.setAlpha(1);
                page.setPivotX(0);
                page.setRotationY(90 * Math.abs(position));

            }
            else {    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
            if (Math.abs(position) <= 0.5){
                page.setScaleY(Math.max(0.4f,1-Math.abs(position)));
            }
            else if (Math.abs(position) <= 1){
                page.setScaleY(Math.max(0.4f,1-Math.abs(position)));
            }
        }
    }
    public class CubeInDepthTransformation implements ViewPager2.PageTransformer {
        @Override
        public void transformPage(View page, float position) {
            page.setCameraDistance(20000);


            if (position < -1){
                page.setAlpha(0);
            }
            else if (position <= 0){
                page.setAlpha(1);
                page.setPivotX(page.getWidth());
                page.setRotationY(90*Math.abs(position));
            }
            else if (position <= 1){
                page.setAlpha(1);
                page.setPivotX(0);
                page.setRotationY(-90*Math.abs(position));
            }
            else{
                page.setAlpha(0);
            }

            if (Math.abs(position) <= 0.5){
                page.setScaleY(Math.max(.4f,1-Math.abs(position)));
            }
            else if (Math.abs(position) <= 1){
                page.setScaleY(Math.max(.4f,1-Math.abs(position)));

            }


        }
    }
    public class ZoomOutTransformation implements ViewPager2.PageTransformer {

        private static final float MIN_SCALE = 0.65f;
        private static final float MIN_ALPHA = 0.3f;

        @Override
        public void transformPage(View page, float position) {

            if (position <-1){  // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <=1){ // [-1,1]

                page.setScaleX(Math.max(MIN_SCALE,1-Math.abs(position)));
                page.setScaleY(Math.max(MIN_SCALE,1-Math.abs(position)));
                page.setAlpha(Math.max(MIN_ALPHA,1-Math.abs(position)));

            }
            else {  // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
        }
    }
    public class Clock_SpinTransformation implements ViewPager2.PageTransformer {
        @Override
        public void transformPage(View page, float position) {

            page.setTranslationX(-position * page.getWidth());

            if (Math.abs(position) <= 0.5) {
                page.setVisibility(View.VISIBLE);
                page.setScaleX(1 - Math.abs(position));
                page.setScaleY(1 - Math.abs(position));
            } else if (Math.abs(position) > 0.5) {
                page.setVisibility(View.GONE);
            }


            if (position < -1){  // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0) {   // [-1,0]
                page.setAlpha(1);
                page.setRotation(360 * Math.abs(position));

            }
            else if (position <= 1) {   // (0,1]
                page.setAlpha(1);
                page.setRotation(-360 * Math.abs(position));

            }
            else {  // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
        }
    }
    public class AntiClockSpinTransformation implements ViewPager2.PageTransformer {
        @Override
        public void transformPage(View page, float position) {

            page.setTranslationX(-position * page.getWidth());

            if (Math.abs(position) < 0.5){
                page.setVisibility(View.VISIBLE);
                page.setScaleX(1-Math.abs(position));
                page.setScaleY(1-Math.abs(position));
            }
            else if (Math.abs(position) > 0.5){
                page.setVisibility(View.GONE);
            }

            if (position < -1){  // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0){    // [-1,0]
                page.setAlpha(1);
                page.setRotation(360*(1-Math.abs(position)));

            }
            else if (position <= 1){    // (0,1]
                page.setAlpha(1);
                page.setRotation(-360*(1-Math.abs(position)));

            }
            else {  // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
        }
    }
    public class FidgetSpinTransformation implements ViewPager2.PageTransformer {
        @Override
        public void transformPage(View page, float position) {

            page.setTranslationX(-position * page.getWidth());

            if (Math.abs(position) < 0.5) {
                page.setVisibility(View.VISIBLE);
                page.setScaleX(1 - Math.abs(position));
                page.setScaleY(1 - Math.abs(position));
            } else if (Math.abs(position) > 0.5) {
                page.setVisibility(View.GONE);
            }



            if (position < -1){     // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0) {    // [-1,0]
                page.setAlpha(1);
                page.setRotation(36000*(Math.abs(position)*Math.abs(position)*Math.abs(position)*Math.abs(position)*Math.abs(position)*Math.abs(position)*Math.abs(position)));

            }else if (position <= 1){    // (0,1]
                page.setAlpha(1);
                page.setRotation(-36000 *(Math.abs(position)*Math.abs(position)*Math.abs(position)*Math.abs(position)*Math.abs(position)*Math.abs(position)*Math.abs(position)));

            }
            else {    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
        }
    }
    public class GateTransformation implements ViewPager2.PageTransformer{

        private String TAG  = "GateAnimationn";
        @Override
        public void transformPage(View page, float position) {

            page.setTranslationX(-position*page.getWidth());

            if (position<-1){    // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position<=0){    // [-1,0]
                page.setAlpha(1);
                page.setPivotX(0);
                page.setRotationY(90*Math.abs(position));

            }
            else if (position <=1){    // (0,1]
                page.setAlpha(1);
                page.setPivotX(page.getWidth());
                page.setRotationY(-90*Math.abs(position));

            }else {    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
        }
    }
    public class TossTransformation implements ViewPager2.PageTransformer {
        @Override
        public void transformPage(View page, float position) {

            page.setTranslationX(-position * page.getWidth());
            page.setCameraDistance(20000);


            if (position < 0.5 && position > -0.5) {
                page.setVisibility(View.VISIBLE);

            } else {
                page.setVisibility(View.INVISIBLE);

            }


            if (position < -1) {     // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0) {    // [-1,0]
                page.setAlpha(1);
                page.setScaleX(Math.max(0.4f, (1 - Math.abs(position))));
                page.setScaleY(Math.max(0.4f, (1 - Math.abs(position))));
                page.setRotationX(1080 * (1 - Math.abs(position) + 1));
                page.setTranslationY(-1000*Math.abs(position));

            }
            else if (position <= 1) {    // (0,1]
                page.setAlpha(1);
                page.setScaleX(Math.max(0.4f, (1-Math.abs(position))));
                page.setScaleY(Math.max(0.4f, (1-Math.abs(position))));
                page.setRotationX(-1080 * (1 - Math.abs(position) + 1));
                page.setTranslationY(-1000*Math.abs(position));

            }
            else {    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
        }
    }
    public class FanTransformation implements ViewPager2.PageTransformer{
        @Override
        public void transformPage(View page, float position) {

            page.setTranslationX(-position*page.getWidth());
            page.setPivotX(0);
            page.setPivotY(page.getHeight()/2);
            page.setCameraDistance(20000);

            if (position < -1){     // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0){    // [-1,0]
                page.setAlpha(1);
                page.setRotationY(-120*Math.abs(position));
            }
            else if (position <= 1){    // (0,1]
                page.setAlpha(1);
                page.setRotationY(120*Math.abs(position));

            }
            else {    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
        }
    }
    public class SpinnerTransformation implements ViewPager2.PageTransformer {
        @Override
        public void transformPage(View page, float position) {

            page.setTranslationX(-position * page.getWidth());
            page.setCameraDistance(12000);

            if (position < 0.5 && position > -0.5) {
                page.setVisibility(View.VISIBLE);
            } else {
                page.setVisibility(View.INVISIBLE);
            }



            if (position < -1){     // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0) {    // [-1,0]
                page.setAlpha(1);
                page.setRotationY(900 *(1-Math.abs(position)+1));

            }
            else if (position <= 1) {    // (0,1]
                page.setAlpha(1);
                page.setRotationY(-900 *(1-Math.abs(position)+1));

            }
            else {    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
        }
    }
    public class VerticalShutTransformation implements ViewPager2.PageTransformer{
        @Override
        public void transformPage(View page, float position) {

            page.setTranslationX(-position*page.getWidth());
            page.setCameraDistance(999999999);

            if (position < 0.5 && position > -0.5){
                page.setVisibility(View.VISIBLE);
            }
            else {
                page.setVisibility(View.INVISIBLE);
            }

            if (position < -1){     // [-Infinity,-1)
                // This page is way off-screen to the left.
                page.setAlpha(0);

            }
            else if (position <= 0 ){    // [-1,0]
                page.setAlpha(1);
                page.setRotationX(180*(1-Math.abs(position)+1));

            }
            else if (position <= 1){    // (0,1]
                page.setAlpha(1);
                page.setRotationX(-180*(1-Math.abs(position)+1));

            }
            else {    // (1,+Infinity]
                // This page is way off-screen to the right.
                page.setAlpha(0);

            }
        }
    }
}