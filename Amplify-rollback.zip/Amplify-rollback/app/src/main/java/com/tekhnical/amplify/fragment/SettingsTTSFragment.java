package com.tekhnical.amplify.fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

//import androidx.preference.ListPreference;
//import androidx.preference.Preference;
//import androidx.preference.PreferenceFragment;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.preference.ListPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.market.Bitstamp;
import com.tekhnical.amplify.model.CurrencySubunit;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.CurrencyUtils;
import com.tekhnical.amplify.util.FormatUtils;
import com.tekhnical.amplify.util.TTSHelper;
import com.tekhnical.amplify.util.Utils;

public class SettingsTTSFragment extends PreferenceFragmentCompat implements OnSharedPreferenceChangeListener {
    private final String currencyDst = Currency.USD;
    private final String currencySrc = VirtualCurrency.BTC;
    private Preference formatExamplePreference;
    private final double lastPrice = 712.67d;
    private final Market market = new Bitstamp();
    private final CurrencySubunit subunitDst = CurrencyUtils.getCurrencySubunit(Currency.USD, 1);

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);
        //view.setBackgroundColor(getResources().getColor(R.color.background));
        return view;
    }
    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.settings_tts,rootKey);
        findPreference(getString(R.string.settings_tts_configure_key)).setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                try {
                    Intent intent = new Intent();
                    intent.setAction("com.android.settings.TTS_SETTINGS");
                    intent.setFlags(268435456);
                    SettingsTTSFragment.this.getActivity().startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return true;
            }
        });
        this.formatExamplePreference = findPreference(getString(R.string.settings_tts_format_example_key));
        String currencyString = getString(R.string.generic_currency_pair, VirtualCurrency.BTC, Currency.USD);
        this.formatExamplePreference.setTitle(getString(R.string.settings_tts_format_example_title, currencyString, this.market.name));
        this.formatExamplePreference.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            public boolean onPreferenceClick(Preference preference) {
                TTSHelper.speak(SettingsTTSFragment.this.getActivity(), FormatUtils.formatTextForTTS(SettingsTTSFragment.this.getActivity(), 712.67d, VirtualCurrency.BTC, 0, false, SettingsTTSFragment.this.subunitDst, false, SettingsTTSFragment.this.market, SettingsTTSFragment.this.market.ttsName, false));
                return true;
            }
        });
        final ListPreference advancedStreamPreference = (ListPreference) findPreference(getString(R.string.settings_tts_advanced_stream_key));
        if (advancedStreamPreference!=null) {
            //advancedStreamPreference.setSummary(advancedStreamPreference.getEntry());
            advancedStreamPreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
                public boolean onPreferenceChange(Preference preference, Object newValue) {
                    return Utils.handleIntListOnPreferenceChange(advancedStreamPreference, newValue);
                }
            });
        }
    }

    public void onStart() {
        super.onStart();
        getPreferenceManager().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
        refreshFormatExamplePreference();
    }

    public void onStop() {
        super.onStop();
        try {
            getPreferenceManager().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        if (getString(R.string.settings_tts_format_speak_base_currency_key).equals(key) || getString(R.string.settings_tts_format_integer_only_key).equals(key) || getString(R.string.settings_tts_format_speak_counter_currency_key).equals(key) || getString(R.string.settings_tts_format_speak_exchange_key).equals(key)) {
            refreshFormatExamplePreference();
        }
    }

    private void refreshFormatExamplePreference() {
        this.formatExamplePreference.setSummary(FormatUtils.formatTextForTTS(getActivity(), 712.67d, VirtualCurrency.BTC, 0, false, this.subunitDst, false, this.market, this.market.name, false));
    }
}
