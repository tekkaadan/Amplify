package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class HitBtc extends Market {
    private static final String NAME = "HitBTC";
    private static final String TTS_NAME = "Hit BTC";
    private static final String URL = "https://api.hitbtc.com/api/1/public/%1$s/ticker";
    private static final String URL_CURRENCY_PAIRS = "https://api.hitbtc.com/api/1/public/symbols";

    public HitBtc() {
        super("hitbtc",NAME, TTS_NAME, null);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/HitBTC.png";
        //return "https://assets.coingecko.com/markets/images/24/small/hitbtc.png";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.hitbtc;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "bid");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "ask");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "volume");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last");
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray symbolsJsonArray = jsonObject.getJSONArray("symbols");
        for (int i = 0; i < symbolsJsonArray.length(); i++) {
            JSONObject pairJsonObject = symbolsJsonArray.getJSONObject(i);
            String currencyBase = pairJsonObject.getString("commodity");
            String currencyCounter = pairJsonObject.getString("currency");
            String currencyPairId = pairJsonObject.getString("symbol");
            if (!(currencyBase == null || currencyCounter == null || currencyPairId == null)) {
                pairs.add(new CurrencyPairInfo(currencyBase, currencyCounter, currencyPairId));
            }
        }
    }
}
