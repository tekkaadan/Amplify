package com.tekhnical.amplify.util;

import com.tekhnical.amplify.config.MarketsConfig;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.ConnectionSpec;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {
    public static final String BASE_URL = MarketsConfig.STOCKAPI;

    public static Retrofit getAppClient(){

        /*Interceptor headerAuthorizationInterceptor = new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Request request = chain.request();
                if (token!=null) {
                    Headers headers = request.headers().newBuilder().add("Authorization", token).build();
                    request = request.newBuilder().headers(headers).build();
                }
                return chain.proceed(request);
            }
        };*/
        List<ConnectionSpec> specs = new ArrayList<>();
        specs.add(ConnectionSpec.MODERN_TLS);
        specs.add(ConnectionSpec.CLEARTEXT);
        OkHttpClient mOkHttpClient = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(5, TimeUnit.MINUTES)
                .writeTimeout(5, TimeUnit.MINUTES)
                .connectionSpecs(specs)
                .build();

        Retrofit mRetrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(mOkHttpClient)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return mRetrofit;
    }
}
