package com.tekhnical.amplify.model;

import com.google.gson.annotations.SerializedName;

public class StockQuote {

    @SerializedName("symbol")
    private String symbol;
    @SerializedName("companyName")
    private String companyName;
    @SerializedName("primaryExchange")
    private String primaryExchange;
    @SerializedName("calculationPrice")
    private String calculationPrice;
    @SerializedName("open")
    private double open;
    @SerializedName("openTime")
    private long openTime;
    @SerializedName("openSource")
    private String openSource;

    @SerializedName("close")
    private double close;
    @SerializedName("closeTime")
    private long closeTime;
    @SerializedName("closeSource")
    private String closeSource;

    @SerializedName("high")
    private double high;
    @SerializedName("highTime")
    private long highTime;
    @SerializedName("highSource")
    private String highSource;

    @SerializedName("low")
    private double low;
    @SerializedName("lowTime")
    private long lowTime;
    @SerializedName("lowSource")
    private String lowSource;

    @SerializedName("latestPrice")
    private double price;
    @SerializedName("latestTime")
    private String latestTime;
    @SerializedName("latestUpdate")
    private String latestUpdate;
    @SerializedName("latestSource")
    private String latestSource;
    @SerializedName("latestVolume")
    private long latestVolume;
    @SerializedName("iexMarketPercent")
    private long iexMarketPercent;
    @SerializedName("iexVolume")
    private long iexVolume;
    @SerializedName("avgTotalVolume")
    private long avgTotalVolume;

    @SerializedName("extendedPrice")
    private double extendedPrice;
    @SerializedName("extendedChange")
    private double extendedChange;
    @SerializedName("extendedChangePercent")
    private double extendedChangePercent;
    @SerializedName("extendedPriceTime")
    private long extendedPriceTime;

    @SerializedName("previousClose")
    private double previousClose;
    @SerializedName("previousVolume")
    private double previousVolume;

    @SerializedName("change")
    private double change;
    @SerializedName("changePercent")
    private double changePercent;

    @SerializedName("volume")
    private long volume;

    @SerializedName("iexRealtimePrice")
    private double iexRealtimePrice;
    @SerializedName("iexLastUpdated")
    private double iexLastUpdated;

    @SerializedName("marketCap")
    private long marketCap;
    @SerializedName("peRatio")
    private double peRatio;
    @SerializedName("week52High")
    private double week52High;
    @SerializedName("week52Low")
    private double week52Low;
    @SerializedName("ytdChange")
    private double ytdChange;
    @SerializedName("lastTradeTime")
    private long lastTradeTime;
    @SerializedName("isUSMarketOpen")
    private boolean isUSMarketOpen;

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getPrimaryExchange() {
        return primaryExchange;
    }

    public void setPrimaryExchange(String primaryExchange) {
        this.primaryExchange = primaryExchange;
    }

    public String getCalculationPrice() {
        return calculationPrice;
    }

    public void setCalculationPrice(String calculationPrice) {
        this.calculationPrice = calculationPrice;
    }

    public double getOpen() {
        return open;
    }

    public void setOpen(double open) {
        this.open = open;
    }

    public long getOpenTime() {
        return openTime;
    }

    public void setOpenTime(long openTime) {
        this.openTime = openTime;
    }

    public String getOpenSource() {
        return openSource;
    }

    public void setOpenSource(String openSource) {
        this.openSource = openSource;
    }

    public double getClose() {
        return close;
    }

    public void setClose(double close) {
        this.close = close;
    }

    public long getCloseTime() {
        return closeTime;
    }

    public void setCloseTime(long closeTime) {
        this.closeTime = closeTime;
    }

    public String getCloseSource() {
        return closeSource;
    }

    public void setCloseSource(String closeSource) {
        this.closeSource = closeSource;
    }

    public double getHigh() {
        return high;
    }

    public void setHigh(double high) {
        this.high = high;
    }

    public long getHighTime() {
        return highTime;
    }

    public void setHighTime(long highTime) {
        this.highTime = highTime;
    }

    public String getHighSource() {
        return highSource;
    }

    public void setHighSource(String highSource) {
        this.highSource = highSource;
    }

    public double getLow() {
        return low;
    }

    public void setLow(double low) {
        this.low = low;
    }

    public long getLowTime() {
        return lowTime;
    }

    public void setLowTime(long lowTime) {
        this.lowTime = lowTime;
    }

    public String getLowSource() {
        return lowSource;
    }

    public void setLowSource(String lowSource) {
        this.lowSource = lowSource;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getLatestTime() {
        return latestTime;
    }

    public void setLatestTime(String latestTime) {
        this.latestTime = latestTime;
    }

    public String getLatestUpdate() {
        return latestUpdate;
    }

    public void setLatestUpdate(String latestUpdate) {
        this.latestUpdate = latestUpdate;
    }

    public String getLatestSource() {
        return latestSource;
    }

    public void setLatestSource(String latestSource) {
        this.latestSource = latestSource;
    }

    public long getLatestVolume() {
        return latestVolume;
    }

    public void setLatestVolume(long latestVolume) {
        this.latestVolume = latestVolume;
    }

    public long getIexMarketPercent() {
        return iexMarketPercent;
    }

    public void setIexMarketPercent(long iexMarketPercent) {
        this.iexMarketPercent = iexMarketPercent;
    }

    public long getIexVolume() {
        return iexVolume;
    }

    public void setIexVolume(long iexVolume) {
        this.iexVolume = iexVolume;
    }

    public long getAvgTotalVolume() {
        return avgTotalVolume;
    }

    public void setAvgTotalVolume(long avgTotalVolume) {
        this.avgTotalVolume = avgTotalVolume;
    }

    public double getExtendedPrice() {
        return extendedPrice;
    }

    public void setExtendedPrice(double extendedPrice) {
        this.extendedPrice = extendedPrice;
    }

    public double getExtendedChange() {
        return extendedChange;
    }

    public void setExtendedChange(double extendedChange) {
        this.extendedChange = extendedChange;
    }

    public double getExtendedChangePercent() {
        return extendedChangePercent;
    }

    public void setExtendedChangePercent(double extendedChangePercent) {
        this.extendedChangePercent = extendedChangePercent;
    }

    public long getExtendedPriceTime() {
        return extendedPriceTime;
    }

    public void setExtendedPriceTime(long extendedPriceTime) {
        this.extendedPriceTime = extendedPriceTime;
    }

    public double getPreviousClose() {
        return previousClose;
    }

    public void setPreviousClose(double previousClose) {
        this.previousClose = previousClose;
    }

    public double getPreviousVolume() {
        return previousVolume;
    }

    public void setPreviousVolume(double previousVolume) {
        this.previousVolume = previousVolume;
    }

    public double getChange() {
        return change;
    }

    public void setChange(double change) {
        this.change = change;
    }

    public double getChangePercent() {
        return changePercent;
    }

    public void setChangePercent(double changePercent) {
        this.changePercent = changePercent;
    }

    public long getVolume() {
        return volume;
    }

    public void setVolume(long volume) {
        this.volume = volume;
    }

    public double getIexRealtimePrice() {
        return iexRealtimePrice;
    }

    public void setIexRealtimePrice(double iexRealtimePrice) {
        this.iexRealtimePrice = iexRealtimePrice;
    }

    public double getIexLastUpdated() {
        return iexLastUpdated;
    }

    public void setIexLastUpdated(double iexLastUpdated) {
        this.iexLastUpdated = iexLastUpdated;
    }

    public long getMarketCap() {
        return marketCap;
    }

    public void setMarketCap(long marketCap) {
        this.marketCap = marketCap;
    }

    public double getPeRatio() {
        return peRatio;
    }

    public void setPeRatio(double peRatio) {
        this.peRatio = peRatio;
    }

    public double getWeek52High() {
        return week52High;
    }

    public void setWeek52High(double week52High) {
        this.week52High = week52High;
    }

    public double getWeek52Low() {
        return week52Low;
    }

    public void setWeek52Low(double week52Low) {
        this.week52Low = week52Low;
    }

    public double getYtdChange() {
        return ytdChange;
    }

    public void setYtdChange(double ytdChange) {
        this.ytdChange = ytdChange;
    }

    public long getLastTradeTime() {
        return lastTradeTime;
    }

    public void setLastTradeTime(long lastTradeTime) {
        this.lastTradeTime = lastTradeTime;
    }

    public boolean isUSMarketOpen() {
        return isUSMarketOpen;
    }

    public void setUSMarketOpen(boolean USMarketOpen) {
        isUSMarketOpen = USMarketOpen;
    }
}
