package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Coinbase extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Coinbase";
    private static final String TTS_NAME = "Coinbase";
    private static final String URL1 = "https://api.pro.coinbase.com/products/%1$s/ticker";
    private static final String URL2 = "https://api.pro.coinbase.com/products/%1$s/stats";
    private static final String CURRENCIES_URL = "https://api.pro.coinbase.com/products";


    public Coinbase() {
        super("coinbase",NAME, TTS_NAME, null);
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Coinbase.png";
        //return "https://assets.coingecko.com/markets/images/23/small/fe290a14-ac8f-4c90-9aed-5e72abf271f0.jpeg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.coinbase;
    }
    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }
    public int getNumOfRequests(CheckerInfo checkerRecord) {
        return 2;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        if (requestId == 0) {
            return String.format(URL1, new Object[]{checkerInfo.getCurrencyPairId()});
        }
        return String.format(URL2, new Object[]{checkerInfo.getCurrencyPairId()});
    }


    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        if (requestId == 0) {
            ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "bid");
            ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "ask");
            ticker.last = ParseUtils.getDoubleFromString(jsonObject, "price");
            ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "volume");
        }else{
            ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
            ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
        }
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i=0;i<jsonArray.length();i++){
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("id")){
                pairs.add(new CurrencyPairInfo(jsonObject.getString("base_currency"),jsonObject.getString("quote_currency"),jsonObject.getString("id")));
            }
        }
    }
}
