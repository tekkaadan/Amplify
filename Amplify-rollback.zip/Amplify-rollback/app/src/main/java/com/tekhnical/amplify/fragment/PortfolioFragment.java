package com.tekhnical.amplify.fragment;

import android.content.ContentProviderOperation;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.text.TextPaint;
import android.util.Log;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.google.gson.Gson;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.adapter.CheckersListAdapter;
import com.tekhnical.amplify.adapter.PortfolioAdapter;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.content.MaindbContentProvider;
import com.tekhnical.amplify.content.MaindbContract;
import com.tekhnical.amplify.content.MaindbOpenHelper;
import com.tekhnical.amplify.fragment.generic.ActionModeListFragment;
import com.tekhnical.amplify.receiver.MarketChecker;
import com.tekhnical.amplify.util.FormatUtils;
import com.tekhnical.amplify.util.NotificationUtils;
import com.tekhnical.amplify.util.PreferencesUtils;

import java.util.ArrayList;
import java.util.Arrays;

public class PortfolioFragment extends ActionModeListFragment<Cursor> implements LoaderManager.LoaderCallbacks<Cursor> {

    private PortfolioAdapter adapter;
    private AsyncTask<ArrayList<ContentProviderOperation>, Void, Void> dragAndDropUpateTask;
    private SwipeRefreshLayout mPullToRefreshLayout;
    private TextView portfolioAmountTv;
    private Runnable refreshAllCompleteRunnable = new Runnable() {
        public void run() {
            if (PortfolioFragment.this.getActivity() != null && PortfolioFragment.this.mPullToRefreshLayout != null) {
                PortfolioFragment.this.mPullToRefreshLayout.setRefreshing(false);
            }
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_portfolio, container, false);
        setHasOptionsMenu(true);
        view.findViewById(R.id.empty_id).setId(0x00ff0001);
        view.findViewById(R.id.progress_container_id).setId(0x00ff0002);
        view.findViewById(R.id.list_container_id).setId(0x00ff0003);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setHasOptionsMenu(true);
        portfolioAmountTv = view.findViewById(R.id.portfolio_amount_tv);

        this.mPullToRefreshLayout = view.findViewById(R.id.swipe_refresh_view);
        this.mPullToRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if(mPullToRefreshLayout!=null)
                    mPullToRefreshLayout.setRefreshing(true);
                onRefreshStarted(null);
            }
        });
        setPortfolio("0$");
        this.adapter = new PortfolioAdapter(getActivity());
        setListAdapter(this.adapter);
        setListShownNoAnimation(false);
        setEmptyText(getString(R.string.checkers_list_empty_text));
        TextView emptyView = (TextView) getListView().getEmptyView();
        emptyView.setTextColor(getResources().getColor(R.color.list_divider));
        getListView().setDividerHeight(0);
        getListView().setDivider(null);
        getListView().setSelector(R.drawable.list_selector_background_transition_holo_light);
        enableActionModeOrContextMenu();
        getLoaderManager().restartLoader(0, null, this);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    private void setPortfolio(String amount){
        TextPaint paint = portfolioAmountTv.getPaint();
        float width = paint.measureText(amount);

        Shader textShader = new LinearGradient(0, 0, width, portfolioAmountTv.getLineHeight(),
                Color.parseColor("#FF9250"),
                Color.parseColor("#FF2F88"), Shader.TileMode.REPEAT);
        portfolioAmountTv.getPaint().setShader(textShader);
        portfolioAmountTv.setText(amount);
    }
    private void onRefreshStarted(View unused) {
        if (this.mPullToRefreshLayout != null && getActivity() != null) {
            MarketChecker.refreshAllEnabledCheckerRecords(getActivity());
            this.mPullToRefreshLayout.postDelayed(this.refreshAllCompleteRunnable, 2000);
        }
    }

    @Override
    public int getActionModeOrContextMenuResId() {
        return R.menu.checkers_list_fragment_cab;
    }

    @Override
    public void onActionModeItemsCheckedCountChanged(ActionMode mode, int checkedItemCount) {
        boolean z = true;
        MenuItem findItem = mode.getMenu().findItem(R.id.editItem);
        if (checkedItemCount != 1) {
            z = false;
        }
        findItem.setVisible(z);
        super.onActionModeItemsCheckedCountChanged(mode, checkedItemCount);
    }

    @Override
    public boolean onActionModeOrContextMenuItemClicked(int menuItemId, Cursor checkedItem, int listItemPosition, int checkedItemsCount, boolean isForLastItem) {
        return super.onActionModeOrContextMenuItemClicked(menuItemId, checkedItem, listItemPosition, checkedItemsCount, isForLastItem);
    }

    @Override
    public void onActionModeActive(boolean active) {
        super.onActionModeActive(active);
        this.adapter.setActionModeActive(active);
    }

    private void setNewList(Cursor cursor) {
        if (getView() != null && getActivity() != null) {
            if (cursor != null) {
                if (cursor.getCount()>0){
                    double total = 0;
                    boolean check = false;
                    while (cursor.moveToNext()){
                        check = true;
                        CheckerRecord item = CheckerRecord.fromCursor(cursor);
                        Log.e("PORTFOLIO",DatabaseUtils.dumpCursorToString(cursor));
                        total = total +item.getSum();
                    }
                    if (total >0) {
                        setPortfolio(FormatUtils.formatPriceWithCurrency(total, "USD"));
                        NotificationUtils.showTotalPortfolioNotification(getContext());
                    }
                    else if (check)
                        setPortfolio(FormatUtils.formatPriceWithCurrency(0, "USD"));
                }
                cursor.moveToFirst();
                this.adapter.swapCursor(cursor);
            }
            setListShown(true);
        }
    }

    @NonNull
    @Override
    public Loader<Cursor> onCreateLoader(int arg0, Bundle arg1) {
        //return new MaindbContentProvider().getOpenHelper().getReadableDatabase().rawQuery("",null);
        return new CursorLoader(getActivity(), MaindbContract.Checker.CONTENT_URI,CheckerRecord.PROJECTION_PORTFOLIO,MaindbContract.CheckerColumns.HOLDINGS+ "!= '0' GROUP BY " + MaindbContract.CheckerColumns.CURRENCY_SRC,null,getSortOrderString(getActivity()));
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor data) {
        setNewList(data);
    }


    @Override
    public void onLoaderReset(@NonNull Loader<Cursor> loader) {
        setNewList(null);
    }

    public static String getSortOrderString(Context context) {
        switch (PreferencesUtils.getCheckersListSortMode(context)) {
            case 1:
                return "currencySrc ASC, currencyDst ASC, marketKey ASC";
            case 2:
                return "marketKey ASC, currencySrc ASC, currencyDst ASC";
            default:
                return "sortOrder ASC";
        }
    }

}