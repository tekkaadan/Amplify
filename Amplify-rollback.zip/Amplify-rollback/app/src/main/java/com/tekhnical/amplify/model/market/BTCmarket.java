package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class BTCmarket extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "BTCMarket";
    private static final String TTS_NAME = "BTC Markets";
    private static final String URL = "https://api.btcmarkets.net/v3/markets/%1$s/ticker";
    private static final String CURRENCIES_URL = "https://api.btcmarkets.net/v3/markets";

    public BTCmarket() {
        super("btcmarkets", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/btcmarkets.jpg";
        //return "https://assets.coingecko.com/markets/images/237/small/btcmarkets-exchange.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.btcmarkets;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {

        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "lastPrice");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high24h");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low24h");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "volume");
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "bestBid");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "bestAsk");

    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("marketId")){
                pairs.add(new CurrencyPairInfo(jsonObject.getString("baseAssetName"),jsonObject.getString("quoteAssetName"),jsonObject.getString("marketId")));
            }
        }
    }


}
