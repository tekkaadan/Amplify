package com.tekhnical.amplify.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.media.AudioManager;
import android.media.AudioManager.OnAudioFocusChangeListener;
import android.os.Build.VERSION;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.speech.tts.TextToSpeech.OnUtteranceCompletedListener;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;
import java.util.HashMap;
import java.util.Locale;

public class TTSHelper {
    private static final Object LOCK = new Object();
    static final OnAudioFocusChangeListener afChangeListener = new OnAudioFocusChangeListener() {
        public void onAudioFocusChange(int focusChange) {
            if (focusChange != -2 && focusChange != 1 && focusChange == -1) {
                TTSHelper.onDoneSpeaking();
            }
        }
    };
    private static AudioManager audioManager;
    private static Locale defaultLanguageLocale;
    private static String textToBeSpoken;
    private static TextToSpeech tts = null;

    public static void initTTS(Context context, OnInitListener onInitListener) {
        if (tts == null) {
            tts = new TextToSpeech(context.getApplicationContext(), onInitListener);
        } else {
            onInitListener.onInit(0);
        }
    }

    public static void speak(Context context, String text) {
        synchronized (LOCK) {
            final Context appContext = context.getApplicationContext();
            if (!PreferencesUtils.getTTSDisplayOffOnly(appContext) || !((PowerManager) appContext.getSystemService(Context.POWER_SERVICE)).isScreenOn()) {
                try {
                    if (!PreferencesUtils.getTTSHeadphonesOnly(appContext) || isHeadsetConnected(appContext)) {
                        textToBeSpoken = text;
                        if (tts == null) {
                            tts = new TextToSpeech(appContext, new OnInitListener() {
                                public void onInit(int status) {
                                    if (TTSHelper.isStatusSuccess(status)) {
                                        TTSHelper.defaultLanguageLocale = TTSHelper.tts.getLanguage();
                                        TTSHelper.speakAfterInit(appContext, TTSHelper.textToBeSpoken);
                                        return;
                                    }
                                    Log.d("TTS", "Initilization Failed!");
                                    TTSHelper.defaultLanguageLocale = null;
                                    TTSHelper.tts = null;
                                }
                            });
                        } else {
                            speakAfterInit(appContext, textToBeSpoken);
                        }
                        return;
                    }
                    return;
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            } else {
                return;
            }
        }
    }

    public static boolean isStatusSuccess(int status) {
        return status == 0;
    }

    private static boolean setLanguageAndCheck(Locale locale) {
        int result = tts.setLanguage(locale);
        return (result == -1 || result == -2) ? false : true;
    }

    private static void speakAfterInit(Context appContext, String text) {
        if (tts != null) {
            try {
                audioManager = (AudioManager) appContext.getSystemService("audio");
                if (!setLanguageAndCheck(Locale.ENGLISH)) {
                    Log.d("TTS", "ENGLISH language is not supported, setting default instead.");
                    if (defaultLanguageLocale == null || !setLanguageAndCheck(defaultLanguageLocale)) {
                        Log.d("TTS", "Error while setting default language!");
                        return;
                    }
                }
                int streamId = getProperAudioStream(appContext);
                int requestAudioFocus = audioManager.requestAudioFocus(afChangeListener, streamId, 3);
                setTTSListeners();
                HashMap<String, String> myHashParams = new HashMap<>();
                myHashParams.put("utteranceId", "DONE");
                myHashParams.put("streamType", String.valueOf(streamId));
                tts.speak(text, 1, myHashParams);
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }
    }

    @TargetApi(15)
    private static void setTTSListeners() {
        if (VERSION.SDK_INT < 15) {
            tts.setOnUtteranceCompletedListener(new OnUtteranceCompletedListener() {
                public void onUtteranceCompleted(String utteranceId) {
                    TTSHelper.onDoneSpeaking();
                }
            });
        } else if (tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            public void onStart(String utteranceId) {
            }

            public void onError(String utteranceId) {
                TTSHelper.onDoneSpeaking();
            }

            public void onDone(String utteranceId) {
                TTSHelper.onDoneSpeaking();
            }
        }) != 0) {
            onDoneSpeaking();
        }
    }

    public static void stopSpeaking() {
        if (tts != null) {
            tts.stop();
        }
    }

    private static void onDoneSpeaking() {
        if (audioManager != null) {
            audioManager.abandonAudioFocus(afChangeListener);
        }
    }

    public static int getProperAudioStream(Context context) {
        if (isHeadsetConnected(context)) {
            return 3;
        }
        return PreferencesUtils.getTTSAdvancedStream(context);
    }

    public static boolean isHeadsetConnected(Context appContext) {
        AudioManager audioManager2 = (AudioManager) appContext.getSystemService("audio");
        return audioManager2.isWiredHeadsetOn() || audioManager2.isBluetoothA2dpOn();
    }
}
