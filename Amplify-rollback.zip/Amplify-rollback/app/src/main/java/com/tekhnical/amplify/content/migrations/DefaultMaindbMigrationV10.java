package com.tekhnical.amplify.content.migrations;

import android.database.sqlite.SQLiteDatabase;
import com.robotoworks.mechanoid.db.SQLiteMigration;

/* renamed from: com.tekhnical.amplify.db.content.migrations.DefaultMaindbMigrationV10 */
public class DefaultMaindbMigrationV10 extends SQLiteMigration {
    public void onBeforeUp(SQLiteDatabase db) {
    }

    @Override
    public void up(SQLiteDatabase db) {
        db.execSQL("update checker set currencySrc = 'DSH' WHERE marketKey = 'Bitfinex' and currencySrc = 'DASH'");
    }

    public void onAfterUp(SQLiteDatabase db) {
    }
}
