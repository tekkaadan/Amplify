package com.tekhnical.amplify.config;

public class Settings {
    public static String userCountry;
}
