package com.tekhnical.amplify.adapter;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.text.Html;
import android.text.TextUtils;
import android.text.style.RelativeSizeSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.CheckBox;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import butterknife.ButterKnife;
import butterknife.BindView;

import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.crashlytics.FirebaseCrashlytics;
import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.content.MaindbContract;
import com.tekhnical.amplify.model.CurrencySubunit;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.StockMarket;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.content.AlarmRecord;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.util.AlarmRecordHelper;
import com.tekhnical.amplify.util.CheckerRecordHelper;
import com.tekhnical.amplify.util.CurrencyUtils;
import com.tekhnical.amplify.util.FormatUtils;
import com.tekhnical.amplify.util.FormatUtilsBase;
import com.tekhnical.amplify.util.MarketsConfigUtils;
import com.tekhnical.amplify.util.SpannableUtils;
import com.tekhnical.amplify.util.TickerUtils;
import com.tekhnical.amplify.util.Utils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class CheckersListAdapter extends CursorAdapter {
    private final boolean darkTheme;
    private boolean actionModeActive;
    private final Context context;
    private OnItemClickListener itemClickListener;

    static class ViewHolder {
        @BindView(R.id.item_parent)
        LinearLayout parent;
        @BindView(R.id.list_item_iv)
        LinearLayout iconBack;
        @BindView(R.id.exchange_icon)
        ImageView exchangeIcon;
        @BindView(R.id.market_icon)
        ImageView marketIcon;
        @BindView(R.id.currencyView)
        TextView currencyView;
        @BindView(R.id.lastCheckTimeView)
        TextView lastCheckTimeView;
        @BindView(R.id.lastCheckValueView)
        TextView lastCheckValueView;
        @BindView(R.id.lastCheckView)
        TextView lastCheckView;
        @BindView(R.id.marketView)
        TextView marketView;
        @BindView(R.id.alarmView)
        TextView alarmView;
        @BindView(R.id.bid_value_tv)
        TextView bidTv;
        @BindView(R.id.ask_value_tv)
        TextView askTv;
        @BindView(R.id.ch_value_tv)
        TextView chTv;
        @BindView(R.id.high_value_tv)
        TextView highTv;
        @BindView(R.id.low_value_tv)
        TextView lowTv;
        @BindView(R.id.vol_value_tv)
        TextView volTv;
        @BindView(R.id.checker_cb)
        CheckBox checkerCb;

        public ViewHolder(View view) {
            ButterKnife.bind((Object) this, view);
        }
    }

    public CheckersListAdapter(Context context, OnItemClickListener listener) {
        super(context, (Cursor) null, false);
        itemClickListener = listener;
        this.context = context;
        this.darkTheme = MyApplication.getInstance().isNightModeEnabled();
    }

    public void setActionModeActive(boolean actionModeActive) {
        this.actionModeActive = actionModeActive;
        notifyDataSetChanged();
    }

    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        View view = LayoutInflater.from(this.context).inflate(R.layout.checkers_futures_list_item, parent, false);
        view.setTag(new ViewHolder(view));
        return view;
    }

    public void bindView(View convertView, Context context, Cursor cursor) {
        try {
            int lastCheckValueViewVisibility;
            ViewHolder holder = (ViewHolder) convertView.getTag();
            final CheckerRecord item = CheckerRecord.fromCursor(cursor);
            CurrencySubunit subunitDst = CurrencyUtils.getCurrencySubunit(item.getCurrencyDst(), item.getCurrencySubunitDst());
            Market market = MarketsConfigUtils.getMarketByKey(item.getMarketKey());

            int position = cursor.getPosition();
            holder.marketView.setText(market.name);
            holder.currencyView.setText(context.getString(R.string.generic_currency_pair, new Object[]{FormatUtils.getCurrencySrcWithContractType(item.getCurrencySrc(), market, (int) item.getContractType()), item.getCurrencyDst()}));
            List<AlarmRecord> alarmRecords = CheckerRecordHelper.getAlarmsForCheckerRecord(item, true);
            if (alarmRecords == null || alarmRecords.size() == 0) {
                holder.alarmView.setText(context.getString(R.string.checkers_list_item_alarm, new Object[]{" " + context.getString(R.string.checkers_list_item_alarm_none)}));
            } else {
                String alarmString = "";
                for (AlarmRecord alarmRecord : alarmRecords) {
                    if (!TextUtils.isEmpty(alarmString)) {
                        alarmString = alarmString + ",  ";
                    }
                    String prefix = AlarmRecordHelper.getPrefixForAlarmType(item, alarmRecord);
                    String value = AlarmRecordHelper.getValueForAlarmType(subunitDst, alarmRecord);
                    String sufix = AlarmRecordHelper.getSufixForAlarmType(item, alarmRecord);
                    alarmString = alarmString + context.getString(R.string.checkers_list_item_alarm_value_format, new Object[]{prefix, value, sufix != null ? sufix : "$"});
                }
                holder.alarmView.setText(SpannableUtils.formatWithSpans(context.getString(R.string.checkers_list_item_alarm), " " + alarmString, new RelativeSizeSpan(1.00f)));
            }
            Ticker lastCheckTicker = TickerUtils.fromJson(item.getLastCheckTicker());
            if (item.getErrorMsg() != null) {
                holder.lastCheckView.setText(context.getString(R.string.check_error_generic_prefix, new Object[]{""}));
                holder.lastCheckValueView.setText(Html.fromHtml("<small>" + item.getErrorMsg() + "</small>"));
                holder.lastCheckValueView.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
                lastCheckValueViewVisibility = View.VISIBLE;
                holder.lastCheckTimeView.setText(FormatUtils.formatSameDayTimeOrDate(context, item.getLastCheckDate()));
            } else if (lastCheckTicker != null) {
                holder.lastCheckView.setText(R.string.checkers_list_item_last_check);
                holder.lastCheckValueView.setText(" " + FormatUtils.formatPriceWithCurrency(lastCheckTicker.last, subunitDst));
                //holder.lastCheckValueView.setCompoundDrawablesWithIntrinsicBounds(0, 0, NotificationUtils.getIconResIdForTickers(TickerUtils.fromJson(item.getPreviousCheckTicker()), lastCheckTicker, true), 0);
                lastCheckValueViewVisibility = View.VISIBLE;
                holder.askTv.setText(lastCheckTicker.ch1h != 0 ? FormatUtilsBase.formatDouble(lastCheckTicker.ch1h, false) + "%" : "N/A");
                holder.bidTv.setText(lastCheckTicker.ch1d != 0 ? FormatUtilsBase.formatDouble(lastCheckTicker.ch1d, false) + "%" : "N/A");
                holder.chTv.setText(lastCheckTicker.ch7d != 0 ? FormatUtilsBase.formatDouble(lastCheckTicker.ch7d, false) + "%" : "N/A");
                holder.highTv.setText(lastCheckTicker.mc != 0 ? FormatUtilsBase.formatLong(lastCheckTicker.mc) : "N/A");
                holder.lowTv.setText(lastCheckTicker.cs != 0 ? FormatUtilsBase.formatDouble(lastCheckTicker.cs, false) : "N/A");
                holder.volTv.setText(lastCheckTicker.vol > 0 ? "" + ((int) lastCheckTicker.vol) : "N/A");
                holder.lastCheckTimeView.setText(FormatUtils.formatSameDayTimeOrDate(context, lastCheckTicker.timestamp));
            } else {
                holder.lastCheckView.setText(R.string.checkers_list_item_last_check);
                holder.lastCheckValueView.setText(null);
                lastCheckValueViewVisibility = View.GONE;
            }
            if (market.getImageUrl() >= 0) {
                holder.marketIcon.setImageResource(market.getImageUrl());
                String iconName =  item.getCurrencySrc() != null ? "icon_" +item.getCurrencySrc().toLowerCase() : "";
                int resID = context.getResources().getIdentifier(iconName, "drawable", context.getPackageName());
                if (resID > 0)
                    holder.exchangeIcon.setImageResource(resID);
                else if (lastCheckTicker != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        holder.exchangeIcon.setImageTintList(null);
                    }
                    Glide.with(context).load(lastCheckTicker.icon).fitCenter().into(holder.exchangeIcon);
                }

            }
            //holder.lastCheckView.setVisibility(lastCheckValueViewVisibility);
            holder.lastCheckValueView.setVisibility(lastCheckValueViewVisibility);
            holder.lastCheckTimeView.setVisibility(lastCheckValueViewVisibility);
            holder.iconBack.setBackgroundResource(item.getEnabled() ? R.drawable.checker_enabled : R.drawable.checker_disabled);
            //holder.separator.setVisibility(lastCheckValueViewVisibility);
            holder.parent.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    Utils.vibrate(context);
                    itemClickListener.onItemLongClick(v, position);
                    return true;
                }
            });
            holder.parent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    itemClickListener.onItemClick(position);
                }
            });
            holder.checkerCb.setChecked(item.getEnabled());
            holder.checkerCb.setOnCheckedChangeListener((button, isChecked) -> {
                MaindbContract.Checker.newBuilder().setEnabled(isChecked).update(item.getId(), true);
                item.setEnabled(isChecked);
                CheckerRecordHelper.doAfterEdit(context, item, true);
            });
            if (this.actionModeActive) {
                holder.checkerCb.setEnabled(false);
            }
        } catch (Exception e) {
            e.printStackTrace();
            FirebaseCrashlytics.getInstance().recordException(e);
        }
    }

    public interface OnItemClickListener {
        public void onItemClick(int position);
        public void onItemEdit(int position, boolean enabled);
        public void onItemLongClick(View view, int position);
    }
}
