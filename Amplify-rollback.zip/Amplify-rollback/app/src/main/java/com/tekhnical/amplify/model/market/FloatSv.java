package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class FloatSv extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "FloatSv";
    private static final String TTS_NAME = "Float SV";
    private static final String URL = "https://www.floatsv.com/api/spot/v3/instruments/%1$s/ticker";
    private static final String CURRENCIES_URL = "https://www.floatsv.com/api/spot/v3/instruments";

    public FloatSv() {
        super("floatsv", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Floatsv.png";
        //return "https://assets.coingecko.com/markets/images/406/small/wCQAOb2o_400x400.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.floatsv;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDouble(jsonObject, "best_bid");
        ticker.ask = ParseUtils.getDouble(jsonObject, "best_ask");
        ticker.last = ParseUtils.getDouble(jsonObject, "last");
        ticker.high = ParseUtils.getDouble(jsonObject, "high_24h");
        ticker.low = ParseUtils.getDouble(jsonObject, "low_24h");
        ticker.vol = ParseUtils.getDouble(jsonObject, "base_volume_24h");

    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("instrument_id")){
                pairs.add(new CurrencyPairInfo(jsonObject.getString("base_currency"),jsonObject.getString("quote_currency"),jsonObject.getString("instrument_id")));
            }
        }
    }
}
