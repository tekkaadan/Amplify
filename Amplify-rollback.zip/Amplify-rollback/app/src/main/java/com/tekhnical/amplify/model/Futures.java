package com.tekhnical.amplify.model;

public class Futures {
    public static final int CONTRACT_TYPE_BIMONTHLY = 4;
    public static final int CONTRACT_TYPE_BIWEEKLY = 2;
    public static final int CONTRACT_TYPE_MONTHLY = 3;
    public static final int CONTRACT_TYPE_DAILY = 0;
    public static final int CONTRACT_TYPE_QUARTERLY = 5;
    public static final int CONTRACT_TYPE_BIARTERLY = 6;
    public static final int CONTRACT_TYPE_WEEKLY = 1;
    private static final String[] CONTRACT_TYPE_SHORT_NAMES = {"1D","1W", "2W", "1M", "2M", "3M"};

    public static String getContractTypeShortName(int contractType) {
        if (contractType < 0 || contractType >= CONTRACT_TYPE_SHORT_NAMES.length) {
            return null;
        }
        return CONTRACT_TYPE_SHORT_NAMES[contractType];
    }
}
