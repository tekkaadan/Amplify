package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class DragonEx extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Dragonex";
    private static final String TTS_NAME = "Dragonex";
    private static final String URL = "https://openapi.dragonex.io/api/v1/market/real/?symbol_id=%1$s";
    private static final String CURRENCIES_URL = "https://openapi.dragonex.io/api/v1/symbol/all/";

    public DragonEx() {
        super("dragonex", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/dragonex.jpg";
        //return "https://assets.coingecko.com/markets/images/297/small/S0rxMXWo_400x400.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.dragonex;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONArray("data").getJSONObject(0);
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "close_price");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "max_price");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "min_price");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "current_volume");
        if (jsonObject.has("timestamp"));
            ticker.timestamp = jsonObject.getLong("timestamp");
    }


    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = json.getJSONArray("data");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            String pair = jsonObject.getString("symbol");
            String[] splits = pair.split("_");
            if (splits.length>=2){
                list.add(new CurrencyPairInfo(splits[0].toUpperCase(),splits[1].toUpperCase(),jsonObject.getInt("symbol_id")+""));
            }
        }
    }
}
