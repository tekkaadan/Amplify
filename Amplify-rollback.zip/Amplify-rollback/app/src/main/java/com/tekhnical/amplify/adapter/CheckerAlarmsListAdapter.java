package com.tekhnical.amplify.adapter;

import android.annotation.TargetApi;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.FrameLayout;
import android.widget.TextView;
import butterknife.ButterKnife;
import butterknife.BindView;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.fragment.CheckerAddFragment;
import com.tekhnical.amplify.content.AlarmRecord;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.util.AlarmRecordHelper;
import com.nineoldandroids.view.ViewHelper;
import java.util.List;

public abstract class CheckerAlarmsListAdapter extends BaseAdapter {
    private static final float ALPHA_OFF = 0.1f;
    private static final float ALPHA_ON = 1.0f;
    private final CheckerAddFragment checkerAddFragment;
    private final CheckerRecord checkerRecord;
    private final Context context;
    private final List<AlarmRecord> items;
    private final int verticalPadding;

    static class ViewHolder {
        @BindView(R.id.alarmLedView)
        View alarmLedView;
        @BindView(R.id.alarmSoundView)
        View alarmSoundView;
        @BindView(R.id.alarmTtsView)
        View alarmTtsView;
        @BindView(R.id.alarmVibrateView)
        View alarmVibrateView;
        @BindView(R.id.alarmView)
        TextView alarmView;
        @BindView(R.id.checkBox)
        CompoundButton checkBox;
        @BindView(R.id.checkBoxWrapper)
        FrameLayout checkBoxWrapper;

        public ViewHolder(View view) {
            ButterKnife.bind((Object) this, view);
        }
    }

    public abstract void onItemLongClick(AlarmRecord alarmRecord, int i);

    public CheckerAlarmsListAdapter(Context context2, CheckerAddFragment checkerAddFragment2, CheckerRecord checkerRecord2, List<AlarmRecord> items2) {
        this.context = context2;
        this.checkerAddFragment = checkerAddFragment2;
        this.checkerRecord = checkerRecord2;
        this.items = items2;
        this.verticalPadding = context2.getResources().getDimensionPixelSize(R.dimen.list_item_vertical_padding_card);
    }

    public int getCount() {
        if (this.items == null || this.items.size() <= 1) {
            return 1;
        }
        return this.items.size() + 1;
    }

    public AlarmRecord getItem(int position) {
        if (position < 0 || position >= this.items.size()) {
            return null;
        }
        return (AlarmRecord) this.items.get(position);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public int getViewTypeCount() {
        return 2;
    }

    public int getItemViewType(int position) {
        return position == getCount() + -1 ? 1 : 0;
    }

    @TargetApi(11)
    public View getView(final int position, View convertView, ViewGroup parent) {
        int i;
        if (position == getCount() - 1) {
            View convertView2 = LayoutInflater.from(this.context).inflate(R.layout.checker_add_alarm_add_list_item, parent, false);
            TextView textView = (TextView) convertView2.findViewById(R.id.textView);
            if (getCount() == 1) {
                i = R.string.checker_add_alarm_list_add_alarm_more;
            } else {
                i = R.string.checker_add_alarm_list_add_alarm;
            }
            textView.setText(i);
            return convertView2;
        }
        if (convertView == null) {
            convertView = LayoutInflater.from(this.context).inflate(R.layout.checker_add_alarm_list_item, parent, false);
            convertView.setTag(new ViewHolder(convertView));
        }
        convertView.setPadding(convertView.getPaddingLeft(), (position == 0 ? 2 : 1) * this.verticalPadding, convertView.getPaddingRight(), convertView.getPaddingBottom());
        final AlarmRecord alarmRecord = getItem(position);
        if (alarmRecord != null) {
            final ViewHolder holder = (ViewHolder) convertView.getTag();
            String prefix = AlarmRecordHelper.getPrefixForAlarmType(this.checkerRecord, alarmRecord);
            String value = AlarmRecordHelper.getValueForAlarmType(this.checkerRecord, alarmRecord);
            String sufix = AlarmRecordHelper.getSufixForAlarmType(this.checkerRecord, alarmRecord);

            holder.alarmView.setText(this.context.getString(R.string.checker_add_alarm_type_value_format, new Object[]{prefix, value, sufix !=null ? sufix:"$"}));
            ViewHelper.setAlpha(holder.alarmSoundView, alarmRecord.getSound() ? 1.0f : ALPHA_OFF);
            ViewHelper.setAlpha(holder.alarmVibrateView, alarmRecord.getVibrate() ? 1.0f : ALPHA_OFF);
            ViewHelper.setAlpha(holder.alarmLedView, alarmRecord.getLed() ? 1.0f : ALPHA_OFF);
            ViewHelper.setAlpha(holder.alarmTtsView, alarmRecord.getTtsEnabled() ? 1.0f : ALPHA_OFF);
            holder.checkBox.setOnCheckedChangeListener(null);
            holder.checkBox.setChecked(alarmRecord.getEnabled());
            holder.checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    alarmRecord.setEnabled(isChecked);
                    CheckerAlarmsListAdapter.this.checkerAddFragment.makeUnsavedChanges();
                }
            });
            holder.checkBoxWrapper.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    holder.checkBox.toggle();
                }
            });
        }
        convertView.setOnLongClickListener(new OnLongClickListener() {
            public boolean onLongClick(View v) {
                CheckerAlarmsListAdapter.this.onItemLongClick(alarmRecord, position);
                return true;
            }
        });
        return convertView;
    }
}
