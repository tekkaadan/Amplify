package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class ZBG extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "ZBG";
    private static final String TTS_NAME = "ZBG";
    private static final String URL = "https://kline.zbg.com/api/data/v1/ticker?marketName=%1$s_%2$s";
    private static final String CURRENCIES_URL = "https://www.zbg.com/exchange/api/v1/common/symbols";

    public ZBG() {
        super("zbg", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyBase(),checkerInfo.getCurrencyCounter()});
    }

    @Override
    public int getImageUrl() {
        return R.drawable.zbg;
    }
    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/ZBG.png";
        //return "https://assets.coingecko.com/markets/images/256/small/zbg-exchange.jpg";
    }*/

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject json, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray dataObject = json.getJSONArray("datas");
        if (dataObject.length() > 0) {
            ticker.bid = Double.parseDouble(dataObject.getString(8));
            ticker.ask = Double.parseDouble(dataObject.getString(9));
            ticker.last = Double.parseDouble(dataObject.getString(1));
            ticker.low = Double.parseDouble(dataObject.getString(3));
            ticker.high = Double.parseDouble(dataObject.getString(2));
            ticker.vol = Double.parseDouble(dataObject.getString(4));
            ticker.timestamp = System.currentTimeMillis();
        }
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = jsonObject.getJSONArray("datas");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject pairObject = jsonArray.getJSONObject(i);
            if (pairObject.has("symbol")) {
                list.add(new CurrencyPairInfo(pairObject.getString("base-currency").toUpperCase(),pairObject.getString("quote-currency").toUpperCase(),pairObject.getString("symbol")));
            }
        }
    }

}
