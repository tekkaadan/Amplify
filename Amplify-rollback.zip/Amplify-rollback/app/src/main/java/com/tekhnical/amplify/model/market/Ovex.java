package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class Ovex extends Market {
    private static final String NAME = "Ovex";
    private static final String TTS_NAME = "Ovex";
    private static final String URL = "https://www.ovex.io/api/v2/tickers/%1$s";
    private static final String URL_CURRENCY_PAIRS = "https://www.ovex.io/api/v2/markets";

    public Ovex() {
        super("ovex",NAME, TTS_NAME, null);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    @Override
    public int getImageUrl() {
        return R.drawable.ovex;
    }
    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/OVEX.png";
        //return "https://assets.coingecko.com/markets/images/455/small/OVEX_dark_%281%29.png";
    }*/

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject resultJsonObject = jsonObject.getJSONObject("ticker");
        ticker.bid = ParseUtils.getDoubleFromString(resultJsonObject,"buy");
        ticker.ask = ParseUtils.getDoubleFromString(resultJsonObject,"sell");
        ticker.last = ParseUtils.getDoubleFromString(resultJsonObject,"last");
        ticker.low = ParseUtils.getDoubleFromString(resultJsonObject,"low");
        ticker.high = ParseUtils.getDoubleFromString(resultJsonObject,"high");
        ticker.vol = ParseUtils.getDoubleFromString(resultJsonObject,"volume");
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray resultJsonArray = new JSONArray(responseString);
        for (int i = 0; i < resultJsonArray.length(); i++) {
            JSONObject marketJsonObject = resultJsonArray.getJSONObject(i);
            if(marketJsonObject.has("name")) {
                pairs.add(new CurrencyPairInfo(marketJsonObject.getString("ask_unit"), marketJsonObject.getString("bid_unit"), marketJsonObject.getString("id")));
            }
        }
    }

}
