package com.tekhnical.amplify.receiver;

import android.content.Context;
import android.content.Intent;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class IntentManager {
    public static final String ACTION_CHECKPOINT_REFRESH = "com.tekhnical.amplify.receiver.action.checkpoint_refresh";

    public static void sendLocalBroadcast(Context context, String action) {
        LocalBroadcastManager.getInstance(context).sendBroadcast(new Intent(action));
    }
}
