package com.tekhnical.amplify.util;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore.Audio.Media;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class SoundFilesManager {
    public static final String AMPLIFY_DOWN_ALERT_FILENAME = "amplify_down_alert";
    public static final String AMPLIFY_UP_CHEERS_FILENAME = "amplify_up_cheers";

    public static void installRingtonesIfNeeded(Context context) {
        installRingtoneFileIfNeeded(context, AMPLIFY_UP_CHEERS_FILENAME, "Amplify Up Cheers");
        installRingtoneFileIfNeeded(context, AMPLIFY_DOWN_ALERT_FILENAME, "Amplify Down Alert");
    }

    private static void installRingtoneFileIfNeeded(Context context, String fileName, String ringtoneTitle) {
        File file = copyRingtoneFromResources(context, fileName);
        if (file != null) {
            Uri contentUri = Media.getContentUriForPath(file.getAbsolutePath());
            if (checkRingtoneUri(context, contentUri, file.getAbsolutePath()) == null) {
                try {
                    context.getContentResolver().insert(contentUri, createRingtoneDatabaseEntry(file, ringtoneTitle));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static File getRingtonesDir() {
        return new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/media/audio/notifications");
    }

    private static File getRingtonePath(File ringtonesDir, String fileName) {
        return new File(ringtonesDir, fileName + ".mp3");
    }

    private static File copyRingtoneFromResources(Context context, String fileName) {
        InputStream fis = null;
        OutputStream outputStream = null;
        try {
            File path = getRingtonesDir();
            if (!path.exists()) {
                path.mkdirs();
            }
            File f = getRingtonePath(path, fileName);
            if (f.exists()) {
                return f;
            }
            fis = context.getContentResolver().openAssetFileDescriptor(Uri.parse("android.resource://" + context.getPackageName() + "/raw/" + fileName), "r").createInputStream();
            if (fis == null) {
                return null;
            }
            OutputStream fos = new FileOutputStream(f);
            try {
                byte[] buf = new byte[1024];
                while (true) {
                    int len = fis.read(buf);
                    if (len <= 0) {
                        break;
                    }
                    fos.write(buf, 0, len);
                }
                outputStream = fos;
                fos.close();
                fis.close();
                return f;
            } catch (Exception e) {
                outputStream = fos;
                e.printStackTrace();
                outputStream.close();
                fis.close();
                return null;

            }
        } catch (Throwable e4) {
            e4.printStackTrace();
            return null;
        }
    }

    private static ContentValues createRingtoneDatabaseEntry(File f, String ringtoneTitle) {
        ContentValues values = new ContentValues();
        values.put("_data", f.getAbsolutePath());
        values.put("title", ringtoneTitle);
        values.put("_size", Long.valueOf(f.length()));
        values.put("mime_type", "audio/mp3");
        values.put("is_ringtone", Boolean.valueOf(false));
        values.put("is_notification", Boolean.valueOf(true));
        values.put("is_alarm", Boolean.valueOf(false));
        values.put("is_music", Boolean.valueOf(false));
        return values;
    }

    public static Uri getUriForRingtone(Context context, String fileName) {
        File file = getRingtonePath(getRingtonesDir(), fileName).getAbsoluteFile();
        return checkRingtoneUri(context, Media.getContentUriForPath(file.getAbsolutePath()), file.getAbsolutePath());
    }

    private static Uri checkRingtoneUri(Context context, Uri contentUri, String filePath) {
        Uri uri = null;
        Cursor cursor = context.getContentResolver().query(contentUri, new String[]{"_id"}, "_data='" + filePath + "'", null, null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                uri = Uri.withAppendedPath(contentUri, String.valueOf(cursor.getInt(0)));
            }
            cursor.close();
        }
        return uri;
    }
}
