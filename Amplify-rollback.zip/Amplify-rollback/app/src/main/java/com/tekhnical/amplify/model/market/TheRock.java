package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class TheRock extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "therocktrading";
    private static final String TTS_NAME = "The Rock";
    private static final String URL = "https://api.therocktrading.com/v1/funds/%1$s/ticker";
    private static final String URL_CURRENCY_PAIRS = "https://api.therocktrading.com/v1/funds";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{Currency.EUR, Currency.USD, VirtualCurrency.XRP});
        CURRENCY_PAIRS.put(Currency.EUR, new String[]{VirtualCurrency.DOGE, VirtualCurrency.XRP});
        CURRENCY_PAIRS.put(VirtualCurrency.LTC, new String[]{VirtualCurrency.BTC, Currency.EUR, Currency.USD});
        CURRENCY_PAIRS.put(VirtualCurrency.NMC, new String[]{VirtualCurrency.BTC});
        CURRENCY_PAIRS.put(VirtualCurrency.PPC, new String[]{Currency.EUR});
        CURRENCY_PAIRS.put(Currency.USD, new String[]{VirtualCurrency.XRP});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/TheRockTrading.png";
        //return "https://assets.coingecko.com/markets/images/42/small/rocktrading.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.therocktrading;
    }
    public TheRock() {
        super("therocktrading",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        String pairId = checkerInfo.getCurrencyPairId();
        if (pairId == null) {
            pairId = fixCurrency(checkerInfo.getCurrencyBase()) + fixCurrency(checkerInfo.getCurrencyCounter());
        }
        return String.format(URL, new Object[]{pairId});
    }

    private String fixCurrency(String currency) {
        if (VirtualCurrency.DOGE.equals(currency)) {
            return VirtualCurrency.DOG;
        }
        return currency;
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDouble(jsonObject,"bid");
        ticker.ask = ParseUtils.getDouble(jsonObject,"ask");
        ticker.vol = ParseUtils.getDouble(jsonObject,"volume");
        ticker.high = ParseUtils.getDouble(jsonObject,"high");
        ticker.low = ParseUtils.getDouble(jsonObject,"low");
        ticker.last = ParseUtils.getDouble(jsonObject,"last");
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray fundsJsonArray = jsonObject.getJSONArray("funds");
        for (int i = 0; i < fundsJsonArray.length(); i++) {
            JSONObject pairJsonObject = fundsJsonArray.getJSONObject(i);
            if(pairJsonObject.has("id") && pairJsonObject.has("trade_currency") && pairJsonObject.has("base_currency"))
                pairs.add(new CurrencyPairInfo(pairJsonObject.getString("trade_currency"), pairJsonObject.getString("base_currency"), pairJsonObject.getString("id")));
        }
    }
}
