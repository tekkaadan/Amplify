package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class Dexblue extends Market {
    private static final String NAME = "Dexblue";
    private static final String TTS_NAME = "Dex Blue";
    private static final String URL = "https://api.dex.blue/rest/v1/market/%1$s/ticker";
    private static final String URL_CURRENCY_PAIRS = "https://api.dex.blue/rest/v1/listed";

    public Dexblue() {
        super("dexblue",NAME, TTS_NAME, null);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject resultJsonObject = jsonObject.getJSONObject("data");
        ticker.last = ParseUtils.getDoubleFromString(resultJsonObject,"rate");
        ticker.low = ParseUtils.getDoubleFromString(resultJsonObject,"low24h");
        ticker.high = ParseUtils.getDoubleFromString(resultJsonObject,"high24h");
        ticker.vol = ParseUtils.getDoubleFromString(resultJsonObject,"volumeTraded24h");
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONObject marketsObject = jsonObject.getJSONObject("data").getJSONObject("markets");
        JSONArray resultJsonArray = marketsObject.names();
        for (int i = 0; i < resultJsonArray.length(); i++) {
            JSONObject marketJsonObject = marketsObject.getJSONObject(resultJsonArray.getString(i));
            list.add(new CurrencyPairInfo(marketJsonObject.getString("traded"), marketJsonObject.getString("quote"), resultJsonArray.getString(i)));

        }
    }

}
