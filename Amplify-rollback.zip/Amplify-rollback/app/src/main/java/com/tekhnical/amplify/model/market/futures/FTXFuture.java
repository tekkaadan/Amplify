package com.tekhnical.amplify.model.market.futures;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.FuturesMarket;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class FTXFuture extends FuturesMarket {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    public static final String ID = "ftx_futures";
    private static final String NAME = "FTX Future";
    private static final String TTS_NAME = "FTX Future";
    private static final String URL = "https://ftx.com/api/futures/%1$s";
    private static final String CURRENCIES_URL = "https://ftx.com/api/futures";

    public FTXFuture() {
        super(ID, NAME, TTS_NAME, null, new int[]{4});
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo, int contractType) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    @Override
    public int getImageUrl() {
        return R.drawable.ftx_futures;
    }
    /*@Override
    public String getImageUrl() {
        //return "https://assets.coingecko.com/markets/images/443/small/FTX-exchange.png";
        return "file:///android_asset/logos/FTXFutures.png";
    }*/

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject json, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = json.getJSONObject("result");
        ticker.bid = ParseUtils.getDouble(jsonObject, "bid");
        ticker.ask = ParseUtils.getDouble(jsonObject, "ask");
        ticker.last = ParseUtils.getDouble(jsonObject, "last");
        ticker.high = ParseUtils.getDouble(jsonObject, "upperBound");
        ticker.low = ParseUtils.getDouble(jsonObject, "lowerBound");
        ticker.vol = ParseUtils.getDouble(jsonObject, "volume");
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = jsonObject.getJSONArray("result");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject pairObject = jsonArray.getJSONObject(i);
            if (pairObject.has("name")){
                String splits[] = null;
                if (pairObject.getString("name").contains("-"))
                    splits = pairObject.getString("name").split("-");
                else if (pairObject.getString("name").contains("/"))
                    splits = pairObject.getString("name").split("/");
                if (splits!=null && splits.length>=2)
                    list.add(new CurrencyPairInfo(splits[0],splits[1],pairObject.getString("name")));
            }
        }
    }

}
