package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Biki extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "BIKI";
    private static final String TTS_NAME = "BIKI";
    private static final String URL = "https://openapi.biki.cc/open/api/get_ticker?symbol=%1$s";
    private static final String CURRENCIES_URL = "https://openapi.biki.cc/open/api/common/symbols";

    public Biki() {
        super("biki", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        //return "https://assets.coingecko.com/markets/images/384/small/BiKi_icon.png";
        return "file:///android_asset/logos/BiKi.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.biki;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject("data");
        ticker.bid = ParseUtils.getDouble(jsonObject, "buy");
        ticker.ask = ParseUtils.getDouble(jsonObject, "sell");
        ticker.last = ParseUtils.getDouble(jsonObject, "last");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "vol");

    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = json.getJSONArray("data");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject pairObject = jsonArray.getJSONObject(i);
            if (pairObject.has("symbol"))
            list.add(new CurrencyPairInfo(pairObject.getString("base_coin"),pairObject.getString("count_coin"), pairObject.getString("symbol")));

        }
    }

}
