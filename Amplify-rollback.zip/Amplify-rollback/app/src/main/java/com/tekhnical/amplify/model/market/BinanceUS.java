package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

public class BinanceUS extends Market {
    private static final String[] COUNTER_CURRENCIES = {VirtualCurrency.BNB, VirtualCurrency.BTC, VirtualCurrency.ETH, VirtualCurrency.USDT, VirtualCurrency.BUSD, VirtualCurrency.AUD,VirtualCurrency.TRX,VirtualCurrency.ZAR};
    private static final String NAME = "BinanceUS";
    private static final String TTS_NAME = "BinanceUS";
    private static final String URL = "https://api.binance.us/api/v3/ticker/24hr?symbol=%1$s";
    private static final String URL_CURRENCY_PAIRS = "https://api.binance.us/api/v3/exchangeInfo";

    public BinanceUS() {
        super("binance_us",NAME, TTS_NAME, null);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/BinanceUS.png";
        //return "https://assets.coingecko.com/markets/images/469/small/Binance.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.binance_us;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject,"bidPrice");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject,"askPrice");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject,"volume");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject,"highPrice");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject,"lowPrice");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject,"lastPrice");
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray resultJsonArray = jsonObject.getJSONArray("symbols");
        for (int i = 0; i < resultJsonArray.length(); i++) {
            JSONObject tickerJson = resultJsonArray.getJSONObject(i);
            if (tickerJson.has("symbol")) {
                list.add(new CurrencyPairInfo(tickerJson.getString("baseAsset"),tickerJson.getString("quoteAsset"), tickerJson.getString("symbol")));
            }

        }
    }

}
