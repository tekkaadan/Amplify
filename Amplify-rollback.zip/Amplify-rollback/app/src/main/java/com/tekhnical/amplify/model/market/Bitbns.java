package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Bitbns extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Bitbns";
    private static final String TTS_NAME = "Bitbns";
    private static final String CURRENCIES_URL = "https://bitbns.com/order/fetchTickers";

    public Bitbns() {
        super("bitbns", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return CURRENCIES_URL;
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/BitBNS.png";
        //return "https://assets.coingecko.com/markets/images/541/small/HS7eNJdt_400x400.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.bitbns;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonOb, Ticker ticker, CheckerInfo checkerInfo) throws Exception {

        if (jsonOb.has(checkerInfo.getCurrencyPairId())) {
            JSONObject jsonObject = jsonOb.getJSONObject(checkerInfo.getCurrencyPairId());
            if (jsonObject.has("info"))
                ticker.last = ParseUtils.getDouble(jsonObject.getJSONObject("info"), "last_traded_price");
            ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
            ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
            ticker.bid = ParseUtils.getDouble(jsonObject, "bid");
            ticker.ask = ParseUtils.getDouble(jsonObject, "ask");
            ticker.vol = ParseUtils.getDouble(jsonObject, "baseVolume");
        }
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = jsonObject.names();
        for (int i=0;i<jsonArray.length();i++){
            String split[] = jsonArray.getString(i).split("/");
            if (split.length>=2)
                list.add(new CurrencyPairInfo(split[0],split[1],jsonArray.getString(i)));
        }
    }


}
