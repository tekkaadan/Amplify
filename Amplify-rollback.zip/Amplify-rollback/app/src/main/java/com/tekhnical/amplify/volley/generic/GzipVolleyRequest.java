package com.tekhnical.amplify.volley.generic;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.tekhnical.amplify.volley.UnknownVolleyError;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;

public abstract class GzipVolleyRequest<T> extends Request<T> {
    private static final int MAX_REDIRECTION_COUNT = 3;
    private final Map<String, String> headers;
    private final Listener<T> listener;
    private int redirectionCount;
    private String redirectionUrl = null;
    private RequestQueue requestQueue;

    public abstract T parseNetworkResponse(String str) throws Exception;

    public GzipVolleyRequest(String url, Listener<T> listener2, ErrorListener errorListener) {
        super(0, url, errorListener);
        this.listener = listener2;
        this.headers = new HashMap();
        this.headers.put("Accept-Encoding", "gzip");
        this.headers.put("User-Agent", "Amplify (gzip)");
    }

    public RequestQueue getRequestQueue() {
        return this.requestQueue;
    }

    public String getUrl() {
        if (this.redirectionUrl != null) {
            return this.redirectionUrl;
        }
        return super.getUrl();
    }

    public Map<String, String> getHeaders() throws AuthFailureError {
        return this.headers != null ? this.headers : super.getHeaders();
    }

    public Request<?> setRequestQueue(RequestQueue requestQueue2) {
        this.requestQueue = requestQueue2;
        return super.setRequestQueue(requestQueue2);
    }

    public void deliverError(VolleyError error) {
        if (!(error == null || error.networkResponse == null)) {
            int statusCode = error.networkResponse.statusCode;
            if (statusCode == 301 || statusCode == 302) {
                String location = (String) error.networkResponse.headers.get("Location");
                if (location != null && this.redirectionCount < 3) {
                    this.redirectionCount++;
                    this.redirectionUrl = location;
                    this.requestQueue.add(this);
                    return;
                }
            }
        }
        super.deliverError(error);
    }

    @Override
    public void deliverResponse(T response) {
        this.listener.onResponse(response);
    }

    @Override
    public Response<T> parseNetworkResponse(NetworkResponse response) {
        String responseString;
        String str = "";
        try {
            String encoding = (String) response.headers.get("Content-Encoding");
            if (encoding == null || !encoding.contains("gzip")) {
                responseString = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
            } else {
                responseString = decodeGZip(response.data);
            }
            return Response.success(parseNetworkResponse(responseString), HttpHeaderParser.parseCacheHeaders(response));
        } catch (Exception e) {
            e.printStackTrace();
            return Response.error(new ParseError((Throwable) e));
        } catch (Throwable e2) {
            e2.printStackTrace();
            return Response.error(new UnknownVolleyError(e2));
        }
    }

    private String decodeGZip(byte[] data) throws Exception {
        GZIPInputStream gzis;
        String responseString = "";
        try {
            ByteArrayInputStream bais2 = new ByteArrayInputStream(data);
            gzis = new GZIPInputStream(bais2);
            InputStreamReader reader2 = new InputStreamReader(gzis);
            BufferedReader in2 = new BufferedReader(reader2);
            while (true) {
                String readed = in2.readLine();
                if (readed == null) {
                    break;
                }
                responseString = responseString + readed + "\n";
            }
            if (bais2 != null) {
                bais2.close();
            }
            if (gzis != null) {
                gzis.close();
            }
            if (reader2 != null) {
                reader2.close();
            }
            if (in2 != null) {
                in2.close();
            }
            return responseString;

        }catch (Throwable th) {
            throw th;
        }

    }
}
