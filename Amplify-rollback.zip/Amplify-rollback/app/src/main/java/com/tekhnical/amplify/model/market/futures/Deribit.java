package com.tekhnical.amplify.model.market.futures;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.FuturesMarket;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class Deribit extends FuturesMarket {
    private static final int[] CONTRACT_TYPES = {0, 1, 3};
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    public static final String ID = "deribit";
    private static final String NAME = "Deribit";
    private static final String TTS_NAME = "Deribit";
    private static final String CURRENCIES_URL_BTC = "https://www.deribit.com/api/v2/public/get_instruments?currency=BTC";
    private static final String CURRENCIES_URL_ETH = "https://www.deribit.com/api/v2/public/get_instruments?currency=ETH";
    private static final String URL = "https://www.deribit.com/api/v2/public/ticker?instrument_name=%1$s";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{Currency.USD});
        CURRENCY_PAIRS.put(VirtualCurrency.ETH, new String[]{Currency.USD});
    }

    public Deribit() {
        super(ID,NAME, TTS_NAME, null, CONTRACT_TYPES);
    }

    @Override
    public int getImageUrl() {
        return R.drawable.deribit;
    }
    /*@Override
    public String getImageUrl() {
        //return "https://assets.coingecko.com/markets/images/402/small/deribit_logo_on_light_bg.png";
        return "file:///android_asset/logos/Deribit.png";
    }*/

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        if (requestId == 0)
            return CURRENCIES_URL_BTC;
        else
            return CURRENCIES_URL_ETH;
    }

    @Override
    public int getNumOfRequests(CheckerInfo checkerInfo) {
        return 2;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo, int contractType) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = jsonObject.getJSONArray("result");
        for (int i=0;i<jsonArray.length();i++){
            JSONObject pairObject = jsonArray.getJSONObject(i);
            list.add(new CurrencyPairInfo(pairObject.getString("base_currency"),pairObject.getString("quote_currency"),pairObject.getString("instrument_name")));
        }
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject tickerJsonObject = jsonObject.getJSONObject("result");
        ticker.bid = tickerJsonObject.getDouble("best_bid_price");
        ticker.ask = tickerJsonObject.getDouble("best_ask_price");
        ticker.last = tickerJsonObject.getDouble("last_price");
        ticker.high = tickerJsonObject.getDouble("max_price");
        ticker.low = tickerJsonObject.getDouble("min_price");
        if (tickerJsonObject.has("stats")) {
            ticker.vol = tickerJsonObject.getJSONObject("stats").getDouble("volume");
        }
        if (tickerJsonObject.has("timestamp"))
            ticker.timestamp = tickerJsonObject.getLong("timestamp");
    }
}
