package com.tekhnical.amplify.preferences;

import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.preference.DialogPreference;
import android.util.AttributeSet;
import android.view.View;
import android.widget.NumberPicker;

import com.tekhnical.amplify.R;

public class NumberPickerPreference extends DialogPreference {
    int initialValue;
    NumberPicker picker;
    int viewValue;

    private static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR = new Creator<SavedState>() {
            public SavedState createFromParcel(Parcel in) {
                return new SavedState(in);
            }

            public SavedState[] newArray(int size) {
                return new SavedState[size];
            }
        };
        int initialValue;
        int viewValue;

        public SavedState(Parcelable superState) {
            super(superState);
        }

        public SavedState(Parcel source) {
            super(source);
            this.initialValue = source.readInt();
            this.viewValue = source.readInt();
        }

        public void writeToParcel(Parcel dest, int flags) {
            super.writeToParcel(dest, flags);
            dest.writeInt(this.initialValue);
            dest.writeInt(this.viewValue);
        }
    }

    public NumberPickerPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
        setDialogLayoutResource(R.layout.number_picker_dialog);
        setPositiveButtonText(R.string.ok);
        setNegativeButtonText(R.string.cancel);
    }

    @Override
    public void onSetInitialValue(boolean restore, Object defaultValue) {
        setValue(restore ? getPersistedInt(1) : ((Integer) defaultValue).intValue());
    }

    @Override
    public Object onGetDefaultValue(TypedArray a, int index) {
        return Integer.valueOf(a.getInt(index, 1));
    }

    @Override
    public void onPrepareDialogBuilder(Builder builder) {
        //super.onPrepareDialogBuilder(builder);
        builder.setInverseBackgroundForced(true);
    }

    @Override
    public void onBindDialogView(View view) {
        super.onBindDialogView(view);
        this.picker = (NumberPicker) view.findViewById(R.id.pref_num_picker);
        if (this.viewValue == 0) {
            this.viewValue = this.initialValue;
        }
        this.picker.setMinValue(1);
        this.picker.setMaxValue(100);
        this.picker.setValue(this.viewValue);
    }

    @Override
    public void onDialogClosed(boolean positiveResult) {
        //super.onDialogClosed(positiveResult);
        if (positiveResult) {
            int value = this.picker.getValue();
            if (callChangeListener(Integer.valueOf(value))) {
                setValue(value);
                return;
            }
            return;
        }
        this.viewValue = 0;
    }

    public void setValue(int value) {
        this.viewValue = value;
        setSummary(value + "%");
        if (value != this.initialValue) {
            this.initialValue = value;
            persistInt(value);
            notifyChanged();
        }
    }

    @Override
    public Parcelable onSaveInstanceState() {
        SavedState myState = new SavedState(super.onSaveInstanceState());
        myState.initialValue = this.initialValue;
        if (this.picker != null) {
            myState.viewValue = this.picker.getValue();
        }
        return myState;
    }

    @Override
    public void onRestoreInstanceState(Parcelable state) {
        if (state == null || !state.getClass().equals(SavedState.class)) {
            super.onRestoreInstanceState(state);
            return;
        }
        SavedState myState = (SavedState) state;
        setValue(myState.initialValue);
        this.viewValue = myState.viewValue;
        super.onRestoreInstanceState(myState.getSuperState());
    }
}
