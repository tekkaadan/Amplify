package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Bitubu extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Bitubu";
    private static final String TTS_NAME = "Bitubu";
    private static final String URL = "https://api.bitubu.com/api/v2/tickers/%1$s";
    private static final String CURRENCIES_URL = "https://api.bitubu.com/api/v2/markets";

    public Bitubu() {
        super("bitubu", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }


    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Bitubu.png";
        //return "https://assets.coingecko.com/markets/images/508/small/7EcLqic7_400x400.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bitubu;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject("ticker");
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "buy");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "sell");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "volume");

    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("id")){
                pairs.add(new CurrencyPairInfo(jsonObject.getString("ask_unit").toUpperCase(),jsonObject.getString("bid_unit").toUpperCase(),jsonObject.getString("id")));
            }
        }
    }

}
