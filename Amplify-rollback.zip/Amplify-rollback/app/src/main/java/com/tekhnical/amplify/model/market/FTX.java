package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class FTX extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "FTX";
    private static final String TTS_NAME = "FTX";
    private static final String URL = "https://ftx.com/api/markets/%1$s";
    private static final String CURRENCIES_URL = "https://ftx.com/api/markets";

    public FTX() {
        super("ftx", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }


    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/FTX.png";
        //return "https://assets.coingecko.com/markets/images/451/small/FTX-exchange.png";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.ftx;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject json, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = json.getJSONObject("result");
        ticker.bid = ParseUtils.getDouble(jsonObject, "bid");
        ticker.ask = ParseUtils.getDouble(jsonObject, "ask");
        ticker.last = ParseUtils.getDouble(jsonObject, "last");
        ticker.vol = ParseUtils.getDouble(jsonObject, "volumeUsd24h");
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = jsonObject.getJSONArray("result");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject pairObject = jsonArray.getJSONObject(i);
            if (pairObject.has("type") && pairObject.getString("type").equalsIgnoreCase("spot")){
                list.add(new CurrencyPairInfo(pairObject.getString("baseCurrency"),pairObject.getString("quoteCurrency"),pairObject.getString("name")));
            }
        }
    }

}
