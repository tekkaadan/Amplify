package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class GmoJapan extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "GMO Japan";
    private static final String TTS_NAME = "GMO Japan";
    private static final String CURRENCIES_URL = "https://api.coin.z.com/public/v1/ticker";

    public GmoJapan() {
        super("gmojapan", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return CURRENCIES_URL;
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/GMOJapan.png";
        //return "https://assets.coingecko.com/markets/images/430/small/gmo_z_com.png";
    }
*/  @Override
    public int getImageUrl() {
        return R.drawable.gmojapan;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject json, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray jsonArray = json.getJSONArray("data");
        for (int i=0;i<jsonArray.length();i++){
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("symbol") && jsonObject.getString("symbol").equals(checkerInfo.getCurrencyPairId())) {
                ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last");
                ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
                ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
                ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "bid");
                ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "ask");
                ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "volume");
            }
        }
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = json.getJSONArray("data");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("symbol")){
                String splits[] = jsonObject.getString("symbol").split("_");
                if (splits.length>=2)
                    list.add(new CurrencyPairInfo(splits[0],splits[1],jsonObject.getString("symbol")));
            }
        }
    }


}
