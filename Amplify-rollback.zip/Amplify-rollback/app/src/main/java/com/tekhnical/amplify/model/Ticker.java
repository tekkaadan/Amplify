package com.tekhnical.amplify.model;

public class Ticker {
    public static final int NO_DATA = -1;
    public double ask = -1.0d;
    public double bid = -1.0d;
    public double high = -1.0d;
    public double last = -1.0d;
    public double low = -1.0d;
    public long timestamp = -1;
    public double vol = -1.0d;
    public double usd = -1.0d;
    public long mc = 0;
    public double cs = 0d;
    public double ch1h = 0d;
    public double ch1d = 0d;
    public double ch7d = 0d;
    public String icon = null;
}
