package com.tekhnical.amplify.fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import butterknife.ButterKnife;
import butterknife.BindView;

import com.android.volley.NetworkError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.elconfidencial.bubbleshowcase.BubbleShowCase;
import com.elconfidencial.bubbleshowcase.BubbleShowCaseBuilder;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.gson.Gson;
import com.linearlistview.LinearListView;
import com.linearlistview.LinearListView.OnItemClickListener;
import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.CheckerAddActivity;
import com.tekhnical.amplify.activity.CheckerAddAlarmActivity;
import com.tekhnical.amplify.activity.MarketPickerListActivity;
import com.tekhnical.amplify.activity.StockPickerListActivity;
import com.tekhnical.amplify.adapter.CheckerAlarmsListAdapter;
import com.tekhnical.amplify.dialog.CustomDialog;
import com.tekhnical.amplify.dialog.DynamicCurrencyPairsDialog;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencySubunit;
import com.tekhnical.amplify.model.CurrencySubunitsMap;
import com.tekhnical.amplify.model.ExchangeModel;
import com.tekhnical.amplify.model.FuturesMarket;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.StockMarket;
import com.tekhnical.amplify.model.StockSearchModel;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.CurrenciesSubunits;
import com.tekhnical.amplify.content.AlarmRecord;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.content.MaindbContract.Alarm;
import com.tekhnical.amplify.content.MaindbContract.Checker;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.receiver.MarketChecker;
import com.tekhnical.amplify.util.AlarmRecordHelper;
import com.tekhnical.amplify.util.AsyncTaskCompat;
import com.tekhnical.amplify.util.CheckErrorsUtils;
import com.tekhnical.amplify.util.CheckerRecordHelper;
import com.tekhnical.amplify.util.CurrencyPairsMapHelper;
import com.tekhnical.amplify.util.FormatUtils;
import com.tekhnical.amplify.util.HttpsHelper;
import com.tekhnical.amplify.util.MarketCurrencyPairsStore;
import com.tekhnical.amplify.util.MarketsConfigUtils;
import com.tekhnical.amplify.util.NotificationUtils;
import com.tekhnical.amplify.util.PreferencesUtils;
import com.tekhnical.amplify.util.Utils;
import com.tekhnical.amplify.view.ViewCurrencySpinnerPreference;
import com.tekhnical.amplify.view.generic.ViewFrequencyPickerPreference;
import com.tekhnical.amplify.view.generic.ViewFrequencyPickerPreference.OnFrequencySelectedListener;
import com.tekhnical.amplify.view.generic.ViewPreference;
import com.tekhnical.amplify.view.generic.ViewSpinnerPreference;
import com.tekhnical.amplify.view.generic.ViewSpinnerPreference.OnItemSelectedListener;
import com.tekhnical.amplify.view.generic.ViewTwoStatePreference;
import com.tekhnical.amplify.view.generic.ViewTwoStatePreference.OnCheckChangedListener;
import com.robotoworks.mechanoid.Mechanoid;
import com.robotoworks.mechanoid.db.SQuery;
import com.robotoworks.mechanoid.db.SQuery.Op;
import com.tekhnical.amplify.volley.CheckerTotalVolleyAsyncTask;
import com.tekhnical.amplify.volley.CheckerVolleyAsyncTask;
import com.tekhnical.amplify.volley.DynamicCurrencyPairsVolleyAsyncTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

public class CheckerAddFragment extends Fragment {
    private static final String EXTRA_ALARM_RECORDS = "alarm_records";
    private static final String EXTRA_REMOVED_ALARM_RECORD_IDS = "removed_alarm_record_ids";
    private static final String EXTRA_UNSAVED_CHANGES = "unsaved_changes";
    private static final int REQ_EDIT_ALARM = 200;
    private static final int REQ_MARKET_PICKER = 199;
    private static final int REQ_STOCK_PICKER = 198;

    private ArrayList<AlarmRecord> alarmRecords;
    private DynamicCurrencyPairsVolleyAsyncTask dynamicCurrencyPairsVolleyAsyncTask;
    private RequestQueue requestQueue;
    @BindView(R.id.checker_add_swiperefresh)
    SwipeRefreshLayout refreshLayout;
    @BindView(R.id.alarmSectionHeader)
    TextView alarmSectionHeader;
    @BindView(R.id.alarmSectionWrapper)
    View alarmSectionWrapper;
    private CheckerAlarmsListAdapter alarmsAdapter;
    @BindView(R.id.alarmsListView)
    LinearListView alarmsListView;
    @BindView(R.id.checkSectionWrapper)
    View checkSectionWrapper;
    @BindView(R.id.checkTTSView)
    ViewTwoStatePreference checkTTSView;
    private CheckerAddAlarmFragment checkerAddAlarmFragment;
    @BindView(R.id.checkerAddAlarmFragmentWrapper)
    View checkerAddAlarmFragmentWrapper;
    private CheckerRecord checkerRecord;
    @BindView(R.id.currencyDstSpinner)
    ViewCurrencySpinnerPreference currencyDstSpinner;
    @BindView(R.id.currencyDstSubunitSpinner)
    ViewCurrencySpinnerPreference currencyDstSubunitSpinner;
    private CurrencyPairsMapHelper currencyPairsMapHelper;
    @BindView(R.id.currencySpinnersAndDynamicPairsWrapper)
    View currencySpinnersAndDynamicPairsWrapper;
    @BindView(R.id.currencySpinnersWrapper)
    View currencySpinnersWrapper;
    @BindView(R.id.currencySrcSpinner)
    ViewCurrencySpinnerPreference currencySrcSpinner;
    @BindView(R.id.currencySrcSubunitSpinner)
    ViewCurrencySpinnerPreference currencySrcSubunitSpinner;
    @BindView(R.id.dynamicCurrencyPairsInfoView)
    View dynamicCurrencyPairsInfoView;
    @BindView(R.id.dynamicCurrencyPairsNoSyncYetView)
    View dynamicCurrencyPairsNoSyncYetView;
    @BindView(R.id.dynamicCurrencyPairsWarningView)
    View dynamicCurrencyPairsWarningView;
    //@BindView(R.id.enabledView)
    //MaterialButtonToggleGroup enabledView;
    @BindView(R.id.frequencySpinner)
    ViewFrequencyPickerPreference frequencySpinner;
    @BindView(R.id.futuresContractTypeSpinner)
    ViewCurrencySpinnerPreference futuresContractTypeSpinner;
    @BindView(R.id.marketCautionView)
    TextView marketCautionView;
    @BindView(R.id.marketSpinner)
    ViewPreference marketSpinner;
    @BindView(R.id.notificationPriorityView)
    ViewTwoStatePreference notificationPriorityView;
    private ArrayList<Long> removedAlarmRecordIds;
    @BindView(R.id.scrollView)
    NestedScrollView scrollView;
    @BindView(R.id.holdings_view)
    EditText holdingsView;
    @BindView(R.id.checker_chart_layout)
    LinearLayout checkerChartView;
    @BindView(R.id.checker_webview)
    WebView chckerWebview;
    private boolean unsavedChanges = false;

    public static final CheckerAddFragment newInstance(CheckerRecord checkerRecord2, long alarmRecordId) {
        CheckerAddFragment fragment = new CheckerAddFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable(CheckerAddActivity.EXTRA_CHECKER_RECORD, checkerRecord2);
        bundle.putLong(MarketChecker.EXTRA_ALARM_RECORD_ID, alarmRecordId);
        fragment.setArguments(bundle);
        return fragment;
    }

    public void onAttach(Activity activity) {
        super.onAttach(activity);
        setHasOptionsMenu(true);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.checker_add_fragment, container, false);
        requestQueue = HttpsHelper.newRequestQueue(getContext());
        ButterKnife.bind((Object) this, view);
        return view;
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (savedInstanceState != null) {
            this.checkerRecord = (CheckerRecord) savedInstanceState.getParcelable(CheckerAddActivity.EXTRA_CHECKER_RECORD);
            List<AlarmRecord> savedAlarmRecords = (List) savedInstanceState.getSerializable(EXTRA_ALARM_RECORDS);
            if (savedAlarmRecords != null) {
                this.alarmRecords = new ArrayList<>(savedAlarmRecords);
            }
            this.removedAlarmRecordIds = (ArrayList) savedInstanceState.getSerializable(EXTRA_REMOVED_ALARM_RECORD_IDS);
            this.unsavedChanges = savedInstanceState.getBoolean(EXTRA_UNSAVED_CHANGES);
        } else if (getArguments() != null) {
            this.checkerRecord = (CheckerRecord) getArguments().getParcelable(CheckerAddActivity.EXTRA_CHECKER_RECORD);
        }
        if (this.checkerRecord == null) {
            this.checkerRecord = new CheckerRecord();
            this.checkerRecord.setEnabled(true);
            this.checkerRecord.setMarketKey(PreferencesUtils.getMarketDefault(getActivity()));
            this.checkerRecord.setCurrencySubunitSrc(1);
            this.checkerRecord.setCurrencySubunitDst(1);
            this.checkerRecord.setFrequency(-1);
            this.checkerRecord.setFrequencyType(0);
            this.checkerRecord.setNotificationPriority(-2);
            this.checkerRecord.setTtsEnabled(false);
            this.checkerRecord.setSortOrder(Long.MAX_VALUE);
            this.checkerRecord.setHoldings("0");
            this.checkerRecord.setHoldingsAmount(0);
            this.checkerRecord.setMarketType(MyApplication.appMarketType);
            this.alarmRecords = new ArrayList<>();
            this.alarmRecords.add(AlarmRecordHelper.generateDefaultAlarmRecord(false));
        } else if (this.alarmRecords == null) {
            this.alarmRecords = new ArrayList<>(CheckerRecordHelper.getAlarmsForCheckerRecord(this.checkerRecord, false));
        }
        int theme = MyApplication.getAppTheme(getContext());
        if (theme == 3)
            alarmSectionWrapper.setBackgroundResource(R.drawable.dialog_button_gray);
        else if (theme == 4)
            alarmSectionWrapper.setBackgroundResource(R.drawable.dialog_button_sepia);
        else
            alarmSectionWrapper.setBackgroundResource(R.drawable.dialog_button_dark);
        NotificationUtils.clearAlarmNotificationForCheckerRecord(getActivity(), this.checkerRecord);
        if (this.removedAlarmRecordIds == null) {
            this.removedAlarmRecordIds = new ArrayList<>();
        }

        TextView titleView = ((AppCompatActivity) getActivity()).findViewById(R.id.appbar_title);
        titleView.setVisibility(View.VISIBLE);
        ((AppCompatActivity) getActivity()).findViewById(R.id.appbar_icon).setVisibility(View.GONE);
        titleView.setText(this.checkerRecord.getId() > 0 ? R.string.checker_add_title_edit : R.string.checker_add_title_new);
        this.checkerAddAlarmFragment = (CheckerAddAlarmFragment) getChildFragmentManager().findFragmentById(R.id.checkerAddAlarmFragment);
        this.alarmsAdapter = new CheckerAlarmsListAdapter(getActivity(), this, this.checkerRecord, this.alarmRecords) {
            public void onItemLongClick(AlarmRecord alarmRecord, final int position) {
                CustomDialog dialog = new CustomDialog(getContext());
                dialog.setMessage("Do you wants to delete?");
                dialog.setPositiveButton(getResources().getString(R.string.generic_delete), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        AlarmRecord removedAlarmRecord = (AlarmRecord) CheckerAddFragment.this.alarmRecords.remove(position);
                        if (removedAlarmRecord != null && removedAlarmRecord.getId() > 0) {
                            CheckerAddFragment.this.removedAlarmRecordIds.add(Long.valueOf(removedAlarmRecord.getId()));
                        }
                        CheckerAddFragment.this.unsavedChanges = true;
                        CheckerAddFragment.this.refreshAlarms();
                    }
                });
                dialog.setNegativeButton(getResources().getString(R.string.cancel), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        };
        this.alarmsListView.setAdapter(this.alarmsAdapter);
        this.alarmsListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(LinearListView parent, View view, int position, long id) {
                if (position >= CheckerAddFragment.this.alarmsAdapter.getCount() - 1) {
                    AlarmRecord newAlarmRecord = AlarmRecordHelper.generateDefaultAlarmRecord(true);
                    CheckerAddFragment.this.alarmRecords.add(newAlarmRecord);
                    CheckerAddFragment.this.unsavedChanges = true;
                    CheckerAddFragment.this.refreshAlarms();
                    CheckerAddAlarmActivity.startCheckerAddAlarmActivity(CheckerAddFragment.this, 200, CheckerAddFragment.this.checkerRecord, newAlarmRecord, CheckerAddFragment.this.alarmRecords.indexOf(newAlarmRecord));
                    return;
                }
                CheckerAddAlarmActivity.startCheckerAddAlarmActivity(CheckerAddFragment.this, 200, CheckerAddFragment.this.checkerRecord, (AlarmRecord) CheckerAddFragment.this.alarmRecords.get(position), position);
            }
        });
        //this.enabledView = getActivity().findViewById(R.id.enabledView);
        //this.enabledView.check(this.checkerRecord.getEnabled()? R.id.btn_on : R.id.btn_off);
        Utils.hideKeyboard(getContext(),this.holdingsView);
        if (this.checkerRecord.getHoldings()!=null) {
            if(this.checkerRecord.getHoldings().contains(","))
                this.holdingsView.setText(this.checkerRecord.getHoldings().substring(0,this.checkerRecord.getHoldings().indexOf(",")));
            else
                this.holdingsView.setText(this.checkerRecord.getHoldings());
        }
        /*this.enabledView.addOnButtonCheckedListener(new MaterialButtonToggleGroup.OnButtonCheckedListener() {
            @Override
            public void onButtonChecked(MaterialButtonToggleGroup group, int checkedId, boolean isChecked) {
                if(checkedId == R.id.btn_off){
                    CheckerAddFragment.this.checkerRecord.setEnabled(isChecked);
                    CheckerAddFragment.this.unsavedChanges = true;
                }else if(checkedId == R.id.btn_on){
                    CheckerAddFragment.this.checkerRecord.setEnabled(isChecked);
                    CheckerAddFragment.this.unsavedChanges = true;
                }
            }
        });*/
        this.refreshLayout.setEnabled(false);
        this.refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                startRefreshing();
            }
        });

        if(MyApplication.appMarketType == 2){
            currencySpinnersAndDynamicPairsWrapper.setVisibility(View.GONE);
        }
        Market selectedMarket = MarketsConfigUtils.getMarketByKey(this.checkerRecord.getMarketKey());
        if (selectedMarket == null) {
            selectedMarket = MarketsConfigUtils.getMarketById(0);
            PreferencesUtils.setMarketDefault(getActivity(), selectedMarket.key);
            this.checkerRecord.setMarketKey(selectedMarket.key);
            CustomDialog dialog = new CustomDialog(getActivity());
            dialog.setCancelable(false);
            dialog.setTitle(getResources().getString(R.string.checker_add_exchange_unknown_title));
            dialog.setMessage(getResources().getString(R.string.checker_add_exchange_unknown_text));
            dialog.setPositiveButton(getResources().getString(R.string.ok), new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    showHint();
                }
            });
            dialog.show();
        } else if (!PreferencesUtils.isExchangeTutorialDone(getActivity()) && SQuery.newQuery().count(Checker.CONTENT_URI) == 0) {
            CustomDialog dialog = new CustomDialog(getActivity());
            dialog.setCancelable(false);
            dialog.setTitle(getResources().getString(R.string.checker_add_exchange_tutorial_title));
            dialog.setMessage(getResources().getString(R.string.checker_add_exchange_tutorial_text));
            dialog.setPositiveButton(getResources().getString(R.string.ok), new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    PreferencesUtils.setExchangeTutorialDone(CheckerAddFragment.this.getActivity());
                    showHint();
                }
            });
            dialog.show();
        }
        else
            showHint();
        this.currencyPairsMapHelper = new CurrencyPairsMapHelper(MarketCurrencyPairsStore.getPairsForMarket(getActivity(), selectedMarket.key));
        if(MyApplication.appMarketType == 2){
            this.marketSpinner.setTitle(getContext().getString(R.string.checker_add_check_stock_title));
        }else{
            this.marketSpinner.setTitle(getContext().getString(R.string.checker_add_check_market_title));
        }
        this.marketSpinner.setSummary(selectedMarket.name);
        refreshMarketCautionView(selectedMarket);
        this.marketSpinner.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (MyApplication.appMarketType == 2){
                    StockPickerListActivity.startActivityForResult(CheckerAddFragment.this, CheckerAddFragment.REQ_STOCK_PICKER, CheckerAddFragment.this.checkerRecord.getMarketKey());
                }
                else
                    MarketPickerListActivity.startActivityForResult(CheckerAddFragment.this, CheckerAddFragment.REQ_MARKET_PICKER, CheckerAddFragment.this.checkerRecord.getMarketKey());
            }
        });
        refreshDynamicCurrencyPairsView(selectedMarket);
        View.OnClickListener dynamicCurrencyPairsOnClickListener = new View.OnClickListener() {
            public void onClick(View v) {
                new DynamicCurrencyPairsDialog(CheckerAddFragment.this.getActivity(), CheckerAddFragment.this.getSelectedMarket(), CheckerAddFragment.this.currencyPairsMapHelper) {
                    public void onPairsUpdated(Market market, CurrencyPairsMapHelper currencyPairsMapHelper) {
                        CheckerAddFragment.this.onPairsUpdated(market,currencyPairsMapHelper);
                    }
                }.show();
            }
        };
        this.currencySpinnersAndDynamicPairsWrapper.setOnClickListener(dynamicCurrencyPairsOnClickListener);
        this.currencySpinnersAndDynamicPairsWrapper.setClickable(false);
        this.currencySpinnersAndDynamicPairsWrapper.setFocusable(false);
        this.dynamicCurrencyPairsInfoView.setOnClickListener(dynamicCurrencyPairsOnClickListener);
        refreshCurrencySpinnersForMarket(selectedMarket, false);
        this.currencySrcSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            public boolean onItemSelected(ViewSpinnerPreference viewSpinnerPreference, int position) {
                String newCurrency = viewSpinnerPreference.getEntries() != null ? String.valueOf(viewSpinnerPreference.getEntries()[position]) : null;
                if (newCurrency == null || !newCurrency.equals(CheckerAddFragment.this.checkerRecord.getCurrencySrc())) {
                    CheckerAddFragment.this.checkerRecord.setCurrencySrc(newCurrency);
                    CheckerAddFragment.this.checkerRecord.setCurrencySubunitSrc(1);
                    CheckerAddFragment.this.unsavedChanges = true;
                    CheckerAddFragment.this.clearLastAndPreviousCheck();
                    CheckerAddFragment.this.clearAlarmsLastCheckPoint();
                    CheckerAddFragment.this.refreshCurrencySrcSubunits();
                    CheckerAddFragment.this.refreshCurrencyDstSpinnerForMarket(CheckerAddFragment.this.getSelectedMarket(), true);
                    CheckerAddFragment.this.refreshChart();
                }
                return true;
            }
        });
        this.currencyDstSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            public boolean onItemSelected(ViewSpinnerPreference viewSpinnerPreference, int position) {
                String newCurrency = viewSpinnerPreference.getEntries() != null ? String.valueOf(viewSpinnerPreference.getEntries()[position]) : null;
                if (newCurrency == null || !newCurrency.equals(CheckerAddFragment.this.checkerRecord.getCurrencyDst())) {
                    CheckerAddFragment.this.checkerRecord.setCurrencyDst(newCurrency);
                    CheckerAddFragment.this.checkerRecord.setCurrencySubunitDst(1);
                    CheckerAddFragment.this.unsavedChanges = true;
                    CheckerAddFragment.this.clearLastAndPreviousCheck();
                    CheckerAddFragment.this.clearAlarmsLastCheckPoint();
                    CheckerAddFragment.this.refreshCurrencyDstSubunits();
                    CheckerAddFragment.this.refreshAlarms();
                    CheckerAddFragment.this.refreshChart();
                }
                return true;
            }
        });
        this.currencySrcSpinner.setOnSyncClickedListener(dynamicCurrencyPairsOnClickListener);
        this.currencyDstSpinner.setOnSyncClickedListener(dynamicCurrencyPairsOnClickListener);
        refreshFuturesContractTypes(selectedMarket);
        this.futuresContractTypeSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            public boolean onItemSelected(ViewSpinnerPreference viewSpinnerPreference, int position) {
                Market market = CheckerAddFragment.this.getSelectedMarket();
                if (market instanceof FuturesMarket) {
                    FuturesMarket futuresMarket = (FuturesMarket) market;
                    if (position >= 0 && position < futuresMarket.contractTypes.length) {
                        CheckerAddFragment.this.checkerRecord.setContractType((long) futuresMarket.contractTypes[position]);
                        CheckerAddFragment.this.unsavedChanges = true;
                        CheckerAddFragment.this.clearLastAndPreviousCheck();
                        CheckerAddFragment.this.clearAlarmsLastCheckPoint();
                        CheckerAddFragment.this.refreshChart();
                    }
                }
                return true;
            }
        });
        refreshCurrencySrcSubunits();
        this.currencySrcSubunitSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            public boolean onItemSelected(ViewSpinnerPreference viewSpinnerPreference, int position) {
                try {
                    if (CurrenciesSubunits.CURRENCIES_SUBUNITS.containsKey(CheckerAddFragment.this.checkerRecord.getCurrencySrc())) {
                        CheckerAddFragment.this.checkerRecord.setCurrencySubunitSrc(((CurrencySubunit) ((CurrencySubunitsMap) CurrenciesSubunits.CURRENCIES_SUBUNITS.get(CheckerAddFragment.this.checkerRecord.getCurrencySrc())).values().toArray()[position]).subunitToUnit);
                    } else {
                        CheckerAddFragment.this.checkerRecord.setCurrencySubunitSrc(1);
                    }
                } catch (Exception e) {
                    CheckerAddFragment.this.checkerRecord.setCurrencySubunitSrc(1);
                    e.printStackTrace();
                }
                CheckerAddFragment.this.unsavedChanges = true;
                CheckerAddFragment.this.refreshAlarms();
                return true;
            }
        });
        refreshCurrencyDstSubunits();
        this.currencyDstSubunitSpinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            public boolean onItemSelected(ViewSpinnerPreference viewSpinnerPreference, int position) {
                try {
                    if(viewSpinnerPreference.getEntries()!=null && viewSpinnerPreference.getEntries()[position]!=null && viewSpinnerPreference.getEntries()[position].equals("USD")){
                        CheckerAddFragment.this.checkerRecord.setCurrencySubunitDst(-2);
                    }else {
                        if (CurrenciesSubunits.CURRENCIES_SUBUNITS.containsKey(CheckerAddFragment.this.checkerRecord.getCurrencyDst())) {
                            CheckerAddFragment.this.checkerRecord.setCurrencySubunitDst(((CurrencySubunit) ((CurrencySubunitsMap) CurrenciesSubunits.CURRENCIES_SUBUNITS.get(CheckerAddFragment.this.checkerRecord.getCurrencyDst())).values().toArray()[position]).subunitToUnit);
                        } else {
                            CheckerAddFragment.this.checkerRecord.setCurrencySubunitDst(1);
                        }
                    }
                } catch (Exception e) {
                    CheckerAddFragment.this.checkerRecord.setCurrencySubunitDst(1);
                    e.printStackTrace();
                }
                CheckerAddFragment.this.unsavedChanges = true;
                CheckerAddFragment.this.refreshAlarms();
                return true;
            }
        });
        this.frequencySpinner.setFrequency(this.checkerRecord.getFrequencyType() , this.checkerRecord.getFrequency());
        this.frequencySpinner.setOnFrequencySelectedListener(new OnFrequencySelectedListener() {
            public boolean onFrequencySelected(ViewFrequencyPickerPreference viewSpinnerPreference, int type, long frequency) {
                CheckerAddFragment.this.checkerRecord.setFrequency(frequency);
                CheckerAddFragment.this.checkerRecord.setFrequencyType(type);
                CheckerAddFragment.this.unsavedChanges = true;
                return true;
            }
        });
        this.notificationPriorityView.setChecked(this.checkerRecord.getNotificationPriority() >= -2);
        this.notificationPriorityView.setOnCheckChangedListener(new OnCheckChangedListener() {
            public boolean onCheckChanged(ViewTwoStatePreference viewCheckBoxPreference, boolean checked) {
                CheckerAddFragment.this.checkerRecord.setNotificationPriority(checked ? -2 : -100);
                CheckerAddFragment.this.unsavedChanges = true;
                return true;
            }
        });
        this.checkTTSView.setChecked(this.checkerRecord.getTtsEnabled());
        this.checkTTSView.setOnCheckChangedListener(new OnCheckChangedListener() {
            public boolean onCheckChanged(ViewTwoStatePreference viewCheckBoxPreference, boolean checked) {
                CheckerAddFragment.this.checkerRecord.setTtsEnabled(checked);
                CheckerAddFragment.this.unsavedChanges = true;
                return true;
            }
        });
        this.alarmSectionHeader.setText(R.string.checker_add_alarm_category_title);
        if (getArguments() != null && savedInstanceState == null) {
            long alarmRecordId = getArguments().getLong(MarketChecker.EXTRA_ALARM_RECORD_ID, -1);
            if (alarmRecordId > 0 && this.alarmRecords != null) {
                int i = 0;
                while (i < this.alarmRecords.size()) {
                    AlarmRecord alarmRecord = (AlarmRecord) this.alarmRecords.get(i);
                    if (alarmRecord == null || alarmRecord.getId() != alarmRecordId) {
                        i++;
                    } else {
                        getArguments().remove(MarketChecker.EXTRA_ALARM_RECORD_ID);
                        if (this.alarmRecords.size() == 1) {
                            this.scrollView.post(new Runnable() {
                                public void run() {
                                    CheckerAddFragment.this.scrollView.scrollTo(0, CheckerAddFragment.this.alarmSectionHeader.getBottom());
                                }
                            });
                            return;
                        } else {
                            CheckerAddAlarmActivity.startCheckerAddAlarmActivity(this, 200, this.checkerRecord, alarmRecord, i);
                            return;
                        }
                    }
                }
            }
        }
        refreshChart();
    }

    private void showHint() {
        if (!PreferencesUtils.getUserSyncHint(getContext())) {
            new BubbleShowCaseBuilder(getActivity()) //Activity instance
                    .title(getString(R.string.information)) //Any title for the bubble view
                    .description(getString(R.string.sync_hint)) //More detailed description
                    .arrowPosition(BubbleShowCase.ArrowPosition.TOP) //You can force the position of the arrow to change the location of the bubble.
                    .backgroundColor(getContext().getResources().getColor(R.color.background)) //Bubble background color
                    .textColor(getContext().getResources().getColor(R.color.textPrimaryColor)) //Bubble Text color
                    .titleTextSize(16) //Title text size in SP (default value 16sp)
                    .descriptionTextSize(14) //Subtitle text size in SP (default value 14sp)
                    .image(getResources().getDrawable(R.drawable.amplify_icon)) //Bubble main image
                    .showOnce(PreferencesUtils.USER_SYNC_HINT_KEY) //Id to show only once the BubbleShowCase
                    .targetView(getView().findViewById(R.id.dynamicCurrencyPairsInfoView)) //View to point out
                    .show();
            PreferencesUtils.setUserSyncHint(getContext(),true);
        }
    }

    public void onSaveInstanceState(Bundle outState) {
        outState.putParcelable(CheckerAddActivity.EXTRA_CHECKER_RECORD, this.checkerRecord);
        outState.putSerializable(EXTRA_ALARM_RECORDS, this.alarmRecords);
        outState.putSerializable(EXTRA_REMOVED_ALARM_RECORD_IDS, this.removedAlarmRecordIds);
        outState.putBoolean(EXTRA_UNSAVED_CHANGES, this.unsavedChanges);
        super.onSaveInstanceState(outState);
    }

    public void onDestroyView() {
        super.onDestroyView();
        //ButterKnife.reset(this);
    }
    private void onPairsUpdated(Market market2, CurrencyPairsMapHelper currencyPairsMapHelper2){
        CheckerAddFragment.this.currencyPairsMapHelper = currencyPairsMapHelper2;
        if (CheckerAddFragment.this.getView() != null && CheckerAddFragment.this.getActivity() != null) {
            CheckerAddFragment.this.refreshDynamicCurrencyPairsView(market2);
            CheckerAddFragment.this.refreshCurrencySpinnersForMarket(market2, true);
        }
    }
    private void startRefreshing() {
        this.refreshLayout.setRefreshing(true);
        this.dynamicCurrencyPairsVolleyAsyncTask = new DynamicCurrencyPairsVolleyAsyncTask(this.requestQueue, getContext(), this.getSelectedMarket(), new Response.Listener<CurrencyPairsMapHelper>() {
            public void onResponse(CurrencyPairsMapHelper currencyPairsMapHelper) {
                CheckerAddFragment.this.dynamicCurrencyPairsVolleyAsyncTask = null;
                CheckerAddFragment.this.currencyPairsMapHelper = currencyPairsMapHelper;
                CheckerAddFragment.this.stopRefreshingAnim();
                CheckerAddFragment.this.onPairsUpdated(CheckerAddFragment.this.getSelectedMarket(), currencyPairsMapHelper);
            }
        }, new Response.ErrorListener() {
            public void onErrorResponse(VolleyError error) {
                CheckerAddFragment.this.dynamicCurrencyPairsVolleyAsyncTask = null;
                error.printStackTrace();
                CheckerAddFragment.this.stopRefreshingAnim();
            }
        });
        AsyncTaskCompat.execute(this.dynamicCurrencyPairsVolleyAsyncTask, new Void[0]);
    }
    private void stopRefreshingAnim(){
        refreshLayout.setRefreshing(false);
    }

    private void onMarketChanged(Market market) {
        if (market != null) {
            this.marketSpinner.setSummary(market.name);
            refreshMarketCautionView(market);
            this.currencyPairsMapHelper = new CurrencyPairsMapHelper(MarketCurrencyPairsStore.getPairsForMarket(getActivity(), market.key));
            this.checkerRecord.setMarketKey(market.key);
            this.checkerRecord.setContractType(0);
            this.unsavedChanges = true;
            clearLastAndPreviousCheck();
            clearAlarmsLastCheckPoint();
            refreshDynamicCurrencyPairsView(market);
            refreshCurrencySpinnersForMarket(market, true);
            refreshFuturesContractTypes(market);
            refreshChart();
        }
    }

    private void refreshMarketCautionView(Market market) {
        int textResId;
        int i = View.VISIBLE;
        if (market != null) {
            textResId = market.getCautionResId();
        } else {
            textResId = 0;
        }
        String cautionText = textResId > 0 ? getString(textResId) : "";
        this.marketCautionView.setText(cautionText);
        TextView textView = this.marketCautionView;
        if (TextUtils.isEmpty(cautionText)) {
            i = View.GONE;
        }
        textView.setVisibility(i);
    }

    private Market getSelectedMarket() {
        return MarketsConfigUtils.getMarketByKey(this.checkerRecord.getMarketKey());
    }

    private void refreshDynamicCurrencyPairsView(Market market) {
        boolean dynamicPairsEnabled;
        int i = 0;
        if (market.getCurrencyPairsUrl(0) != null) {
            dynamicPairsEnabled = true;
        } else {
            dynamicPairsEnabled = false;
        }
        this.dynamicCurrencyPairsInfoView.setEnabled(dynamicPairsEnabled);
        View view = this.dynamicCurrencyPairsNoSyncYetView;
        if (!dynamicPairsEnabled || market.currencyPairs == null || market.currencyPairs.isEmpty() || (this.currencyPairsMapHelper != null && this.currencyPairsMapHelper.getDate() > 0)) {
            i = View.GONE;
        }
        //view.setVisibility(i);
        this.currencySrcSpinner.setShowSyncButton(dynamicPairsEnabled);
        this.currencyDstSpinner.setShowSyncButton(dynamicPairsEnabled);
    }

    private void refreshCurrencySpinnersForMarket(Market market, boolean considerAsChange) {
        boolean isCurrencyEmpty;
        refreshCurrencySrcSpinnerForMarket(market, considerAsChange);
        refreshCurrencyDstSpinnerForMarket(market, considerAsChange);
        if (this.checkerRecord.getMarketType() == 2) {
            isCurrencyEmpty = true;
        } else {
            isCurrencyEmpty = false;
        }
        this.currencySpinnersWrapper.setVisibility(isCurrencyEmpty ? View.GONE : View.VISIBLE);
        this.dynamicCurrencyPairsWarningView.setVisibility(isCurrencyEmpty ? View.VISIBLE : View.GONE);
        this.currencySpinnersAndDynamicPairsWrapper.setClickable(isCurrencyEmpty);
        this.currencySpinnersAndDynamicPairsWrapper.setFocusable(isCurrencyEmpty);
        /*
        this.checkSectionWrapper.setVisibility(isCurrencyEmpty? View.GONE : View.VISIBLE);
        this.alarmSectionWrapper.setVisibility(!isCurrencyEmpty? View.VISIBLE : View.GONE);*/
    }

    private HashMap<String, String[]> getProperCurrencyPairs(Market market) {
        if (this.currencyPairsMapHelper == null || this.currencyPairsMapHelper.getCurrencyPairs() == null || this.currencyPairsMapHelper.getCurrencyPairs().size() <= 0) {
            return market.currencyPairs;
        }
        return this.currencyPairsMapHelper.getCurrencyPairs();
    }

    private void refreshCurrencySrcSpinnerForMarket(Market market, boolean considerAsChange) {
        HashMap<String, String[]> currencyPairs = getProperCurrencyPairs(market);
        CharSequence oldSelectedValue = this.checkerRecord.getCurrencySrc();
        String newCurrency = null;
        if (currencyPairs == null || currencyPairs.size() <= 0) {
            this.currencySrcSpinner.setEntriesAndSelection(null, 0);
        } else {
            int selection = 0;
            String[] srcEntries = new String[currencyPairs.size()];
            int i = 0;
            for (String currency : currencyPairs.keySet()) {
                srcEntries[i] = currency;
                if (currency.equals(oldSelectedValue)) {
                    selection = i;
                }
                i++;
            }
            this.currencySrcSpinner.setEntriesAndSelection(srcEntries, selection);
            if (this.currencySrcSpinner.getEntry() != null) {
                newCurrency = String.valueOf(this.currencySrcSpinner.getEntry());
                if (!newCurrency.equals(this.checkerRecord.getCurrencySrc())) {
                    this.checkerRecord.setCurrencySubunitSrc(1);
                    if (this.checkerRecord.getCurrencySrc() != null) {
                        this.unsavedChanges = true;
                    }
                }
            }
        }
        this.checkerRecord.setCurrencySrc(newCurrency);
        refreshCurrencySrcSubunits();
        refreshAlarms();
    }

    private void refreshCurrencyDstSpinnerForMarket(Market market, boolean considerAsChange) {
        HashMap<String, String[]> currencyPairs = getProperCurrencyPairs(market);
        String oldSelectedValue = this.checkerRecord.getCurrencyDst();
        String newCurrency = null;
        if (currencyPairs == null || currencyPairs.size() <= 0 || this.checkerRecord.getCurrencySrc() == null) {
            this.currencyDstSpinner.setEntriesAndSelection(null, 0);
        } else {
            int selection = 0;
            String[] dstEntries = new String[(currencyPairs.get(this.checkerRecord.getCurrencySrc())).length];
            int i = 0;
            for (String currency :currencyPairs.get(this.checkerRecord.getCurrencySrc())) {
                dstEntries[i] = currency;
                if (currency.equals(oldSelectedValue)) {
                    selection = i;
                }
                i++;
            }
            this.currencyDstSpinner.setEntriesAndSelection(dstEntries, selection);
            if (this.currencyDstSpinner.getEntry() != null) {
                newCurrency = String.valueOf(this.currencyDstSpinner.getEntry());
                if (!newCurrency.equals(this.checkerRecord.getCurrencyDst())) {
                    this.checkerRecord.setCurrencySubunitDst(1);
                    if (this.checkerRecord.getCurrencyDst() != null) {
                        this.unsavedChanges = true;
                    }
                }
            }
        }
        this.checkerRecord.setCurrencyDst(newCurrency);
        refreshCurrencyDstSubunits();
        refreshAlarms();
    }

    private void refreshFuturesContractTypes(Market market) {
        String[] entries = null;
        int selection = 0;
        if (market instanceof FuturesMarket) {
            int oldContractType = (int) this.checkerRecord.getContractType();
            FuturesMarket futuresMarket = (FuturesMarket) market;
            entries = new String[futuresMarket.contractTypes.length];
            for (int i = 0; i < futuresMarket.contractTypes.length; i++) {
                int contractType = futuresMarket.contractTypes[i];
                entries[i] = FormatUtils.getContractTypeName(getActivity(), contractType);
                if (oldContractType == contractType) {
                    selection = i;
                }
            }
        }
        this.futuresContractTypeSpinner.setEntriesAndSelection(entries, selection);
        this.futuresContractTypeSpinner.setVisibility(entries != null ? View.VISIBLE : View.GONE);
    }

    private void refreshCurrencySrcSubunits() {
        this.currencySrcSubunitSpinner.setVisibility(View.GONE);
    }

    private void refreshCurrencyDstSubunits() {
        if (!refreshCurrencySubunits(this.checkerRecord.getCurrencyDst(), this.currencyDstSubunitSpinner, this.checkerRecord.getCurrencySubunitDst())) {
            if (this.checkerRecord.getCurrencySubunitDst() != 1) {
                this.unsavedChanges = true;
            }
            this.checkerRecord.setCurrencySubunitDst(1);
        }
    }

    private boolean refreshCurrencySubunits(String currency, ViewSpinnerPreference viewSpinnerPreference, long subunitToUnit) {
        String[] entries;
        boolean hasSubunits = true;
        int i = View.VISIBLE;
        int selection = 0;
        if (CurrenciesSubunits.CURRENCIES_SUBUNITS.containsKey(currency)) {
            LinkedHashMap<Long, CurrencySubunit> subunits = (LinkedHashMap) CurrenciesSubunits.CURRENCIES_SUBUNITS.get(currency);
            entries = new String[subunits.size()+1];
            int i2 = 0;
            for (CurrencySubunit currencySubunit : subunits.values()) {
                entries[i2] = currencySubunit.name;
                if (currencySubunit.subunitToUnit == subunitToUnit) {
                    selection = i2;
                }
                i2++;
            }
            if(currency!= null && currency.equalsIgnoreCase("BTC")){
                entries[i2] = "USD";
                if(checkerRecord.getCurrencySubunitDst() == -2)
                    selection = i2;
            }
            else if (entries == null || entries.length <= 0) {
                hasSubunits = false;
            }
        } else {
            if(currency!=null && (currency.equalsIgnoreCase("ETH"))){
                entries = new String[]{currency, "USD"};
                if(checkerRecord.getCurrencySubunitDst() == -2)
                    selection = 1;
                else
                    selection = 0;
                hasSubunits = true;
            }else {
                entries = new String[]{currency};
                selection = 0;
                hasSubunits = false;
            }
        }
        viewSpinnerPreference.setEntriesAndSelection(entries, selection);
        if (currency == null) {
            i = View.GONE;
        }
        viewSpinnerPreference.setVisibility(i);
        viewSpinnerPreference.setEnabled(hasSubunits);
        return hasSubunits;
    }

    private void clearLastAndPreviousCheck() {
        if (!TextUtils.isEmpty(this.checkerRecord.getLastCheckTicker()) || !TextUtils.isEmpty(this.checkerRecord.getPreviousCheckTicker())) {
            this.unsavedChanges = true;
        }
        this.checkerRecord.setLastCheckTicker(null);
        this.checkerRecord.setPreviousCheckTicker(null);
    }

    private void refreshChart() {
        if (getActivity()!=null && checkerRecord.getMarketKey()!=null){
            checkerChartView.setVisibility(View.VISIBLE);
            DisplayMetrics metrics = new DisplayMetrics();
            getActivity().getWindowManager().getDefaultDisplay().getMetrics(metrics);
            int width = (int) (metrics.widthPixels/metrics.density);
            String symbol = checkerRecord.getMarketKey().toUpperCase();
            if(checkerRecord.getCurrencySrc() != null && checkerRecord.getCurrencyDst()!= null)
                symbol = symbol+":"+checkerRecord.getCurrencySrc()+checkerRecord.getCurrencyDst();
            chckerWebview.reload();
            chckerWebview.setBackgroundColor(getResources().getColor(R.color.background));
            chckerWebview.getSettings().setJavaScriptEnabled(true);
            chckerWebview.getSettings().setAppCacheEnabled(false);
            chckerWebview.getSettings().setPluginState(WebSettings.PluginState.ON);
            boolean darkTheme = MyApplication.getInstance().isNightModeEnabled();
            chckerWebview.setWebViewClient(new WebViewClient(){
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    return true;
                }
                @Override
                public void onPageFinished(WebView view, String url)
                {
                    String command = "javascript:document.body.style.background = " + (darkTheme?"#000000":"#FAFAFA") + ";";
                    view.loadUrl(command);
                }
            });
            String tickerview = "<div class=\"tradingview-widget-container\">\n" +
                    "  <div id=\"tradingview_22468\"></div>\n" +
                    "  <script type=\"text/javascript\" src=\"https://s3.tradingview.com/tv.js\"></script>\n" +
                    "  <script type=\"text/javascript\">\n" +
                    "  new TradingView.widget(\n" +
                    "  {\n" +
                    "  \"width\": "+(width-20)+",\n" +
                    "  \"height\": 265,\n" +
                    "  \"symbol\": \""+symbol+"\",\n" +
                    "  \"interval\": \"D\",\n" +
                    "  \"timezone\": \"Etc/UTC\",\n" +
                    "  \"theme\": \""+(darkTheme?"dark":"light")+"\",\n" +
                    "  \"style\": \"1\",\n" +
                    "  \"locale\": \"in\",\n" +
                    "  \"enable_publishing\": false,\n" +
                    "  \"isTransparent\": true,\n" +
                    "  \"save_image\": false,\n" +
                    "  \"container_id\": \"tradingview_22468\"\n" +
                    "  }\n" +
                    "  );\n" +
                    "  </script>\n" +
                    "</div>";
            chckerWebview.loadData(tickerview,"text/html","UTF-8");
        }
        else{
            checkerChartView.setVisibility(View.GONE);
        }
    }

    private void clearAlarmsLastCheckPoint() {
        Iterator it = this.alarmRecords.iterator();
        while (it.hasNext()) {
            AlarmRecord alarmRecord = (AlarmRecord) it.next();
            if (!TextUtils.isEmpty(alarmRecord.getLastCheckPointTicker())) {
                this.unsavedChanges = true;
            }
            alarmRecord.setLastCheckPointTicker(null);
        }
    }

    private void refreshAlarms() {
        if (this.alarmRecords.size() == 1) {
            this.checkerAddAlarmFragment.setCheckerAndAlarmRecord(this.checkerRecord, (AlarmRecord) this.alarmRecords.get(0));
            this.checkerAddAlarmFragmentWrapper.setVisibility(View.VISIBLE);
        } else {
            this.checkerAddAlarmFragmentWrapper.setVisibility(View.GONE);
        }
        this.alarmsAdapter.notifyDataSetChanged();
    }

    public void makeUnsavedChanges() {
        this.unsavedChanges = true;
    }

    public boolean onBackPressed() {
        if (!this.unsavedChanges && (this.checkerAddAlarmFragment == null || !this.checkerAddAlarmFragment.getUnsavedChanges())) {
            return false;
        }
        CustomDialog backDialog = new CustomDialog(getContext());
        backDialog.setTitle(getResources().getString(R.string.checker_add_unsaved_changes_dialog_title));
        backDialog.setMessage(getResources().getString(R.string.checker_add_unsaved_changes_dialog_message));
        backDialog.setNegativeButton(getResources().getString(R.string.generic_quit), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backDialog.dismiss();
                CheckerAddFragment.this.getActivity().finish();
            }
        });
        backDialog.setNeutralButton(getResources().getString(R.string.cancel), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backDialog.dismiss();
            }
        });
        backDialog.setPositiveButton(getResources().getString(R.string.generic_save), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backDialog.dismiss();
                CheckerAddFragment.this.save();
            }
        });
        backDialog.show();
        return true;
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.checker_add_fragment, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.saveItem) {
            save();
            return true;
        } else if (item.getItemId() != R.id.deleteItem) {
            return super.onOptionsItemSelected(item);
        } else {
            delete();
            return true;
        }
    }

    private void save() {
        PreferencesUtils.setDefaultItemAdded(getActivity());
        /*if (this.checkerRecord.getCurrencySrc() == null || this.checkerRecord.getCurrencyDst() == null) {
            Utils.showToast((Context) getActivity(), (int) R.string.checker_add_save_error_no_currency_pair, true);
            return;
        }*/
        if(checkerRecord.getMarketType() == 2){
            checkerRecord.setCurrencySrc(checkerRecord.getMarketKey());
            checkerRecord.setCurrencyDst("");
        }
        String holdings= holdingsView.getText().toString();
        if (!holdings.isEmpty()) {
            try {
                double amount = Double.parseDouble(holdings);
                checkerRecord.setHoldings((amount > 0) ? amount + "" : "0");
            }catch (Exception e){
                checkerRecord.setHoldings("0");
            }
        }else{
            checkerRecord.setHoldings("0");
        }
        String str;
        if (this.currencyPairsMapHelper != null) {
            str = this.currencyPairsMapHelper.getCurrencyPairId(this.checkerRecord.getCurrencySrc(), this.checkerRecord.getCurrencyDst());
        } else {
            str = null;
        }
        this.checkerRecord.setCurrencyPairId(str);
        this.checkerRecord.setEnabled(true);
        try {
            this.checkerRecord.save(false);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        if (this.checkerRecord.getId() > 0) {
            Iterator it = this.removedAlarmRecordIds.iterator();
            while (it.hasNext()) {
                SQuery.newQuery().expr("_id", Op.EQ, ((Long) it.next()).longValue()).delete(Alarm.CONTENT_URI, false);
            }
            Iterator it2 = this.alarmRecords.iterator();
            while (it2.hasNext()) {
                AlarmRecord alarmRecord = (AlarmRecord) it2.next();
                alarmRecord.setCheckerId(this.checkerRecord.getId());
                alarmRecord.setEnabled(alarmRecord.getEnabled());
                alarmRecord.save(false);
            }
        }
        Mechanoid.getContentResolver().notifyChange(Checker.CONTENT_URI, null);
        Mechanoid.getContentResolver().notifyChange(Alarm.CONTENT_URI, null);
        CheckerRecordHelper.doAfterEdit(getActivity(), this.checkerRecord, true);
        getActivity().setResult(Activity.RESULT_OK);
        getActivity().finish();
    }

    private void delete() {
        if (this.checkerRecord.getId() > 0) {
            CheckerRecordHelper.doBeforeDelete(getActivity(), this.checkerRecord);
            try {
                this.checkerRecord.delete(true);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
            CheckerRecordHelper.doAfterDelete(getActivity(), this.checkerRecord);
        }
        getActivity().setResult(Activity.RESULT_OK);
        getActivity().finish();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == -1) {
            if (requestCode == 200) {
                int alarmRecordPosition = data.getIntExtra(CheckerAddAlarmActivity.EXTRA_ALARM_RECORD_INDEX, -1);
                AlarmRecord alarmRecord = (AlarmRecord) data.getParcelableExtra(CheckerAddAlarmActivity.EXTRA_ALARM_RECORD);
                if (alarmRecordPosition < 0 || alarmRecordPosition >= this.alarmRecords.size()) {
                    if (alarmRecord != null) {
                        this.alarmRecords.add(alarmRecord);
                    }
                } else if (alarmRecord != null) {
                    this.alarmRecords.set(alarmRecordPosition, alarmRecord);
                } else {
                    this.alarmRecords.remove(alarmRecordPosition);
                }
                this.unsavedChanges = true;
                refreshAlarms();
            } else if (requestCode == REQ_MARKET_PICKER) {
                onMarketChanged(MarketsConfigUtils.getMarketByKey(data.getStringExtra(MarketPickerListActivity.EXTRA_MARKET_KEY)));
            }
            else if (requestCode == REQ_STOCK_PICKER){
                ExchangeModel searchModel = (ExchangeModel) data.getSerializableExtra(StockPickerListActivity.EXTRA_MARKET_KEY);
                StockMarket stockMarket = new StockMarket(searchModel.getSymbol(),searchModel.getName(),searchModel.getName(),null);
                onMarketChanged(stockMarket);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        this.requestQueue.cancelAll((Object) this);
        if (this.dynamicCurrencyPairsVolleyAsyncTask != null) {
            this.dynamicCurrencyPairsVolleyAsyncTask.cancel(true);
        }
        this.currencyPairsMapHelper = null;
    }
}
