package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Eterbase extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Eterbase";
    private static final String TTS_NAME = "Eterbase";
    private static final String URL = "https://api.eterbase.exchange/api/v1/tickers/%1$s/ticker";
    private static final String CURRENCIES_URL = "https://api.eterbase.exchange/api/v1/markets";

    public Eterbase() {
        super("eterbase", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Eterbase.png";
        //return "https://assets.coingecko.com/markets/images/438/small/IMG_20200408_212536_328_%281%29.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.eterbase;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.last = ParseUtils.getDouble(jsonObject, "price");
        ticker.high = ParseUtils.getDouble(jsonObject, "high");
        ticker.low = ParseUtils.getDouble(jsonObject, "low");
        ticker.vol = ParseUtils.getDouble(jsonObject, "volume");
        if (jsonObject.has("time"))
            ticker.timestamp = jsonObject.getLong("time");
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject pairObject = jsonArray.getJSONObject(i);
            if (pairObject.has("symbol"))
                pairs.add(new CurrencyPairInfo(pairObject.getString("base"),pairObject.getString("quote"),String.valueOf(pairObject.getInt("id"))));
        }
    }

}
