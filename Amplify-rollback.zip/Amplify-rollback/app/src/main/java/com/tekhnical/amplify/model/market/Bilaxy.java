package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Bilaxy extends Market {
    public static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    public static final String NAME = "Bilaxy";
    public static final String TTS_NAME = "Bilaxy";
    public static final String URL1 = "https://newapi.bilaxy.com/v1/ticker/24hr?pair=%1$s";
    public static final String URL2 = "https://newapi.bilaxy.com/v1/valuation?currency=%1$s";
    public static final String CURRENCIES_URL = "https://newapi.bilaxy.com/v1/pairs";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{Currency.TRY});
    }

    /*@Override
    public String getImageUrl() {
        //return "https://assets.coingecko.com/markets/images/193/small/bilaxy.png";
        return "file:///android_asset/logos/Bilaxy.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bilaxy;
    }
    public Bilaxy() {
        super("bilaxy",NAME, TTS_NAME, null);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        if (requestId ==0)
            return String.format(URL1, checkerInfo.getCurrencyPairId());
        else
            return String.format(URL2, checkerInfo.getCurrencyBase());
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    @Override
    public int getNumOfRequests(CheckerInfo checkerInfo) {
        return 2;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        JSONArray pairNames = jsonObject.names();
        for (int i = 0; i < pairNames.length(); i++) {
            JSONObject pairObject = jsonObject.getJSONObject(pairNames.getString(i));
            if (pairObject.has("base") && pairObject.has("quote")) {
                list.add(new CurrencyPairInfo(pairObject.getString("base"), pairObject.getString("quote"), pairNames.getString(i)));
            }
        }
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        if (requestId ==0) {
            JSONObject dataJsonObject = jsonObject.getJSONObject(checkerInfo.getCurrencyPairId());
            ticker.vol = ParseUtils.getDoubleFromString(dataJsonObject, "base_volume");
            ticker.high = ParseUtils.getDoubleFromString(dataJsonObject, "height");
            ticker.low = ParseUtils.getDoubleFromString(dataJsonObject, "low");
            ticker.last = ParseUtils.getDoubleFromString(dataJsonObject, "close");
        }else{
            JSONObject jsonObject1 = jsonObject.getJSONObject(checkerInfo.getCurrencyBase());
            if (jsonObject1.has(checkerInfo.getCurrencyCounterLowerCase()+"_value"))
                ticker.last = ParseUtils.getDoubleFromString(jsonObject1,checkerInfo.getCurrencyCounterLowerCase()+"_value");
        }
    }
}
