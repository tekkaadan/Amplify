package com.tekhnical.amplify.activity;

import android.content.Intent;
import android.os.Bundle;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.generic.SimpleFragmentSubActivity;
import com.tekhnical.amplify.fragment.SettingsSoundsFragment;

public class SettingsSoundsActivity extends SimpleFragmentSubActivity<SettingsSoundsFragment> {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.setContentTheme(true);
        super.onCreate(savedInstanceState);
    }

    @Override
    public SettingsSoundsFragment createChildFragment() {
        return new SettingsSoundsFragment();
    }

    @Override
    public int getContentViewResId() {
        return R.layout.setting_main_activity;
    }

    @Override
    public String getContentViewTitle() {
        return getString(R.string.settings_activity_title);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        ((SettingsSoundsFragment) getChildFragment()).onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }

    /*@Override
    public String getContentViewTitle() {
        return getResources().getString(R.string.settings_sounds_category_title);
    }*/
}
