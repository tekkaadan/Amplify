package com.tekhnical.amplify.model.market.futures;

import android.util.Log;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.FuturesMarket;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.VirtualCurrency;

import org.json.JSONArray;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

public class BitfinexFuture extends FuturesMarket {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    public static final String ID = "bitfinex_futures";
    private static final String NAME = "Bitfinex Future";
    private static final String TTS_NAME = "Bitfinex Future";
    private static final String URL = "https://api-pub.bitfinex.com/v2/tickers?symbols=%1$s";
    private static final String URL_CURRENCY_PAIRS = "https://api-pub.bitfinex.com/v2/conf/pub:list:pair:exchange";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{VirtualCurrency.UST});
        CURRENCY_PAIRS.put(VirtualCurrency.ETH, new String[]{VirtualCurrency.UST});
    }

    public BitfinexFuture() {
        super(ID,NAME, TTS_NAME, CURRENCY_PAIRS,new int[]{2,4});
    }

    @Override
    public int getImageUrl() {
        return R.drawable.bitfinex_futures;
    }
    /*@Override
    public String getImageUrl() {
        //return "https://assets.coingecko.com/markets/images/486/small/bitfinex.jpg";
        return "file:///android_asset/logos/BitfenixFutures.png";
    }*/

    public String getUrl(int requestId, CheckerInfo checkerInfo, int type) {
        String pairId = checkerInfo.getCurrencyPairId();
        if (pairId == null) {
            pairId = String.format("t%1$sF0:%2$sF0", new Object[]{checkerInfo.getCurrencyBase(), checkerInfo.getCurrencyCounter()});
        }
        return String.format(URL, new Object[]{pairId});
    }

    @Override
    public void parseTicker(int requestId, String responseString, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        JSONArray tickerArray = jsonArray.getJSONArray(0);
        if (tickerArray.length()>10){
            ticker.bid = tickerArray.getDouble(1);
            ticker.ask = tickerArray.getDouble(3);
            ticker.last = tickerArray.getDouble(7);
            ticker.vol = tickerArray.getDouble(8);
            ticker.high = tickerArray.getDouble(9);
            ticker.low = tickerArray.getDouble(10);
        }
    }


    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray pairsArray = new JSONArray(responseString).getJSONArray(0);
        for (int i = 0; i < pairsArray.length(); i++) {
            String pairId = pairsArray.getString(i);
            if (pairId != null ) {
                if( pairId.length() == 6) {
                    pairs.add(new CurrencyPairInfo(pairId.substring(0, 3).toUpperCase(Locale.US), pairId.substring(3).toUpperCase(Locale.US), pairId));
                }
                else if(pairId.contains(":")){
                    pairs.add(new CurrencyPairInfo(pairId.substring(0,pairId.indexOf(":")).toUpperCase(Locale.US),pairId.substring(pairId.indexOf(":")+1).toUpperCase(Locale.US),pairId));
                }
            }
        }
    }
}
