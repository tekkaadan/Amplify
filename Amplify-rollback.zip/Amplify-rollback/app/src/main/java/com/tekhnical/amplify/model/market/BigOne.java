package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class BigOne extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Bigone";
    private static final String TTS_NAME = "Bigone";
    private static final String URL = "https://big.one/api/v3/asset_pairs/%1$s/ticker";
    private static final String CURRENCIES_URL = "https://big.one/api/v3/asset_pairs";

    public BigOne() {
        super("bigone", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        //return "https://assets.coingecko.com/markets/images/100/small/qcFFufEY_400x400.jpg";
        return "file:///android_asset/logos/BigONE.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bigone;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject("data");
        if (jsonObject.has("bid"))
            ticker.bid = ParseUtils.getDoubleFromString(jsonObject.getJSONObject("bid"), "price");
        if (jsonObject.has("ask"))
            ticker.ask = ParseUtils.getDoubleFromString(jsonObject.getJSONObject("ask"), "price");
        ticker.last = (ticker.bid + ticker.ask)/2;
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "volume");

    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = json.getJSONArray("data");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("quote_asset") && jsonObject.has("base_asset")){
                list.add(new CurrencyPairInfo(jsonObject.getJSONObject("base_asset").getString("symbol"),jsonObject.getJSONObject("quote_asset").getString("symbol"),jsonObject.getString("name")));
            }
        }
    }

}
