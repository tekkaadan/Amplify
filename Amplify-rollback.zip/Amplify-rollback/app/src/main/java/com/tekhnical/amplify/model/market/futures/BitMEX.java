package com.tekhnical.amplify.model.market.futures;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.FuturesMarket;
import com.tekhnical.amplify.model.Ticker;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class BitMEX extends FuturesMarket {
    private static final SimpleDateFormat ISO_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
    public static final String ID = "bitmex";
    private static final String NAME = "BitMEX";
    private static final String TTS_NAME = "BitMEX";
    private static final String URL = "https://www.bitmex.com/api/v1/instrument?symbol=%1$s&columns=bidPrice,askPrice,turnover24h,highPrice,lowPrice,lastPrice";
    private static final String URL_CURRENCY_PAIRS = "https://www.bitmex.com/api/v1/instrument?columns=rootSymbol,typ&filter={\"state\":\"Open\"}";

    static {
        ISO_DATE_FORMAT.setTimeZone(TimeZone.getTimeZone("GMT"));
    }

    public BitMEX() {
        super(ID,NAME, TTS_NAME, null,new int[]{2,3,4,5});
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo, int contractType) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }
    @Override
    public int getImageUrl() {
        return R.drawable.bitmex;
    }
    /*@Override
    public String getImageUrl() {
        //return "https://assets.coingecko.com/markets/images/378/small/BitMEX.png";
        return "file:///android_asset/logos/Bitmex.png";
    }*/

    @Override
    public void parseTicker(int requestId, String responseString, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        parseTickerFromJsonObject(requestId, new JSONArray(responseString).getJSONObject(0), ticker, checkerInfo);
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = jsonObject.getDouble("bidPrice");
        ticker.ask = jsonObject.getDouble("askPrice");
        ticker.vol = jsonObject.getDouble("turnover24h") / 1.0E8d;
        if (!jsonObject.isNull("highPrice")) {
            ticker.high = jsonObject.getDouble("highPrice");
        }
        if (!jsonObject.isNull("lowPrice")) {
            ticker.low = jsonObject.getDouble("lowPrice");
        }
        ticker.last = jsonObject.getDouble("lastPrice");
        ticker.timestamp = ISO_DATE_FORMAT.parse(jsonObject.getString("timestamp")).getTime();
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray instruments = new JSONArray(responseString);
        for (int i = 0; i < instruments.length(); i++) {
            parseCurrencyPairsFromJsonObject(requestId, instruments.getJSONObject(i), pairs);
        }
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> pairs) throws Exception {
        String base = jsonObject.getString("rootSymbol");
        String id = jsonObject.getString("symbol");
        String quote = id.substring(id.indexOf(base) + base.length());
        if (jsonObject.getString("typ").equals("FFICSX")) {
            quote = base;
            base = "BINARY";
        }
        pairs.add(new CurrencyPairInfo(base, quote, id));
    }
}