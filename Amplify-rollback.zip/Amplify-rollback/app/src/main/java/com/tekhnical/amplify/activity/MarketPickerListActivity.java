package com.tekhnical.amplify.activity;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.generic.SimpleFragmentSubActivity;
import com.tekhnical.amplify.fragment.MarketPickerListFragment;

public class MarketPickerListActivity extends SimpleFragmentSubActivity<MarketPickerListFragment> {
    public static final String EXTRA_MARKET_KEY = "market_key";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.setContentTheme(false);
        super.onCreate(savedInstanceState);
    }

    @Override
    public MarketPickerListFragment createChildFragment() {
        return new MarketPickerListFragment();
    }

    public void onBackPressed() {
        if (!(getChildFragment()).onBackPressed()) {
            super.onBackPressed();
        }
    }

    public static void startActivityForResult(Fragment fragment, int requestCode, String marketKey) {
        Intent intent = new Intent(fragment.getActivity(), MarketPickerListActivity.class);
        intent.putExtra(EXTRA_MARKET_KEY, marketKey);
        fragment.startActivityForResult(intent, requestCode);
    }

    @Override
    public int getContentViewResId() {
        return R.layout.setting_main_activity;
    }

    @Override
    public String getContentViewTitle() {
        return getString(R.string.checker_add_check_market_title);
    }
}
