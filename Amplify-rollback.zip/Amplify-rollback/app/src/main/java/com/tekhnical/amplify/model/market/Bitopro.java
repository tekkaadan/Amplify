package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Bitopro extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Bitopro";
    private static final String TTS_NAME = "Bitopro";
    private static final String URL = "https://api.bitopro.com/v3/tickers/%1$s";
    private static final String CURRENCIES_URL = "https://api.bitopro.com/v3/provisioning/trading-pairs";


    public Bitopro() {
        super("bitopro", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/BitoPro.png";
        //return "https://assets.coingecko.com/markets/images/358/small/bitopro_coingecko_250x250_%281%29.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bitopro;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerOb, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerOb.getJSONObject("data");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "lastPrice");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low24hr");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high24hr");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "volume24hr");


    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = json.getJSONArray("data");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject pairObject = jsonArray.getJSONObject(i);
            list.add(new CurrencyPairInfo(pairObject.getString("base").toUpperCase(),pairObject.getString("quote").toUpperCase(),pairObject.getString("pair")));
        }
    }

}
