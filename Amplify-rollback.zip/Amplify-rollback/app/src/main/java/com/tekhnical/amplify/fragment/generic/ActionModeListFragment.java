package com.tekhnical.amplify.fragment.generic;

import android.os.Build.VERSION;
import android.util.SparseBooleanArray;
import android.view.ActionMode;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView.MultiChoiceModeListener;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ListAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.ListFragment;

public class ActionModeListFragment<T> extends ListFragment {
    private ListAdapter adapter;
    private int contextMenuSelectenItemPosition = -1;
    private ActionMode currentActionMode;

    protected class MyMultiChoiceModeListener implements MultiChoiceModeListener {
        protected MyMultiChoiceModeListener() {
        }

        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            ActionModeListFragment.this.onActionModeActive(true);
            ActionModeListFragment.this.currentActionMode = mode;
            int menuResId = ActionModeListFragment.this.getActionModeOrContextMenuResId();
            if (menuResId <= 0) {
                return false;
            }
            mode.getMenuInflater().inflate(menuResId, menu);
            refreshIconsAndTitle(mode);
            return true;
        }

        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            boolean ret = false;
            SparseBooleanArray checkedItemsArray = ActionModeListFragment.this.getListView().getCheckedItemPositions();
            if (checkedItemsArray != null) {
                int checkedItemsCount = checkedItemsArray.size();
                int i = 0;
                while (i < checkedItemsCount) {
                    try {
                        if (checkedItemsArray.valueAt(i)) {
                            if (ActionModeListFragment.this.onActionModeOrContextMenuItemClicked(item.getItemId(), (T) ActionModeListFragment.this.adapter.getItem(checkedItemsArray.keyAt(i)), checkedItemsArray.keyAt(i), checkedItemsCount, i == checkedItemsCount + -1)) {
                                ret = true;
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    i++;
                }
            }
            if (ret) {
                mode.finish();
            }
            return ret;
        }

        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {
            refreshIconsAndTitle(mode);
        }

        private void refreshIconsAndTitle(ActionMode mode) {
            int checkedItemCount = ActionModeListFragment.this.getListView().getCheckedItemCount();
            mode.setTitle(String.valueOf(checkedItemCount));
            ActionModeListFragment.this.onActionModeItemsCheckedCountChanged(mode, checkedItemCount);
        }

        public void onDestroyActionMode(ActionMode mode) {
            ActionModeListFragment.this.onActionModeActive(false);
            ActionModeListFragment.this.currentActionMode = null;
        }
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        try {
            onListItemClick(l, v, position, (T) this.adapter.getItem(position));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onListItemClick(ListView l, View v, int position, T t) {
    }

    public void setListAdapter(ListAdapter adapter2) {
        this.adapter = adapter2;
        super.setListAdapter(adapter2);
    }

    public void cancelActionModeOrContextMenu() {
        if (VERSION.SDK_INT < 11) {
            getActivity().closeContextMenu();
        } else if (this.currentActionMode != null) {
            this.currentActionMode.finish();
        }
    }

    public void enableActionModeOrContextMenu() {
        if (VERSION.SDK_INT >= 11) {
            getListView().setChoiceMode(3);
            getListView().setMultiChoiceModeListener(new MyMultiChoiceModeListener());
            return;
        }
        registerForContextMenu(getListView());
    }

    public void onActionModeActive(boolean active) {
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        AdapterContextMenuInfo info = (AdapterContextMenuInfo) menuInfo;
        int menuResId = getActionModeOrContextMenuResId();
        if (menuResId != 0) {
            this.contextMenuSelectenItemPosition = info.position;
            getActivity().getMenuInflater().inflate(menuResId, menu);
            super.onCreateContextMenu(menu, v, menuInfo);
            return;
        }
        this.contextMenuSelectenItemPosition = -1;
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        if (this.contextMenuSelectenItemPosition > -1) {
            try {
                return onActionModeOrContextMenuItemClicked(item.getItemId(), (T) this.adapter.getItem(this.contextMenuSelectenItemPosition), this.contextMenuSelectenItemPosition, 1, true);
            } catch (Exception e) {
                e.printStackTrace();
                this.contextMenuSelectenItemPosition = -1;
            }
        }
        return false;
    }

    public int getActionModeOrContextMenuResId() {
        return 0;
    }

    public void onActionModeItemsCheckedCountChanged(ActionMode mode, int checkedItemCount) {
    }

    public boolean onActionModeOrContextMenuItemClicked(int menuItemId, T t, int listItemPosition, int checkedItemsCount, boolean isForLastItem) {
        return false;
    }
}
