package com.tekhnical.amplify.alarm;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import com.tekhnical.amplify.content.AlarmRecord;
import com.tekhnical.amplify.receiver.MarketChecker;

public class AlarmKlaxonHelper {
    public static void startAlarmKlaxon(Context context, AlarmRecord alarmRecord) {
    }

    public static PendingIntent createAlarmKlaxonDismissPendingIntent(Context context, long checkerRecordId, long alarmRecordId) {
        return PendingIntent.getBroadcast(context, (int) alarmRecordId, createAlarmKlaxonDismissIntent(context, checkerRecordId, alarmRecordId), PendingIntent.FLAG_CANCEL_CURRENT);
    }

    public static Intent createAlarmKlaxonDismissIntent(Context context, long checkerRecordId, long alarmRecordId) {
        Intent intent = new Intent(Alarms.ALARM_DISMISS_ACTION);
        intent.putExtra(MarketChecker.EXTRA_CHECKER_RECORD_ID, checkerRecordId);
        intent.putExtra(MarketChecker.EXTRA_ALARM_RECORD_ID, alarmRecordId);
        return intent;
    }
}
