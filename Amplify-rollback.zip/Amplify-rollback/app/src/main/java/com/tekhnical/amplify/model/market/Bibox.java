package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Bibox extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Bibox";
    private static final String TTS_NAME = "Bibox";
    private static final String URL = "https://api.bibox.com/v1/mdata?cmd=ticker&pair=%1$s";
    private static final String CURRENCIES_URL = "https://api.bibox.com/v1/mdata?cmd=pairList";

    public Bibox() {
        super("bibox", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }


   /* @Override
    public String getImageUrl() {
        //return "https://assets.coingecko.com/markets/images/114/small/bibox.jpg";
        return "file:///android_asset/logos/bibox.png";
    }*/
   @Override
   public int getImageUrl() {
       return R.drawable.bibox;
   }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject jsonObject = tickerObject.getJSONObject("result");
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "buy");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "sell");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "vol");

    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONArray jsonArray = json.getJSONArray("result");
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("pair")){
                String splits[] = jsonObject.getString("pair").split("_");
                if (splits.length>=2)
                    list.add(new CurrencyPairInfo(splits[0],splits[1],jsonObject.getString("pair")));
            }
        }
    }

}
