package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Coindcx extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Coindcx";
    private static final String TTS_NAME = "Coindcx";
    private static final String URL = "https://api.coindcx.com/exchange/ticker";
    private static final String CURRENCIES_URL = "https://api.coindcx.com/exchange/v1/markets_details";

    public Coindcx() {
        super("coindcx", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return URL;
    }


    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/CoinDCX.png";
        //return "https://assets.coingecko.com/markets/images/520/small/coindcx.png";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.coindcx;
    }
    @Override
    public void parseTicker(int requestId, String responseString, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i=0;i<jsonArray.length();i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("market") && jsonObject.getString("market").equals(checkerInfo.getCurrencyPairId())) {
                ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "bid");
                ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "ask");
                ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last_price");
                ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
                ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
                ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "volume");
                if (jsonObject.has("timestamp"))
                    ticker.timestamp = jsonObject.getLong("timestamp");
            }
        }
    }


    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("coindcx_name")){
                pairs.add(new CurrencyPairInfo(jsonObject.getString("base_currency_short_name"),jsonObject.getString("target_currency_short_name"),jsonObject.getString("coindcx_name")));
            }
        }
    }

}
