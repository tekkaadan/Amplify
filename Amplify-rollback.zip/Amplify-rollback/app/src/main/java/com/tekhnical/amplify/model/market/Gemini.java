package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import org.json.JSONArray;
import org.json.JSONObject;

public class Gemini extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Gemini";
    private static final String TTS_NAME = "Gemini";
    private static final String URL = "https://api.gemini.com/v1/book/%1$s%2$s?limit_asks=1&limit_bids=1";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{Currency.USD});
        CURRENCY_PAIRS.put(VirtualCurrency.ETH, new String[]{VirtualCurrency.BTC, Currency.USD});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Gemini.png";
        //return "https://assets.coingecko.com/markets/images/29/small/kraken.jpg";
    }*/
    @Override
    public int getImageUrl() {
        return R.drawable.gemini;
    }
    public Gemini() {
        super("gemini",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyBase(), checkerInfo.getCurrencyCounter()});
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONArray bidsArray = jsonObject.getJSONArray("bids");
        if (bidsArray != null && bidsArray.length() > 0) {
            ticker.bid = ParseUtils.getDoubleFromString(bidsArray.getJSONObject(0),"price");
        }
        JSONArray asksArray = jsonObject.getJSONArray("asks");
        if (asksArray != null && asksArray.length() > 0) {
            ticker.ask = ParseUtils.getDoubleFromString(asksArray.getJSONObject(0),"price");
        }
        if (ticker.bid != -1.0d && ticker.ask != -1.0d) {
            ticker.last = (ticker.bid + ticker.ask) / 2.0d;
        } else if (ticker.bid != -1.0d) {
            ticker.last = ticker.bid;
        } else if (ticker.ask != -1.0d) {
            ticker.last = ticker.ask;
        } else {
            ticker.last = 0.0d;
        }
    }
}
