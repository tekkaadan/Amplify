package com.tekhnical.amplify.model;

import android.text.TextUtils;

import com.tekhnical.amplify.util.TimeUtils;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

import org.json.JSONObject;

public abstract class Market implements Serializable {
    public HashMap<String, String[]> currencyPairs;
    public final String key;
    public final String name;
    public final String ttsName;
    private int imageUrl;
    private boolean isStock = false;
    public abstract String getUrl(int i, CheckerInfo checkerInfo);

    public Market(String id,String name2, String ttsName2, HashMap<String, String[]> currencyPairs2) {
        this.key = id;
        this.name = name2;
        this.ttsName = ttsName2;
        this.currencyPairs = currencyPairs2;
    }

    public boolean isStock() {
        return isStock;
    }

    public void setStock(boolean stock) {
        isStock = stock;
    }

    public String getKey() {
        return key;
    }

    public int getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(int imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getCautionResId() {
        return 0;
    }

    public int getNumOfRequests(CheckerInfo checkerInfo) {
        return 1;
    }

    public final Ticker parseTickerMain(int requestId, String responseString, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        parseTicker(requestId, responseString, ticker, checkerInfo);
        if (ticker.timestamp <= 0) {
            ticker.timestamp = System.currentTimeMillis();
        } else {
            ticker.timestamp = TimeUtils.parseTimeToMillis(ticker.timestamp);
        }
        return ticker;
    }

    public void parseTicker(int requestId, String responseString, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        parseTickerFromJsonObject(requestId, new JSONObject(responseString), ticker, checkerInfo);
    }

    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        /*JSONArray tickerJsonArray = jsonObject.getJSONArray("tickers");
        for (int i = 0; i < tickerJsonArray.length(); i++) {
            JSONObject tickerJsonObject = tickerJsonArray.getJSONObject(i);
            if(tickerJsonObject.getString("base").equals(checkerInfo.getCurrencyBase()) && tickerJsonObject.getString("target").equals(checkerInfo.getCurrencyCounter())){
                ticker.bid = ParseUtils.getDoubleFromString(tickerJsonObject,"buy");
                ticker.ask = ParseUtils.getDoubleFromString(tickerJsonObject,"sell");
                ticker.vol = ParseUtils.getDoubleFromString(tickerJsonObject,"vol");
                ticker.high = ParseUtils.getDoubleFromString(tickerJsonObject,"high");
                ticker.low = ParseUtils.getDoubleFromString(tickerJsonObject,"low");
                ticker.last = ParseUtils.getDoubleFromString(tickerJsonObject,"last");
                if(tickerJsonObject.has("timestamp"))
                    ticker.timestamp = tickerJsonObject.getLong("timestamp") * 1000;
            }
        }*/

    }

    public final String parseErrorMain(int requestId, String responseString, CheckerInfo checkerInfo) throws Exception {
        return parseError(requestId, responseString, checkerInfo);
    }

    public String parseError(int requestId, String responseString, CheckerInfo checkerInfo) throws Exception {
        return parseErrorFromJsonObject(requestId, new JSONObject(responseString), checkerInfo);
    }

    public String parseErrorFromJsonObject(int requestId, JSONObject jsonObject, CheckerInfo checkerInfo) throws Exception {
        throw new Exception();
    }

    public int getCurrencyPairsNumOfRequests() {
        return 1;
    }

    public String getCurrencyPairsUrl(int requestId) {
        return null;
    }

    public final void parseCurrencyPairsMain(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        parseCurrencyPairs(requestId, responseString, pairs);
        for (int i = pairs.size() - 1; i >= 0; i--) {
            CurrencyPairInfo currencyPairInfo = (CurrencyPairInfo) pairs.get(i);
            if (currencyPairInfo == null || TextUtils.isEmpty(currencyPairInfo.getCurrencyBase()) || TextUtils.isEmpty(currencyPairInfo.getCurrencyCounter())) {
                pairs.remove(i);
            }
        }
    }

    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        parseCurrencyPairsFromJsonObject(requestId, new JSONObject(responseString), pairs);
    }

    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> list) throws Exception {
        /*JSONArray resultJsonArray = jsonObject.getJSONArray("tickers");
        for (int i = 0; i < resultJsonArray.length(); i++) {
            String base = resultJsonArray.getJSONObject(i).getString("base");
            String target = resultJsonArray.getJSONObject(i).getString("target");
            list.add(new CurrencyPairInfo(base,target, base+target));
        }*/
    }
}
