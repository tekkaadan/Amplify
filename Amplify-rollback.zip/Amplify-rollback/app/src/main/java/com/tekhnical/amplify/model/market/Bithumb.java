package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import org.json.JSONArray;
import org.json.JSONObject;

public class Bithumb extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Bithumb";
    private static final String TTS_NAME = "Bithumb";
    private static final String URL_ORDERS = "https://api.bithumb.com/public/orderbook/%1$s?count=1";
    private static final String URL_TICKER = "https://api.bithumb.com/public/ticker/%1$s";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{Currency.KRW});
        CURRENCY_PAIRS.put(VirtualCurrency.ETH, new String[]{Currency.KRW});
        CURRENCY_PAIRS.put(VirtualCurrency.ETC, new String[]{Currency.KRW});
        CURRENCY_PAIRS.put(VirtualCurrency.DASH, new String[]{Currency.KRW});
        CURRENCY_PAIRS.put(VirtualCurrency.LTC, new String[]{Currency.KRW});
        CURRENCY_PAIRS.put(VirtualCurrency.XRP, new String[]{Currency.KRW});
        CURRENCY_PAIRS.put(VirtualCurrency.BCH, new String[]{Currency.KRW});
        CURRENCY_PAIRS.put(VirtualCurrency.XMR, new String[]{Currency.KRW});
        CURRENCY_PAIRS.put(VirtualCurrency.ZEC, new String[]{Currency.KRW});
        CURRENCY_PAIRS.put(VirtualCurrency.QTUM, new String[]{Currency.KRW});
    }

    public Bithumb() {
        super("bithumb",NAME,TTS_NAME, CURRENCY_PAIRS);
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Bithumb.png";
        //return "https://assets.coingecko.com/markets/images/6/small/bithumb_BI.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bithumb;
    }
    public int getNumOfRequests(CheckerInfo checkerRecord) {
        return 2;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        if (requestId == 0) {
            return String.format(URL_TICKER, new Object[]{checkerInfo.getCurrencyBaseLowerCase()});
        }
        return String.format(URL_ORDERS, new Object[]{checkerInfo.getCurrencyBaseLowerCase()});
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject dataObject = jsonObject.getJSONObject("data");
        if (requestId == 0) {
            ticker.vol = ParseUtils.getDoubleFromString(dataObject,"volume_1day");
            ticker.high = ParseUtils.getDoubleFromString(dataObject,"max_price");
            ticker.low = ParseUtils.getDoubleFromString(dataObject,"min_price");
            ticker.last = ParseUtils.getDoubleFromString(dataObject,"closing_price");
            ticker.timestamp = ParseUtils.getLongFromString(dataObject,"date");
            return;
        }
        ticker.bid = getFirstPriceFromOrder(dataObject, "bids");
        ticker.ask = getFirstPriceFromOrder(dataObject, "asks");
    }

    @Override
    public String parseErrorFromJsonObject(int requestId, JSONObject jsonObject, CheckerInfo checkerInfo) throws Exception {
        return jsonObject.getString("message");
    }

    private double getFirstPriceFromOrder(JSONObject jsonObject, String key) throws Exception {
        JSONArray array = jsonObject.getJSONArray(key);
        if (array.length() == 0) {
            return -1.0d;
        }
        return ParseUtils.getDoubleFromString(array.getJSONObject(0),"price");
    }
}
