package com.tekhnical.amplify.fragment;

import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import android.database.Cursor;
import android.os.Bundle;

import android.view.View;
import android.widget.ListView;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.adapter.CheckerAlarmsListAdapter;
import com.tekhnical.amplify.fragment.generic.ActionModeListFragment;
import com.tekhnical.amplify.content.AlarmRecord;
import com.tekhnical.amplify.content.MaindbContract.Alarm;

public class CheckerAlarmsListFragment extends ActionModeListFragment<Cursor> implements LoaderManager.LoaderCallbacks<Cursor> {
    private CheckerAlarmsListAdapter adapter;

    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setHasOptionsMenu(true);
        setListAdapter(this.adapter);
        setListShownNoAnimation(false);
        setEmptyText(getString(R.string.checker_alarms_list_empty_text));
        getListView().setDividerHeight(0);
        getListView().setDivider(null);
        getListView().setSelector(R.drawable.list_selector_background_transition_holo_light);
        enableActionModeOrContextMenu();
        getLoaderManager().initLoader(0, null, this);
    }

    public void onListItemClick(ListView l, View v, int position, long id) {
    }

    private void deleteCheckerAlarmRecord(Cursor cursor, boolean refresh) {
        AlarmRecord.fromCursor(cursor).delete(refresh);
    }

    @Override
    public int getActionModeOrContextMenuResId() {
        return R.menu.checker_alarms_list_fragment_cab;
    }

    @Override
    public boolean onActionModeOrContextMenuItemClicked(int menuItemId, Cursor checkedItem, int listItemPosition, int checkedItemsCount, boolean isForLastItem) {
        switch (menuItemId) {
            case R.id.deleteItem:
                deleteCheckerAlarmRecord(checkedItem, isForLastItem);
                return true;
            default:
                return super.onActionModeOrContextMenuItemClicked(menuItemId, checkedItem, listItemPosition, checkedItemsCount, isForLastItem);
        }
    }

    private void setNewList(Cursor cursor) {
        if (getView() != null && getActivity() != null) {
            setListShown(true);
        }
    }

    public Loader<Cursor> onCreateLoader(int arg0, Bundle arg1) {
        return new CursorLoader(getActivity(), Alarm.CONTENT_URI, AlarmRecord.PROJECTION, null, null, null);
    }

    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        setNewList(cursor);
    }

    public void onLoaderReset(Loader<Cursor> loader) {
        setNewList(null);
    }
}
