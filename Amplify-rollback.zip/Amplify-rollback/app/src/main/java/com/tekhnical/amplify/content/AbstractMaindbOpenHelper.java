package com.tekhnical.amplify.content;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import com.tekhnical.amplify.content.migrations.DefaultMaindbMigrationV1;
import com.tekhnical.amplify.content.migrations.DefaultMaindbMigrationV10;
import com.tekhnical.amplify.content.migrations.DefaultMaindbMigrationV11;
import com.tekhnical.amplify.content.migrations.DefaultMaindbMigrationV12;
import com.tekhnical.amplify.content.migrations.DefaultMaindbMigrationV2;
import com.tekhnical.amplify.content.migrations.DefaultMaindbMigrationV3;
import com.tekhnical.amplify.content.migrations.DefaultMaindbMigrationV4;
import com.tekhnical.amplify.content.migrations.DefaultMaindbMigrationV5;
import com.tekhnical.amplify.content.migrations.DefaultMaindbMigrationV6;
import com.tekhnical.amplify.content.migrations.DefaultMaindbMigrationV7;
import com.tekhnical.amplify.content.migrations.DefaultMaindbMigrationV8;
import com.tekhnical.amplify.content.migrations.DefaultMaindbMigrationV9;
import com.robotoworks.mechanoid.db.MechanoidSQLiteOpenHelper;
import com.robotoworks.mechanoid.db.SQLiteMigration;

public abstract class AbstractMaindbOpenHelper extends MechanoidSQLiteOpenHelper {
    private static final String DATABASE_NAME = "maindb.db";
    public static final int VERSION = 12;

    public interface Sources {
        public static final String ALARM = "alarm";
        public static final String CHECKER = "checker";
    }

    public AbstractMaindbOpenHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    public AbstractMaindbOpenHelper(Context context, String name) {
        super(context, name, null, VERSION);
    }

    public void onCreate(SQLiteDatabase db) {
        applyMigrations(db, 0, VERSION);
    }

    public SQLiteMigration createMigration(int version) {
        switch (version) {
            case 0:
                return createMaindbMigrationV1();
            case 1:
                return createMaindbMigrationV2();
            case 2:
                return createMaindbMigrationV3();
            case 3:
                return createMaindbMigrationV4();
            case 4:
                return createMaindbMigrationV5();
            case 5:
                return createMaindbMigrationV6();
            case 6:
                return createMaindbMigrationV7();
            case 7:
                return createMaindbMigrationV8();
            case 8:
                return createMaindbMigrationV9();
            case 9:
                return createMaindbMigrationV10();
            case 10:
                return createMaindbMigrationV11();
            case 11:
                return createMaindbMigrationV12();
            default:
                throw new IllegalStateException("No migration for version " + version);
        }
    }

    private SQLiteMigration createMaindbMigrationV1() {
        return new DefaultMaindbMigrationV1();
    }

    private SQLiteMigration createMaindbMigrationV2() {
        return new DefaultMaindbMigrationV2();
    }

    private SQLiteMigration createMaindbMigrationV3() {
        return new DefaultMaindbMigrationV3();
    }

    private SQLiteMigration createMaindbMigrationV4() {
        return new DefaultMaindbMigrationV4();
    }

    private SQLiteMigration createMaindbMigrationV5() {
        return new DefaultMaindbMigrationV5();
    }

    private SQLiteMigration createMaindbMigrationV6() {
        return new DefaultMaindbMigrationV6();
    }

    private SQLiteMigration createMaindbMigrationV7() {
        return new DefaultMaindbMigrationV7();
    }

    private SQLiteMigration createMaindbMigrationV8() {
        return new DefaultMaindbMigrationV8();
    }

    private SQLiteMigration createMaindbMigrationV9() {
        return new DefaultMaindbMigrationV9();
    }

    private SQLiteMigration createMaindbMigrationV10() {
        return new DefaultMaindbMigrationV10();
    }
    private SQLiteMigration createMaindbMigrationV11() {
        return new DefaultMaindbMigrationV11();
    }
    private SQLiteMigration createMaindbMigrationV12() {
        return new DefaultMaindbMigrationV12();
    }
}
