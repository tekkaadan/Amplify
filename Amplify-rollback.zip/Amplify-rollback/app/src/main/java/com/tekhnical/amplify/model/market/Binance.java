package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class Binance extends Market {
    private static final String[] COUNTER_CURRENCIES = {VirtualCurrency.BNB, VirtualCurrency.BTC, VirtualCurrency.ETH, VirtualCurrency.USDT, VirtualCurrency.BUSD, VirtualCurrency.AUD,VirtualCurrency.TRX,VirtualCurrency.ZAR};
    private static final String NAME = "Binance";
    private static final String TTS_NAME = "Binance";
    private static final String URL = "https://api.binance.com/api/v1/ticker/24hr?symbol=%1$s";
    private static final String URL_CURRENCY_PAIRS = "https://api.binance.com/api/v1/ticker/allPrices";

    public Binance() {
        super("binance",NAME, TTS_NAME, null);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        //return "https://assets.coingecko.com/markets/images/52/small/binance.jpg";
        return "file:///android_asset/logos/Binance.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.binance;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject,"bidPrice");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject,"askPrice");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject,"volume");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject,"highPrice");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject,"lowPrice");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject,"lastPrice");
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        String[] strArr;
        JSONArray resultJsonArray = new JSONArray(responseString);
        for (int i = 0; i < resultJsonArray.length(); i++) {
            String symbol = resultJsonArray.getJSONObject(i).getString("symbol");
            for (String counter : COUNTER_CURRENCIES) {
                if (symbol.endsWith(counter)) {
                    pairs.add(new CurrencyPairInfo(symbol.substring(0, symbol.lastIndexOf(counter)), counter, symbol));
                }
            }
        }
    }
}
