package com.tekhnical.amplify.view.generic;

import android.annotation.TargetApi;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.NumberPicker;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.dialog.CustomDialog;

public class ViewNumberPickerPreference extends ViewDialogPreference {
    private OnValueChangedListener onValueSelectedListener;
    private int value = -1;
    private String valueSufix;

    public interface OnValueChangedListener {
        boolean onValueChanged(ViewNumberPickerPreference viewNumberPickerPreference, int i);
    }

    public ViewNumberPickerPreference(Context context) {
        super(context);
    }

    public ViewNumberPickerPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @TargetApi(11)
    public ViewNumberPickerPreference(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public String getEntry() {
        return String.valueOf(getValue()) + (this.valueSufix != null ? this.valueSufix : "");
    }

    public void setValue(int value2) {
        if (getValue() != value2 && (this.onValueSelectedListener == null || this.onValueSelectedListener.onValueChanged(this, value2))) {
            this.value = value2;
        }
        setSummary(getEntry());
    }

    public int getValue() {
        return this.value;
    }

    public void setValueSufix(String valueSufix2) {
        this.valueSufix = valueSufix2;
    }

    @Override
    public void onPrepareDialog(CustomDialog builder) {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.number_picker_dialog, null);
        final NumberPicker numberPicker = (NumberPicker) view.findViewById(R.id.pref_num_picker);
        numberPicker.setMinValue(1);
        numberPicker.setMaxValue(100);
        numberPicker.setValue(getValue());
        builder.setPositiveButton(getResources().getString(R.string.ok), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numberPicker.clearFocus();
                ViewNumberPickerPreference.this.setValue(numberPicker.getValue());
                builder.dismiss();
            }
        });
        builder.setView(view);
    }

    public void setOnValueChangedListener(OnValueChangedListener onValueSelectedListener2) {
        this.onValueSelectedListener = onValueSelectedListener2;
    }
}
