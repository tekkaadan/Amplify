package com.tekhnical.amplify.model.currency;

public class CurrencyModel{
    public String id, symbol, name;

    public CurrencyModel(String id, String symbol, String name) {
        this.id = id;
        this.symbol = symbol;
        this.name = name;
    }
}
