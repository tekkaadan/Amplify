package com.tekhnical.amplify.util;

import android.content.Context;
import android.content.res.AssetManager;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CurrencySubunit;
import com.tekhnical.amplify.model.CurrencySubunitsMap;
import com.tekhnical.amplify.model.currency.CurrenciesSubunits;
import com.tekhnical.amplify.model.currency.CurrencySymbols;
import com.tekhnical.amplify.model.currency.VirtualCurrency;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class CurrencyUtils {
    public static String getCurrencySymbol(String currency) {
        return CurrencySymbols.CURRENCY_SYMBOLS.containsKey(currency) ? (String) CurrencySymbols.CURRENCY_SYMBOLS.get(currency) : currency;
    }
    public static CurrencySubunit getCurrencySubunit(String currency, long subunitToUnit) {
        if (subunitToUnit == -2){
            return new CurrencySubunit("USD",1);
        }else {
            if (CurrenciesSubunits.CURRENCIES_SUBUNITS.containsKey(currency)) {
                CurrencySubunitsMap subunits = (CurrencySubunitsMap) CurrenciesSubunits.CURRENCIES_SUBUNITS.get(currency);
                if (subunits.containsKey(Long.valueOf(subunitToUnit))) {
                    return (CurrencySubunit) subunits.get(Long.valueOf(subunitToUnit));
                }
            }
            return new CurrencySubunit(currency, 1);
        }
    }
    public static String getCurrencyAsset(Context context, String currency){
        AssetManager manager = context.getAssets();
        try {
            List<String> mapList = Arrays.asList(manager.list("icons"));
            String iconName = "icon_"+currency.toLowerCase()+".svg";
            if (mapList.contains(iconName)){
                return "file:///android_asset/icons/"+iconName;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    public static int getCurrencyIcon(String currency){
        switch (currency.toUpperCase()){
            case VirtualCurrency.BTC : return R.drawable.icon_bitcoin;
            case VirtualCurrency.ETH : return R.drawable.icon_eth;
            case VirtualCurrency.LINK : return R.drawable.icon_link;
            case VirtualCurrency.TRX : return R.drawable.icon_tron;
            case VirtualCurrency.BUSD : return R.drawable.icon_busd;
            case VirtualCurrency.LTC : return R.drawable.icon_ltc;
            case VirtualCurrency.EOS : return R.drawable.icon_eos;
            case VirtualCurrency.USDT : return R.drawable.icon_usdt;
            case VirtualCurrency.ADA : return R.drawable.icon_ada;
            case VirtualCurrency.DOT : return R.drawable.icon_dot;
            case VirtualCurrency.XRP : return R.drawable.icon_ripple;
            case VirtualCurrency.UNI : return R.drawable.icon_uni;
            case VirtualCurrency.BNB : return R.drawable.icon_bnb;
            case VirtualCurrency.BCH : return R.drawable.icon_bch;
            case VirtualCurrency.XLM : return R.drawable.icon_xlm;
            case VirtualCurrency.USDC : return R.drawable.icon_usdc;
            case VirtualCurrency.DOGE : return R.drawable.icon_doge;
            case VirtualCurrency.XEM : return R.drawable.icon_xem;
            case VirtualCurrency.WBTC : return R.drawable.icon_wbtc;
            case VirtualCurrency.THETA : return R.drawable.icon_theta;
            case VirtualCurrency.ATOM : return R.drawable.icon_atom;
            case VirtualCurrency.MIOTA : return R.drawable.icon_iota;
            case VirtualCurrency.IOTA : return R.drawable.icon_iota;
            case VirtualCurrency.ALGO : return R.drawable.icon_algo;
            case VirtualCurrency.XMR : return R.drawable.icon_xmr;
            case VirtualCurrency.BSV : return R.drawable.icon_bsv;
            case VirtualCurrency.SNX : return R.drawable.icon_snx;
            case VirtualCurrency.FTT : return R.drawable.icon_ftx;
            case VirtualCurrency.VET : return R.drawable.icon_vet;
            case VirtualCurrency.LUNA : return R.drawable.icon_lun;
            case VirtualCurrency.CRO : return R.drawable.icon_cro;
            case VirtualCurrency.AVAX : return R.drawable.icon_avax;
            case VirtualCurrency.SOL : return R.drawable.icon_sol;
            case VirtualCurrency.XTZ : return R.drawable.icon_xtz;
            case VirtualCurrency.HT : return R.drawable.icon_ht;
            case VirtualCurrency.NEO : return R.drawable.icon_neo;
            case VirtualCurrency.CDAI : return R.drawable.icon_cdai;
            case VirtualCurrency.EGLD : return R.drawable.icon_egld;
            case VirtualCurrency.KSM : return R.drawable.icon_ksm;
            case VirtualCurrency.CETH : return R.drawable.icon_ceth;
            case VirtualCurrency.GRT : return R.drawable.icon_grt;
            case VirtualCurrency.SUSHI : return R.drawable.icon_sushi;
            case VirtualCurrency.FIL : return R.drawable.icon_fil;
            case VirtualCurrency.COMP : return R.drawable.icon_comp;
            case VirtualCurrency.DASH : return R.drawable.icon_dash;
            case VirtualCurrency.LEO : return R.drawable.icon_leo;
            case VirtualCurrency.DCR : return R.drawable.icon_dcr;
            case VirtualCurrency.ZEC : return R.drawable.icon_zec;
            case VirtualCurrency.ZIL : return R.drawable.icon_zil;
            case VirtualCurrency.ETC : return R.drawable.icon_etc;
            case VirtualCurrency.RVN : return R.drawable.icon_rvn;
            case VirtualCurrency.BTS : return R.drawable.ic_bitshares;
            case VirtualCurrency.CUSDC : return R.drawable.icon_cusdc;
            case VirtualCurrency.CEL : return R.drawable.icon_cel;
            case VirtualCurrency.MKR : return R.drawable.icon_mkr;
            case VirtualCurrency.COTI : return R.drawable.icon_coti;

            case VirtualCurrency.ABT : return R.drawable.icon_abt;
            case VirtualCurrency.ACT : return R.drawable.icon_act;
            case VirtualCurrency.ACTN : return R.drawable.icon_actn;
            case VirtualCurrency.ADD : return R.drawable.icon_add;
            case VirtualCurrency.ADX : return R.drawable.icon_adx;
            case VirtualCurrency.AE : return R.drawable.icon_ae;
            case VirtualCurrency.AEON : return R.drawable.icon_aeon;
            case VirtualCurrency.AEUR : return R.drawable.icon_aeur;
            case VirtualCurrency.AGI : return R.drawable.icon_agi;
            case VirtualCurrency.AGRS : return R.drawable.icon_agrs;
            case VirtualCurrency.AION : return R.drawable.icon_aion;
            case VirtualCurrency.AMB : return R.drawable.icon_amb;
            case VirtualCurrency.AMP : return R.drawable.icon_amp;
            case VirtualCurrency.AMPL : return R.drawable.icon_ampl;
            case VirtualCurrency.ANT : return R.drawable.icon_ant;
            case VirtualCurrency.APEX : return R.drawable.icon_apex;
            case VirtualCurrency.APPC : return R.drawable.icon_appc;
            case VirtualCurrency.ARDR : return R.drawable.icon_ardr;
            case VirtualCurrency.ARG : return R.drawable.icon_arg;
            case VirtualCurrency.ARK : return R.drawable.icon_ark;
            case VirtualCurrency.ARN : return R.drawable.icon_arn;
            case VirtualCurrency.ARNX : return R.drawable.icon_arnx;
            case VirtualCurrency.ARY : return R.drawable.icon_ary;
            case VirtualCurrency.AST : return R.drawable.icon_ast;
            case VirtualCurrency.ATM : return R.drawable.icon_atm;
            case VirtualCurrency.AUDR : return R.drawable.icon_audr;
            case VirtualCurrency.AUTO : return R.drawable.icon_auto;
            case VirtualCurrency.AYWA : return R.drawable.icon_aywa;
            case VirtualCurrency.BAB : return R.drawable.icon_bab;
            case VirtualCurrency.BAL : return R.drawable.icon_bal;
            case VirtualCurrency.BAND : return R.drawable.icon_band;
            case VirtualCurrency.BAT : return R.drawable.icon_bat;
            case VirtualCurrency.BAY : return R.drawable.icon_bay;
            case VirtualCurrency.BCBC : return R.drawable.icon_bcbc;
            case VirtualCurrency.BCC : return R.drawable.icon_bcc;
            case VirtualCurrency.BCD : return R.drawable.icon_bcd;
            case VirtualCurrency.BCIO : return R.drawable.icon_bcio;
            case VirtualCurrency.BCN : return R.drawable.icon_bcn;
            case VirtualCurrency.BCO : return R.drawable.icon_bco;
            case VirtualCurrency.BCPT : return R.drawable.icon_bcpt;
            case VirtualCurrency.BDL : return R.drawable.icon_bdl;
            case VirtualCurrency.BEAM : return R.drawable.icon_beam;
            case VirtualCurrency.BELA : return R.drawable.icon_bela;
            case VirtualCurrency.BIX : return R.drawable.icon_bix;
            case VirtualCurrency.BLCN : return R.drawable.icon_blcn;
            case VirtualCurrency.BLK : return R.drawable.icon_blk;
            case VirtualCurrency.BLOCK : return R.drawable.icon_block;
            case VirtualCurrency.BLZ : return R.drawable.icon_blz;
            case VirtualCurrency.BNT : return R.drawable.icon_bnt;
            case VirtualCurrency.BNTY : return R.drawable.icon_bnty;
            case VirtualCurrency.BOOTY : return R.drawable.icon_booty;
            case VirtualCurrency.BOS : return R.drawable.icon_bos;
            case VirtualCurrency.BPT : return R.drawable.icon_bpt;
            case VirtualCurrency.BQ : return R.drawable.icon_bq;
            case VirtualCurrency.BRD : return R.drawable.icon_brd;
            case VirtualCurrency.BSD : return R.drawable.icon_bsd;
            case VirtualCurrency.BTCD : return R.drawable.icon_btcd;
            case VirtualCurrency.BZE : return R.drawable.icon_bze;
            case VirtualCurrency.CALL : return R.drawable.icon_call;
            case VirtualCurrency.CC : return R.drawable.icon_cc;
            case VirtualCurrency.CDN : return R.drawable.icon_cdn;
            case VirtualCurrency.CDT : return R.drawable.icon_cdt;
            case VirtualCurrency.CENZ : return R.drawable.icon_cenz;
            case VirtualCurrency.CHAIN : return R.drawable.icon_chain;
            case VirtualCurrency.CHAT : return R.drawable.icon_chat;
            case VirtualCurrency.CHIPS : return R.drawable.icon_chips;
            case VirtualCurrency.CIX : return R.drawable.icon_cix;
            case VirtualCurrency.CLAM : return R.drawable.icon_clam;
            case VirtualCurrency.CLOAK : return R.drawable.icon_cloak;
            case VirtualCurrency.CMM : return R.drawable.icon_cmm;
            case VirtualCurrency.CMT : return R.drawable.icon_cmt;
            case VirtualCurrency.CND : return R.drawable.icon_cnd;
            case VirtualCurrency.CNX : return R.drawable.icon_cnx;
            case VirtualCurrency.CNY : return R.drawable.icon_cny;
            case VirtualCurrency.COB : return R.drawable.icon_cob;
            case VirtualCurrency.COLX : return R.drawable.icon_colx;
            case VirtualCurrency.COQUI : return R.drawable.icon_coqui;
            case VirtualCurrency.CRED : return R.drawable.icon_cred;
            case VirtualCurrency.CRPT : return R.drawable.icon_crpt;
            case VirtualCurrency.CRW : return R.drawable.icon_crw;
            case VirtualCurrency.CS : return R.drawable.icon_cs;
            case VirtualCurrency.CTR : return R.drawable.icon_ctr;
            case VirtualCurrency.CTXC : return R.drawable.icon_ctxc;
            case VirtualCurrency.CVC : return R.drawable.icon_cvc;
            case VirtualCurrency.D : return R.drawable.icon_d;
            case VirtualCurrency.DAI : return R.drawable.icon_dai;
            case VirtualCurrency.DAT : return R.drawable.icon_dat;
            case VirtualCurrency.DBC : return R.drawable.icon_dbc;
            case VirtualCurrency.DCN : return R.drawable.icon_dcn;
            case VirtualCurrency.DEEZ : return R.drawable.icon_deez;
            case VirtualCurrency.DENT : return R.drawable.icon_dent;
            case VirtualCurrency.DEW : return R.drawable.icon_dew;
            case VirtualCurrency.DGB : return R.drawable.icon_dgb;
            case VirtualCurrency.DGD : return R.drawable.icon_dgd;
            case VirtualCurrency.DLT : return R.drawable.icon_dlt;
            case VirtualCurrency.DNT : return R.drawable.icon_dnt;
            case VirtualCurrency.DOCK : return R.drawable.icon_dock;
            case VirtualCurrency.DRGN : return R.drawable.icon_drgn;
            case VirtualCurrency.DROP : return R.drawable.icon_drop;
            case VirtualCurrency.DTA : return R.drawable.icon_dta;
            case VirtualCurrency.DTH : return R.drawable.icon_dth;
            case VirtualCurrency.DTR : return R.drawable.icon_dtr;
            case VirtualCurrency.EBST : return R.drawable.icon_ebst;
            case VirtualCurrency.ECA : return R.drawable.icon_eca;
            case VirtualCurrency.EDG : return R.drawable.icon_edg;
            case VirtualCurrency.EDO : return R.drawable.icon_edo;
            case VirtualCurrency.EDOGE : return R.drawable.icon_edoge;
            case VirtualCurrency.ELA : return R.drawable.icon_ela;
            case VirtualCurrency.ELEC : return R.drawable.icon_elec;
            case VirtualCurrency.ELF : return R.drawable.icon_elf;
            case VirtualCurrency.ELIX : return R.drawable.icon_elix;
            case VirtualCurrency.ELLA : return R.drawable.icon_ella;
            case VirtualCurrency.EMC : return R.drawable.icon_emc;
            case VirtualCurrency.EMC2 : return R.drawable.icon_emc2;
            case VirtualCurrency.ENG : return R.drawable.icon_eng;
            case VirtualCurrency.ENJ : return R.drawable.icon_enj;

            default:
                return R.drawable.amplify_icon;
        }
    }
}
