package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.currency.VirtualCurrency;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class Unknown extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "UNKNOWN";
    private static final String TTS_NAME = "UNKNOWN";
    private static final String URL = "";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{VirtualCurrency.BTC});
    }

    public Unknown() {
        super("UNKNOWN","UNKNOWN", "UNKNOWN", CURRENCY_PAIRS);
    }

    public int getCautionResId() {
        return R.string.market_caution_unknown;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return "";
    }
}
