package com.tekhnical.amplify.adapter;

import android.app.Activity;
import android.content.Context;
import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.BaseAdapter;
import android.widget.CheckedTextView;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.util.PreferencesUtils;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public class MarketPickerListAdapter extends BaseAdapter implements Filterable, OnItemLongClickListener {
    private final int checkMarkDrawableResId;
    private final Context context;
    private List<Market> filteredItems = null;
    private List<Market> items = null;
    private String marketDefault;
    private String searchQuery;
    private final String selectedMarketKey;

    public MarketPickerListAdapter(Activity context, String selectedMarketKey) {
        this.context = context;
        this.selectedMarketKey = selectedMarketKey;
        this.marketDefault = PreferencesUtils.getMarketDefault(context);
        TypedValue value = new TypedValue();
        context.getTheme().resolveAttribute(R.attr.selectableItemBackground, value, true);
        this.checkMarkDrawableResId = value.resourceId;
    }

    public void swapItems(List<Market> items2) {
        this.items = items2;
        this.filteredItems = items2;
        notifyDataSetChanged();
    }

    public int getCount() {
        if (this.filteredItems != null) {
            return this.filteredItems.size();
        }
        return 0;
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public Market getItem(int position) {
        if (position < this.filteredItems.size()) {
            return (Market) this.filteredItems.get(position);
        }
        return null;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        CharSequence name;
        boolean z = false;
        if (convertView == null) {
            convertView = LayoutInflater.from(this.context).inflate(R.layout.market_picker_list_singlechoice, parent, false);
        }
        TextView marketNameView = (TextView) convertView.findViewById(R.id.marketNameView);
        TextView defaultView = (TextView) convertView.findViewById(R.id.defaultView);
        CheckedTextView singleCheckView = (CheckedTextView) convertView.findViewById(R.id.singleCheckView);
        Market market = getItem(position);
        if (market != null) {
            if (!TextUtils.isEmpty(this.searchQuery)) {
                name = Html.fromHtml(market.name.replaceAll("(?i)(" + Pattern.quote(this.searchQuery) + ")", "<b>$1</b>"));
            } else {
                name = market.name;
            }
            marketNameView.setText(name);
            if (market.key.equals(this.marketDefault)) {
                defaultView.setVisibility(View.VISIBLE);
            } else {
                defaultView.setVisibility(View.GONE);
            }
            if (market.key != null && market.key.equals(this.selectedMarketKey)) {
                z = true;
            }
            singleCheckView.setChecked(z);
            singleCheckView.setCheckMarkDrawable(this.checkMarkDrawableResId);
        } /*else {
            marketNameView.setText(R.string.checker_add_check_market_suggest_more);
            defaultView.setVisibility(View.GONE);
            singleCheckView.setChecked(false);
            singleCheckView.setCheckMarkDrawable(android.R.drawable.radiobutton_off_background);
        }*/
        return convertView;
    }

    public Filter getFilter() {
        return new Filter() {
            @Override
            public FilterResults performFiltering(CharSequence newSearchQuery) {
                MarketPickerListAdapter.this.searchQuery = (String) newSearchQuery;
                FilterResults filterResults = new FilterResults();
                ArrayList<Market> markets = new ArrayList<>();
                if (TextUtils.isEmpty(MarketPickerListAdapter.this.searchQuery)) {
                    markets.addAll(MarketPickerListAdapter.this.items);
                } else {
                    for (Market market : MarketPickerListAdapter.this.items) {
                        if (market.name.toLowerCase().contains(MarketPickerListAdapter.this.searchQuery.toLowerCase())) {
                            markets.add(market);
                        }
                    }
                }
                filterResults.values = markets;
                return filterResults;
            }

            @Override
            public void publishResults(CharSequence newSearchQuery, FilterResults results) {
                MarketPickerListAdapter.this.filteredItems = (ArrayList) results.values;
                MarketPickerListAdapter.this.notifyDataSetChanged();
            }
        };
    }

    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
        if (getItem(position) == null) {
            return false;
        }
        this.marketDefault = getItem(position).key;
        PreferencesUtils.setMarketDefault(this.context, this.marketDefault);
        notifyDataSetChanged();
        return true;
    }
}
