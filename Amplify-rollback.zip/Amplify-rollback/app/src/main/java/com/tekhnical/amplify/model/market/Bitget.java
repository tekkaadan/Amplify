package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Bitget extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Bitget";
    private static final String TTS_NAME = "Bitget";
    private static final String URL = "https://capi.bitget.com/api/swap/v3/market/ticker?symbol=%1$s";
    private static final String CURRENCIES_URL = "https://capi.bitget.com/api/swap/v3/market/contracts";

    public Bitget() {
        super("bitget", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Bitget.png";
        //return "https://assets.coingecko.com/markets/images/540/small/bitget-logo-1.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bitget;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        // JSONObject jsonObject = tickerObject.getJSONObject(checkerInfo.getCurrencyPairId());
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "best_bid");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "best_ask");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject, "last");
        ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high_24h");
        ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low_24h");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "volume_24h");
        if (jsonObject.has("timestamp"))
            ticker.timestamp = Long.parseLong(jsonObject.getString("timestamp"));
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("symbol")){
                pairs.add(new CurrencyPairInfo(jsonObject.getString("coin"),jsonObject.getString("quote_currency"),jsonObject.getString("symbol")));
            }
        }
    }

}
