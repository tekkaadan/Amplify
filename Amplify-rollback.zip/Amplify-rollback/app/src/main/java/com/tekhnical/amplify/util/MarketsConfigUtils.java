package com.tekhnical.amplify.util;

import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.config.MarketsConfig;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.StockMarket;
import com.tekhnical.amplify.model.market.Unknown;

import java.util.ArrayList;

public class MarketsConfigUtils {
    private static final Market UNKNOWN = new Unknown();

    public static Market getMarketById(int r3) {
            if (r3 > 0){
                if (MyApplication.appMarketType == 1){
                    if (r3 < MarketsConfig.FUTURE_MARKETS.size()) {
                        return new ArrayList<>(MarketsConfig.FUTURE_MARKETS.values()).get(r3);
                    } else {
                        return UNKNOWN;
                    }
                }
                else {
                    if (r3 < MarketsConfig.MARKETS.size()) {
                        return new ArrayList<>(MarketsConfig.MARKETS.values()).get(r3);
                    } else {
                        return UNKNOWN;
                    }
                }
            }else
                return UNKNOWN;

    }

    public static Market getMarketByKey(String key) {
        synchronized (MarketsConfig.MARKETS) {
            if (!MarketsConfig.MARKETS.containsKey(key)) {
                if (MarketsConfig.FUTURE_MARKETS.containsKey(key))
                    return MarketsConfig.FUTURE_MARKETS.get(key);
                else
                    return new StockMarket(key,key,key,null);
            }
            Market market = (Market) MarketsConfig.MARKETS.get(key);
            return market;
        }
    }

    public static int getMarketIdByKey(String key) {
        int i = 0;
        for (Market market : MarketsConfig.MARKETS.values()) {
            if (market.key.equals(key)) {
                return i;
            }
            i++;
        }
        return 0;
    }
}
