package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.Currency;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import org.json.JSONObject;

public class BitFlyer extends Market {
    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "bitFlyer";
    private static final String TTS_NAME = "bit flyer";
    private static final String URL = "https://api.bitflyer.jp/v1/ticker?product_code=%1$s_%2$s";

    static {
        CURRENCY_PAIRS.put(VirtualCurrency.BTC, new String[]{Currency.JPY});
        CURRENCY_PAIRS.put(VirtualCurrency.ETH, new String[]{VirtualCurrency.BTC});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/BitFLYER.png";
        //return "https://assets.coingecko.com/markets/images/5/small/bitflyer.jpg";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bitflyer;
    }
    public BitFlyer() {
        super("bitflyer",NAME, TTS_NAME, CURRENCY_PAIRS);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyBase(), checkerInfo.getCurrencyCounter()});
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.bid = ParseUtils.getDoubleFromString(jsonObject,"best_bid");
        ticker.ask = ParseUtils.getDoubleFromString(jsonObject,"best_ask");
        ticker.vol = ParseUtils.getDoubleFromString(jsonObject,"volume_by_product");
        ticker.last = ParseUtils.getDoubleFromString(jsonObject,"ltp");
    }
}
