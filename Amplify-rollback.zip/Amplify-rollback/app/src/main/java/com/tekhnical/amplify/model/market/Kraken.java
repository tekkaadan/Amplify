package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.model.currency.VirtualCurrency;
import com.tekhnical.amplify.util.ParseUtils;

import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class Kraken extends Market {
    private static final String NAME = "Kraken";
    private static final String TTS_NAME = "Kraken";
    private static final String URL = "https://api.kraken.com/0/public/Ticker?pair=%1$s";
    private static final String URL_CURRENCY_PAIRS = "https://api.kraken.com/0/public/AssetPairs";

    public Kraken() {
        super("kraken",NAME, TTS_NAME, null);
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        if (checkerInfo.getCurrencyPairId() != null) {
            return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
        }
        String currencyBase = fixCurrency(checkerInfo.getCurrencyBase());
        String currencyCounter = fixCurrency(checkerInfo.getCurrencyCounter());
        return String.format(URL, new Object[]{currencyBase + currencyCounter});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Kraken.png";
        //return "https://assets.coingecko.com/markets/images/29/small/kraken.jpg";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.kraken;
    }
    private String fixCurrency(String currency) {
        if (VirtualCurrency.BTC.equals(currency)) {
            return VirtualCurrency.XBT;
        }
        if (VirtualCurrency.VEN.equals(currency)) {
            return VirtualCurrency.XVN;
        }
        if (VirtualCurrency.DOGE.equals(currency)) {
            return VirtualCurrency.XDG;
        }
        return currency;
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject resultObject = jsonObject.getJSONObject("result");
        JSONObject pairObject = resultObject.getJSONObject(resultObject.names().getString(0));
        ticker.bid = getDoubleFromJsonArrayObject(pairObject, "b");
        ticker.ask = getDoubleFromJsonArrayObject(pairObject, "a");
        ticker.vol = getDoubleFromJsonArrayObject(pairObject, "v");
        ticker.high = getDoubleFromJsonArrayObject(pairObject, "h");
        ticker.low = getDoubleFromJsonArrayObject(pairObject, "l");
        ticker.last = getDoubleFromJsonArrayObject(pairObject, "c");
    }

    private double getDoubleFromJsonArrayObject(JSONObject jsonObject, String arrayKey) throws Exception {
        if(jsonObject.has(arrayKey)) {
            JSONArray jsonArray = jsonObject.getJSONArray(arrayKey);
            if (jsonArray.length() > 0)
                return Double.parseDouble(jsonArray.getString(0));
        }
        return 0.0d;
    }

    public String getCurrencyPairsUrl(int requestId) {
        return URL_CURRENCY_PAIRS;
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject jsonObject, List<CurrencyPairInfo> pairs) throws Exception {
        JSONObject result = jsonObject.getJSONObject("result");
        JSONArray pairNames = result.names();
        for (int i = 0; i < pairNames.length(); i++) {
            String pairId = pairNames.getString(i);
            if (pairId != null) {
                JSONObject pairJsonObject = result.getJSONObject(pairId);
                pairs.add(new CurrencyPairInfo(ParseUtils.getString(pairJsonObject,"base"), ParseUtils.getString(pairJsonObject,"quote"), pairId));
            }
        }
    }

    private String parseCurrency(String currency) {
        if (currency != null && currency.length() >= 2) {
            char firstChar = currency.charAt(0);
            if (firstChar == 'Z' || firstChar == 'X') {
                currency = currency.substring(1);
            }
        }
        if (VirtualCurrency.XBT.equals(currency)) {
            return VirtualCurrency.BTC;
        }
        if (VirtualCurrency.XVN.equals(currency)) {
            return VirtualCurrency.VEN;
        }
        if (VirtualCurrency.XDG.equals(currency)) {
            return VirtualCurrency.DOGE;
        }
        return currency;
    }
}
