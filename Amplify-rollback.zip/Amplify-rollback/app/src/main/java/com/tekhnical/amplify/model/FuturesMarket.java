package com.tekhnical.amplify.model;

import java.util.HashMap;

public abstract class FuturesMarket extends Market {
    public final int[] contractTypes;

    public abstract String getUrl(int i, CheckerInfo checkerInfo, int i2);

    public FuturesMarket(String id,String name, String ttsName, HashMap<String, String[]> currencyPairs, int[] contractTypes2) {
        super(id,name, ttsName, currencyPairs);
        this.contractTypes = contractTypes2;
    }

    public final String getUrl(int requestId, CheckerInfo checkerInfo) {
        return getUrl(requestId, checkerInfo, checkerInfo.getContractType());
    }
}
