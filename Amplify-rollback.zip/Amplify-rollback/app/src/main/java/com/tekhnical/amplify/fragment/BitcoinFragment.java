package com.tekhnical.amplify.fragment;


import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.tekhnical.amplify.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class BitcoinFragment extends Fragment {


    public BitcoinFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_bitcoin, container, false);

        TextView codeTv= view.findViewById(R.id.code_tv);
        ImageView qrview = view.findViewById(R.id.donate_qr);
        Glide.with(this).load("file:///android_asset/bc_qr.jpg").into(qrview);
        ImageView copyView = view.findViewById(R.id.copy_code_iv);
        copyView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipboard = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("CODE", codeTv.getText().toString());
                clipboard.setPrimaryClip(clip);
                Toast.makeText(getContext(), "Copied to clipboard", Toast.LENGTH_SHORT).show();
            }
        });
        return view;
    }

}
