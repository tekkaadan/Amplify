package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Zaif extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Zaif";
    private static final String TTS_NAME = "Zaif";
    private static final String URL = "https://api.zaif.jp/api/1/ticker/%1$s";
    private static final String CURRENCIES_URL = "https://api.zaif.jp/api/1/currency_pairs/all";

    public Zaif() {
        super("zaif", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return String.format(URL, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    @Override
    public int getImageUrl() {
        return R.drawable.zaif;
    }
    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/Zaif.png";
        //return "https://assets.coingecko.com/markets/images/99/small/zaif.png";
    }*/

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject jsonObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        ticker.last = ParseUtils.getDouble(jsonObject, "last");
        ticker.high = ParseUtils.getDouble(jsonObject, "high");
        ticker.low = ParseUtils.getDouble(jsonObject, "low");
        ticker.bid = ParseUtils.getDouble(jsonObject, "bid");
        ticker.ask = ParseUtils.getDouble(jsonObject, "ask");
        ticker.vol = ParseUtils.getDouble(jsonObject, "volume");
    }

    public Double convert(String value){
        DecimalFormat df = new DecimalFormat("0.##E0");
        String formattedVal = df.format(value);
        return Double.parseDouble(formattedVal);
    }
    private double getFirstPriceFromOrder(JSONObject jsonObject, String key) throws Exception {
        JSONArray array = jsonObject.getJSONArray(key);
        if (array.length() == 0) {
            return -1.0d;
        }
        return Double.parseDouble(array.getString(0));
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("currency_pair")){
                String split[] = jsonObject.getString("currency_pair").split("_");
                if (split.length>=2)
                    pairs.add(new CurrencyPairInfo(split[0].toUpperCase(),split[1].toUpperCase(),jsonObject.getString("currency_pair")));
            }
        }
    }


}
