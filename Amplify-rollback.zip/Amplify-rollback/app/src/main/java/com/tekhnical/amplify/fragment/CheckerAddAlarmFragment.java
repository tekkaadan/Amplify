package com.tekhnical.amplify.fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import butterknife.ButterKnife;
import butterknife.BindView;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.activity.CheckerAddActivity;
import com.tekhnical.amplify.activity.CheckerAddAlarmActivity;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.content.AlarmRecord;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.util.AlarmRecordHelper;
import com.tekhnical.amplify.util.CurrencyUtils;
import com.tekhnical.amplify.util.TickerUtils;
import com.tekhnical.amplify.view.ViewAlarmCheckPointPreference;
import com.tekhnical.amplify.view.ViewAlarmCheckPointPreference.OnCheckpointChangedListener;
import com.tekhnical.amplify.view.ViewAlarmTypeSpinnerPreference;
import com.tekhnical.amplify.view.ViewAlarmValuePickerPreference;
import com.tekhnical.amplify.view.ViewAlarmValuePickerPreference.OnValueChangedListener;
import com.tekhnical.amplify.view.generic.ViewSpinnerPreference;
import com.tekhnical.amplify.view.generic.ViewSpinnerPreference.OnItemSelectedListener;
import com.tekhnical.amplify.view.generic.ViewTwoStatePreference;
import com.tekhnical.amplify.view.generic.ViewTwoStatePreference.OnCheckChangedListener;

public class CheckerAddAlarmFragment extends Fragment {
    private static final String EXTRA_SHOULD_SAVE_STATE = "should_save_state";
    private static final String EXTRA_UNSAVED_CHANGES = "unsaved_changes";
    @BindView(R.id.alarmCheckPointView)
    ViewAlarmCheckPointPreference alarmCheckPointView;
    @BindView(R.id.alarmEnabledView)
    ViewTwoStatePreference alarmEnabledView;
    @BindView(R.id.alarmLedView)
    ViewTwoStatePreference alarmLedView;
    private AlarmRecord alarmRecord;
    @BindView(R.id.alarmSoundView)
    ViewTwoStatePreference alarmSoundView;
    @BindView(R.id.alarmTTSView)
    ViewTwoStatePreference alarmTTSView;
    @BindView(R.id.alarmTypeView)
    ViewAlarmTypeSpinnerPreference alarmTypeView;
    @BindView(R.id.alarmValueView)
    ViewAlarmValuePickerPreference alarmValueView;
    @BindView(R.id.alarmVibrateView)
    ViewTwoStatePreference alarmVibrateView;
    private CheckerRecord checkerRecord;
    private boolean unsavedChanges;

    public static final CheckerAddAlarmFragment newInstance(CheckerRecord checkerRecord2, AlarmRecord alarmRecord2) {
        CheckerAddAlarmFragment fragment = new CheckerAddAlarmFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable(CheckerAddActivity.EXTRA_CHECKER_RECORD, checkerRecord2);
        bundle.putParcelable(CheckerAddAlarmActivity.EXTRA_ALARM_RECORD, alarmRecord2);
        bundle.putBoolean(EXTRA_SHOULD_SAVE_STATE, true);
        fragment.setArguments(bundle);
        return fragment;
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.checker_add_alarm_fragment, null);
        ButterKnife.bind((Object) this, view);
        return view;
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (shouldSaveState()) {
            if (savedInstanceState != null) {
                this.alarmRecord = (AlarmRecord) savedInstanceState.getParcelable(CheckerAddAlarmActivity.EXTRA_ALARM_RECORD);
                this.unsavedChanges = savedInstanceState.getBoolean(EXTRA_UNSAVED_CHANGES);
            } else if (getArguments() != null) {
                this.alarmRecord = (AlarmRecord) getArguments().getParcelable(CheckerAddAlarmActivity.EXTRA_ALARM_RECORD);
            }
            if (getArguments() != null) {
                this.checkerRecord = (CheckerRecord) getArguments().getParcelable(CheckerAddActivity.EXTRA_CHECKER_RECORD);
            }
        } else if (savedInstanceState != null) {
            this.unsavedChanges = savedInstanceState.getBoolean(EXTRA_UNSAVED_CHANGES);
        }
        setCheckerAndAlarmRecord(this.checkerRecord, this.alarmRecord);
    }

    public void setCheckerAndAlarmRecord(CheckerRecord checkerRecord2, AlarmRecord alarmRecord2) {
        if (alarmRecord2 != null && checkerRecord2 != null) {
            this.checkerRecord = checkerRecord2;
            this.alarmRecord = alarmRecord2;
            refreshUI();
        }
    }

    private boolean shouldSaveState() {
        return getArguments() != null && getArguments().getBoolean(EXTRA_SHOULD_SAVE_STATE);
    }

    private void refreshUI() {
        refreshAlarmToggles(this.alarmRecord.getEnabled());
        this.alarmEnabledView.setOnCheckChangedListener(null);
        this.alarmEnabledView.setChecked(this.alarmRecord.getEnabled());
        this.alarmEnabledView.setOnCheckChangedListener(new OnCheckChangedListener() {
            public boolean onCheckChanged(ViewTwoStatePreference viewCheckBoxPreference, boolean checked) {
                CheckerAddAlarmFragment.this.alarmRecord.setEnabled(checked);
                CheckerAddAlarmFragment.this.unsavedChanges = true;
                CheckerAddAlarmFragment.this.refreshAlarmToggles(checked);
                return true;
            }
        });
        this.alarmTypeView.setOnItemSelectedListener(null);
        this.alarmTypeView.setSelection(AlarmRecordHelper.getPositionForAlarmType(getActivity(), this.alarmRecord));
        this.alarmTypeView.setOnItemSelectedListener(new OnItemSelectedListener() {
            public boolean onItemSelected(ViewSpinnerPreference viewSpinnerPreference, int position) {
                CheckerAddAlarmFragment.this.alarmRecord.setType((long) AlarmRecordHelper.getAlarmTypeForPosition(CheckerAddAlarmFragment.this.getActivity(), position));
                CheckerAddAlarmFragment.this.unsavedChanges = true;
                CheckerAddAlarmFragment.this.refreshAlarmValueView();
                CheckerAddAlarmFragment.this.refreshLastCheckPointVisibility();
                return true;
            }
        });
        this.alarmValueView.setOnValueChangedListener(null);
        this.alarmValueView.setCheckerAndAlarmRecord(this.checkerRecord, this.alarmRecord);
        refreshAlarmValueView();
        this.alarmValueView.setOnValueChangedListener(new OnValueChangedListener() {
            public boolean onValueChanged(ViewAlarmValuePickerPreference viewAlarmValuePickerPreference, double number) {
                CheckerAddAlarmFragment.this.alarmRecord.setValue(number);
                CheckerAddAlarmFragment.this.unsavedChanges = true;
                return true;
            }
        });
        this.alarmCheckPointView.setOnCheckpointChangedListener(null);
        refreshLastCheckPoint();
        this.alarmCheckPointView.setOnCheckpointChangedListener(new OnCheckpointChangedListener() {
            public boolean onCheckpointChanged(ViewAlarmCheckPointPreference viewAlarmCheckpointPreference, Ticker lastCheckPointTicker) {
                CheckerAddAlarmFragment.this.alarmRecord.setLastCheckPointTicker(lastCheckPointTicker != null ? TickerUtils.toJson(lastCheckPointTicker) : null);
                CheckerAddAlarmFragment.this.unsavedChanges = true;
                return true;
            }
        });
        this.alarmSoundView.setOnCheckChangedListener(null);
        this.alarmSoundView.setChecked(this.alarmRecord.getSound());
        this.alarmSoundView.setOnCheckChangedListener(new OnCheckChangedListener() {
            public boolean onCheckChanged(ViewTwoStatePreference viewCheckBoxPreference, boolean checked) {
                CheckerAddAlarmFragment.this.alarmRecord.setSound(checked);
                CheckerAddAlarmFragment.this.unsavedChanges = true;
                return true;
            }
        });
        this.alarmVibrateView.setOnCheckChangedListener(null);
        this.alarmVibrateView.setChecked(this.alarmRecord.getVibrate());
        this.alarmVibrateView.setOnCheckChangedListener(new OnCheckChangedListener() {
            public boolean onCheckChanged(ViewTwoStatePreference viewCheckBoxPreference, boolean checked) {
                CheckerAddAlarmFragment.this.alarmRecord.setVibrate(checked);
                CheckerAddAlarmFragment.this.unsavedChanges = true;
                return true;
            }
        });
        this.alarmLedView.setOnCheckChangedListener(null);
        this.alarmLedView.setChecked(this.alarmRecord.getLed());
        this.alarmLedView.setOnCheckChangedListener(new OnCheckChangedListener() {
            public boolean onCheckChanged(ViewTwoStatePreference viewCheckBoxPreference, boolean checked) {
                CheckerAddAlarmFragment.this.alarmRecord.setLed(checked);
                CheckerAddAlarmFragment.this.unsavedChanges = true;
                return true;
            }
        });
        this.alarmTTSView.setOnCheckChangedListener(null);
        this.alarmTTSView.setChecked(this.alarmRecord.getTtsEnabled());
        this.alarmTTSView.setOnCheckChangedListener(new OnCheckChangedListener() {
            public boolean onCheckChanged(ViewTwoStatePreference viewCheckBoxPreference, boolean checked) {
                CheckerAddAlarmFragment.this.alarmRecord.setTtsEnabled(checked);
                CheckerAddAlarmFragment.this.unsavedChanges = true;
                return true;
            }
        });
    }

    public void onSaveInstanceState(Bundle outState) {
        if (shouldSaveState()) {
            outState.putParcelable(CheckerAddAlarmActivity.EXTRA_ALARM_RECORD, this.alarmRecord);
        }
        outState.putBoolean(EXTRA_UNSAVED_CHANGES, this.unsavedChanges);
        super.onSaveInstanceState(outState);
    }

    public void onDestroyView() {
        super.onDestroyView();
        //ButterKnife.reset(this);
    }

    public AlarmRecord getAlarmRecord() {
        return this.alarmRecord;
    }

    public boolean getUnsavedChanges() {
        return this.unsavedChanges;
    }

    private void refreshLastCheckPoint() {
        this.alarmCheckPointView.setSufix(CurrencyUtils.getCurrencySymbol(CurrencyUtils.getCurrencySubunit(this.checkerRecord.getCurrencyDst(), this.checkerRecord.getCurrencySubunitDst()).name));
        this.alarmCheckPointView.setCheckerAndAlarmRecord(this.checkerRecord, this.alarmRecord);
        refreshLastCheckPointVisibility();
    }

    private void refreshLastCheckPointVisibility() {
        this.alarmCheckPointView.setVisibility(AlarmRecordHelper.isCheckPointAvailableForAlarmType(this.alarmRecord) ? View.VISIBLE : View.GONE);
    }

    private void refreshAlarmToggles(boolean isAlarmEnabled) {
        this.alarmTypeView.setEnabled(isAlarmEnabled);
        this.alarmValueView.setEnabled(isAlarmEnabled);
        this.alarmCheckPointView.setEnabled(isAlarmEnabled);
        this.alarmSoundView.setEnabled(isAlarmEnabled);
        this.alarmVibrateView.setEnabled(isAlarmEnabled);
        this.alarmLedView.setEnabled(isAlarmEnabled);
        this.alarmTTSView.setEnabled(isAlarmEnabled);
    }

    private void refreshAlarmValueView() {
        String prefix = AlarmRecordHelper.getPrefixForAlarmType(this.checkerRecord, this.alarmRecord);
        String sufix = AlarmRecordHelper.getSufixForAlarmType(this.checkerRecord, this.alarmRecord);
        this.alarmValueView.setPrefix(prefix);
        this.alarmValueView.setSufix(sufix!=null ? sufix : "$");
        this.alarmValueView.setValue(this.alarmRecord.getValue());
    }
}
