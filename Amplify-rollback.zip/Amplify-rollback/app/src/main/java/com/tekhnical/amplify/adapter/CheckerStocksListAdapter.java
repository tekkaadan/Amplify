package com.tekhnical.amplify.adapter;

import android.content.Context;
import android.database.Cursor;
import android.text.Html;
import android.text.TextUtils;
import android.text.style.RelativeSizeSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;
import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.content.AlarmRecord;
import com.tekhnical.amplify.content.CheckerRecord;
import com.tekhnical.amplify.content.MaindbContract;
import com.tekhnical.amplify.model.CurrencySubunit;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.StockMarket;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.AlarmRecordHelper;
import com.tekhnical.amplify.util.CheckerRecordHelper;
import com.tekhnical.amplify.util.CurrencyUtils;
import com.tekhnical.amplify.util.FormatUtils;
import com.tekhnical.amplify.util.MarketsConfigUtils;
import com.tekhnical.amplify.util.SpannableUtils;
import com.tekhnical.amplify.util.TickerUtils;
import com.tekhnical.amplify.util.Utils;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class CheckerStocksListAdapter extends CursorAdapter {
    private boolean actionModeActive;
    private final Context context;
    private OnItemClickListener itemClickListener;
    boolean isDarkTheme = false;
    static class ViewHolder {
        @BindView(R.id.item_parent)
        LinearLayout parent;
        @BindView(R.id.exchange_icon)
        ImageView icon;
        @BindView(R.id.currencyView)
        TextView currencyView;
        @BindView(R.id.lastCheckTimeView)
        TextView lastCheckTimeView;
        @BindView(R.id.lastCheckValueView)
        TextView lastCheckValueView;
        @BindView(R.id.lastCheckView)
        TextView lastCheckView;
        @BindView(R.id.marketView)
        TextView marketView;
        @BindView(R.id.checker_cb)
        CheckBox checkerCb;
        public ViewHolder(View view) {
            ButterKnife.bind((Object) this, view);
        }
    }

    public CheckerStocksListAdapter(Context context, OnItemClickListener listener) {
        super(context, (Cursor) null, false);
        itemClickListener = listener;
        this.context = context;
        isDarkTheme = MyApplication.getInstance().isNightModeEnabled();
    }

    public void setActionModeActive(boolean actionModeActive) {
        this.actionModeActive = actionModeActive;
        notifyDataSetChanged();
    }

    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.checkers_stocks_list_item, parent, false);
        view.setTag(new ViewHolder(view));
        return view;
    }

    public void bindView(View convertView, Context context, Cursor cursor) {
        int lastCheckValueViewVisibility;
        ViewHolder holder = (ViewHolder) convertView.getTag();
        final CheckerRecord item = CheckerRecord.fromCursor(cursor);
        CurrencySubunit subunitDst = CurrencyUtils.getCurrencySubunit(item.getCurrencyDst(), item.getCurrencySubunitDst());
        Market market = MarketsConfigUtils.getMarketByKey(item.getMarketKey());

        int position = cursor.getPosition();
        holder.currencyView.setText(market.key);
        holder.marketView.setText(market.name);
        holder.currencyView.setTextColor(isDarkTheme ? context.getResources().getColor( R.color.md_white_1000) :  context.getResources().getColor( R.color.md_black_1000_87));
        holder.marketView.setTextColor(isDarkTheme ? context.getResources().getColor( R.color.md_white_1000_70) : context.getResources().getColor( R.color.md_black_1000_54));
        holder.lastCheckValueView.setTextColor(isDarkTheme ? context.getResources().getColor( R.color.md_white_1000) :  context.getResources().getColor( R.color.md_black_1000_87));
        Ticker lastCheckTicker = TickerUtils.fromJson(item.getLastCheckTicker());
        if (item.getErrorMsg() != null) {
            holder.lastCheckView.setText(context.getString(R.string.check_error_generic_prefix, new Object[]{""}));
            holder.lastCheckValueView.setText(Html.fromHtml("<small>" + item.getErrorMsg() + "</small>"));
            holder.lastCheckValueView.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
            lastCheckValueViewVisibility = View.VISIBLE;
            holder.lastCheckTimeView.setText(FormatUtils.formatSameDayTimeOrDate(context, item.getLastCheckDate()));
        } else if (lastCheckTicker != null) {
            holder.lastCheckView.setText(R.string.checkers_list_item_last_check);
            holder.lastCheckValueView.setText(" " + FormatUtils.formatPriceWithCurrency(lastCheckTicker.last, subunitDst));
            //holder.lastCheckValueView.setCompoundDrawablesWithIntrinsicBounds(0, 0, NotificationUtils.getIconResIdForTickers(TickerUtils.fromJson(item.getPreviousCheckTicker()), lastCheckTicker, true), 0);
            lastCheckValueViewVisibility = View.VISIBLE;
            holder.lastCheckTimeView.setText(FormatUtils.formatSameDayTimeOrDate(context, lastCheckTicker.timestamp));
        } else {
            holder.lastCheckView.setText(R.string.checkers_list_item_last_check);
            holder.lastCheckValueView.setText(null);
            lastCheckValueViewVisibility = View.GONE;
        }
        if (market.getImageUrl()!=0){
            holder.icon.setImageResource(market.getImageUrl());
            //Glide.with(context).load(market.getImageUrl()).fitCenter().into(holder.icon);
        }
        //holder.lastCheckView.setVisibility(lastCheckValueViewVisibility);
        holder.lastCheckValueView.setVisibility(lastCheckValueViewVisibility);
        holder.lastCheckTimeView.setVisibility(lastCheckValueViewVisibility);
        //holder.separator.setVisibility(lastCheckValueViewVisibility);
        holder.parent.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Utils.vibrate(context);
                itemClickListener.onItemLongClick(v,position);
                return true;
            }
        });
        holder.parent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemClickListener.onItemClick(position);
            }
        });
        holder.checkerCb.setChecked(item.getEnabled());
        holder.checkerCb.setOnCheckedChangeListener((button, isChecked) -> {
            MaindbContract.Checker.newBuilder().setEnabled(isChecked).update(item.getId(), true);
            item.setEnabled(isChecked);
            CheckerRecordHelper.doAfterEdit(context, item, true);
        });
        if(this.actionModeActive){
            holder.checkerCb.setEnabled(false);
        }
    }
    public interface OnItemClickListener{
        public void onItemClick(int position);
        public void onItemLongClick(View view,int position);
    }
}
