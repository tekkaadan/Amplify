package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Bitz extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Bitz";
    private static final String TTS_NAME = "Bitz";
    private static final String URL = "https://apiv2.bitz.com/Market/tickerall";

    public Bitz() {
        super("bitz", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        return URL;
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/bitz.png";
        //return "https://assets.coingecko.com/markets/images/49/small/bit-z-new-blue.png";
    }*/

    @Override
    public int getImageUrl() {
        return R.drawable.bitz;
    }
    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        JSONObject dataObject = tickerObject.getJSONObject("data");
        if (dataObject.has(checkerInfo.getCurrencyPairId())) {
            JSONObject jsonObject = dataObject.getJSONObject(checkerInfo.getCurrencyPairId());
            ticker.last = ParseUtils.getDoubleFromString(jsonObject, "open");
            ticker.high = ParseUtils.getDoubleFromString(jsonObject, "high");
            ticker.low = ParseUtils.getDoubleFromString(jsonObject, "low");
            ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "bidPrice");
            ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "askPrice");
            ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "volume");
        }
    }


    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {
        JSONObject dataObject = json.getJSONObject("data");
        JSONArray jsonArray = dataObject.names();
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = dataObject.getJSONObject(jsonArray.getString(i));
            if (jsonObject.has("symbol")){
                String splits[] = jsonObject.getString("symbol").split("_");
                if (splits.length>=2)
                    list.add(new CurrencyPairInfo(splits[0].toUpperCase(),splits[1].toUpperCase(),jsonObject.getString("symbol")));
            }
        }
    }
}
