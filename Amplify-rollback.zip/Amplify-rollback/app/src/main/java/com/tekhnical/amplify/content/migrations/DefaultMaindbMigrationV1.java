package com.tekhnical.amplify.content.migrations;

import android.database.sqlite.SQLiteDatabase;
import com.robotoworks.mechanoid.db.SQLiteMigration;

/* renamed from: com.tekhnical.amplify.db.content.migrations.DefaultMaindbMigrationV1 */
public class DefaultMaindbMigrationV1 extends SQLiteMigration {
    public void onBeforeUp(SQLiteDatabase db) {
    }

    @Override
    public void up(SQLiteDatabase db) {
        db.execSQL("create table checker ( _id integer primary key autoincrement, enabled boolean, marketKey text, currencySrc text, currencyDst text, frequency integer, notificationPriority integer, ttsEnabled boolean,  lastCheckTicker text, lastCheckPointTicker text, holdings text) ");
        db.execSQL("create table alarm ( _id integer primary key autoincrement, checkerId integer, enabled boolean, type integer, value real, sound boolean, soundUri text, vibrate boolean, led boolean, ttsEnabled boolean ) ");

    }

    public void onAfterUp(SQLiteDatabase db) {
    }
}
