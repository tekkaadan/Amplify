package com.tekhnical.amplify.activity.generic;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.tekhnical.amplify.MyApplication;
import com.tekhnical.amplify.R;
import com.tekhnical.amplify.util.TTSHelper;

public abstract class SimpleFragmentActivity<T extends Fragment> extends AppCompatActivity {
    private static final String CHILD_FRAGMENT_TAG = "CHILD_FRAGMENT";
    private static final IntentFilter audioHeadsetChangedFilter = new IntentFilter("android.intent.action.HEADSET_PLUG");
    private final BroadcastReceiver audioHeadsetChangedReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            SimpleFragmentActivity.this.setVolumeControlStream(TTSHelper.getProperAudioStream(context));
        }
    };
    protected T childFragment;

    public abstract T createChildFragment();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(getContentViewResId());

        Toolbar toolbar = findViewById(R.id.app_toolbar);
        if(toolbar!=null) {
            TextView titleView = findViewById(R.id.appbar_title);
            titleView.setText(getContentViewTitle());
            toolbar.setTitle("");
            setSupportActionBar(toolbar);
            int theme = MyApplication.getAppTheme(this);
            if (theme == 3)
                toolbar.setPopupTheme(R.style.GrayPopupTheme);
            else if (theme == 4)
                toolbar.setPopupTheme(R.style.SepiaPopupTheme);
            else
                toolbar.setPopupTheme(R.style.ToolbarPopupTheme);
        }
        this.childFragment = (T) getSupportFragmentManager().findFragmentByTag(CHILD_FRAGMENT_TAG);
        if (this.childFragment == null) {
            this.childFragment = createChildFragment();
            if (this.childFragment != null) {
                FragmentTransaction mFragmentTransaction = getSupportFragmentManager().beginTransaction();
                mFragmentTransaction.replace(R.id.content, this.childFragment, CHILD_FRAGMENT_TAG);
                mFragmentTransaction.commit();
            }
        }
    }

    public void setContentTheme(boolean isSetting){
        int theme = MyApplication.getAppTheme(this);
        if (isSetting){
            if (theme == 3)
                setTheme(R.style.GraySettingsTheme);
            else if (theme == 4)
                setTheme(R.style.SepiaSettingsTheme);
            else
                setTheme(R.style.SettingsTheme);
        }else {
            if (theme == 3)
                setTheme(R.style.GrayTheme);
            else if (theme == 4)
                setTheme(R.style.SepiaTheme);
            else
                setTheme(R.style.AppTheme);
        }
    }
    @Override
    public void onStart() {
        super.onStart();
        registerReceiver(this.audioHeadsetChangedReceiver, audioHeadsetChangedFilter);
        setVolumeControlStream(TTSHelper.getProperAudioStream(this));
    }

    @Override
    public void onStop() {
        super.onStop();
        try {
            unregisterReceiver(this.audioHeadsetChangedReceiver);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getContentViewResId() {
        return R.layout.fragment_activity;
    }

    public String getContentViewTitle(){
        return "";
    }

    public T getChildFragment() {
        return this.childFragment;
    }
}
