package com.tekhnical.amplify.content;

import android.content.Context;
import android.content.UriMatcher;
import android.net.Uri;
import com.tekhnical.amplify.content.AbstractMaindbOpenHelper.Sources;
import com.tekhnical.amplify.content.MaindbContract.Alarm;
import com.tekhnical.amplify.content.MaindbContract.Checker;
import com.robotoworks.mechanoid.db.ContentProviderActions;
import com.robotoworks.mechanoid.db.DefaultContentProviderActions;
import com.robotoworks.mechanoid.db.MechanoidContentProvider;
import com.robotoworks.mechanoid.db.MechanoidSQLiteOpenHelper;
import java.util.Set;

public abstract class AbstractMaindbContentProvider extends MechanoidContentProvider {
    protected static final int ALARM = 2;
    protected static final int ALARM_ID = 3;
    protected static final int CHECKER = 0;
    protected static final int CHECKER_ID = 1;
    public static final int NUM_URI_MATCHERS = 4;

    public UriMatcher createUriMatcher() {
        UriMatcher matcher = new UriMatcher(-1);
        String authority = MaindbContract.CONTENT_AUTHORITY;
        matcher.addURI(authority, Sources.CHECKER, 0);
        matcher.addURI(authority, "checker/#", 1);
        matcher.addURI(authority, "alarm", 2);
        matcher.addURI(authority, "alarm/#", 3);
        return matcher;
    }

    public String[] createContentTypes() {
        return new String[]{Checker.CONTENT_TYPE, Checker.ITEM_CONTENT_TYPE, Alarm.CONTENT_TYPE, Alarm.ITEM_CONTENT_TYPE};
    }

    public MechanoidSQLiteOpenHelper createOpenHelper(Context context) {
        return new MaindbOpenHelper(context);
    }

    public Set<Uri> getRelatedUris(Uri uri) {
        return (Set) MaindbContract.REFERENCING_VIEWS.get(uri);
    }

    public ContentProviderActions createActions(int id) {
        switch (id) {
            case CHECKER:
                return createCheckerActions();
            case CHECKER_ID:
                return createCheckerByIdActions();
            case ALARM:
                return createAlarmActions();
            case ALARM_ID:
                return createAlarmByIdActions();
            default:
                throw new UnsupportedOperationException("Unknown id: " + id);
        }
    }

    private ContentProviderActions createCheckerByIdActions() {
        return new DefaultContentProviderActions(Sources.CHECKER, true, CheckerRecord.getFactory());
    }

    private ContentProviderActions createCheckerActions() {
        return new DefaultContentProviderActions(Sources.CHECKER, false, CheckerRecord.getFactory());
    }

    private ContentProviderActions createAlarmByIdActions() {
        return new DefaultContentProviderActions(Sources.ALARM, true, AlarmRecord.getFactory());
    }

    private ContentProviderActions createAlarmActions() {
        return new DefaultContentProviderActions(Sources.ALARM, false, AlarmRecord.getFactory());
    }
}
