package com.tekhnical.amplify.appwidget;

import android.os.Bundle;

import androidx.preference.ListPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;


import com.tekhnical.amplify.R;

public class WidgetConfigureFragment extends PreferenceFragmentCompat {
    public static WidgetConfigureFragment newInstance(int appWidgetId) {
        WidgetConfigureFragment fragment = new WidgetConfigureFragment();
        Bundle args = new Bundle();
        args.putInt("appWidgetId", appWidgetId);
        fragment.setArguments(args);
        return fragment;
    }

    public void onCreate(Bundle paramBundle) {
        super.onCreate(paramBundle);
        int appWidgetId = 0;
        if (getArguments() != null) {
            appWidgetId = getArguments().getInt("appWidgetId", 0);
        }
        getPreferenceManager().setSharedPreferencesName(WidgetPrefsUtils.getSharedPreferencesName(appWidgetId));

    }

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.widget_settings,rootKey);
        final ListPreference alphaPercentPreference = (ListPreference) findPreference(getString(R.string.widget_settings_alpha_percent_key));
        //setAlphaPercentPreferenceSummary(alphaPercentPreference, alphaPercentPreference.getEntry());
        alphaPercentPreference.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                try {
                    CharSequence[] entries = alphaPercentPreference.getEntries();
                    int index = alphaPercentPreference.findIndexOfValue((String) newValue);
                    if (index < 0 || index >= entries.length) {
                        index = 0;
                    }
                    //WidgetConfigureFragment.this.setAlphaPercentPreferenceSummary(alphaPercentPreference, alphaPercentPreference.getEntries()[index]);
                    return true;
                } catch (Exception e) {
                    e.printStackTrace();
                    return false;
                }
            }
        });
    }


    private void setAlphaPercentPreferenceSummary(ListPreference alphaPercentPreference, CharSequence newSummary) {
        alphaPercentPreference.setSummary(String.valueOf(newSummary).replace("%", "%%"));
    }
}
