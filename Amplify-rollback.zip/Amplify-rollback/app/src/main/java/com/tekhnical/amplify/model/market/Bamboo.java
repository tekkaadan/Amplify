package com.tekhnical.amplify.model.market;

import com.tekhnical.amplify.R;
import com.tekhnical.amplify.model.CheckerInfo;
import com.tekhnical.amplify.model.CurrencyPairInfo;
import com.tekhnical.amplify.model.Market;
import com.tekhnical.amplify.model.Ticker;
import com.tekhnical.amplify.util.ParseUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Bamboo extends Market {

    private static final HashMap<String, String[]> CURRENCY_PAIRS = new LinkedHashMap();
    private static final String NAME = "Bamboo Relay";
    private static final String TTS_NAME = "Bamboo Relay";
    private static final String URL1 = "https://rest.bamboorelay.com/main/0x/markets/%1$s/ticker";
    private static final String URL2 = "https://rest.bamboorelay.com/main/0x/markets/%1$s/stats";
    private static final String CURRENCIES_URL = "https://rest.bamboorelay.com/main/0x/markets";

    public Bamboo() {
        super("bamboo_relay", NAME, TTS_NAME, null);
    }

    @Override
    public String getCurrencyPairsUrl(int requestId) {
        return CURRENCIES_URL;
    }

    public String getUrl(int requestId, CheckerInfo checkerInfo) {
        if (requestId ==0)
        return String.format(URL1, new Object[]{checkerInfo.getCurrencyPairId()});
        else
        return String.format(URL2, new Object[]{checkerInfo.getCurrencyPairId()});
    }

    /*@Override
    public String getImageUrl() {
        return "file:///android_asset/logos/bamboo.png";
    }
*/
    @Override
    public int getImageUrl() {
        return R.drawable.bamboo;
    }
    @Override
    public int getNumOfRequests(CheckerInfo checkerInfo) {
        return 2;
    }

    @Override
    public void parseTickerFromJsonObject(int requestId, JSONObject tickerObject, Ticker ticker, CheckerInfo checkerInfo) throws Exception {
        if (requestId == 0) {
            JSONObject jsonObject = tickerObject.getJSONObject("ticker");
            ticker.bid = ParseUtils.getDoubleFromString(jsonObject, "bestBid");
            ticker.ask = ParseUtils.getDoubleFromString(jsonObject, "bestAsk");
            ticker.last = ParseUtils.getDoubleFromString(jsonObject, "price");
        }else{
            JSONObject jsonObject = tickerObject.getJSONObject("stats");
            ticker.vol = ParseUtils.getDoubleFromString(jsonObject, "volume24Hour");
        }
    }

    @Override
    public void parseCurrencyPairs(int requestId, String responseString, List<CurrencyPairInfo> pairs) throws Exception {
        JSONArray jsonArray = new JSONArray(responseString);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if (jsonObject.has("id")){
                String splits[] = jsonObject.getString("displayName").split("/");
                if (splits.length>=2)
                    pairs.add(new CurrencyPairInfo(splits[0],splits[1],jsonObject.getString("id")));
            }
        }
    }

    @Override
    public void parseCurrencyPairsFromJsonObject(int requestId, JSONObject json, List<CurrencyPairInfo> list) throws Exception {

    }

}
